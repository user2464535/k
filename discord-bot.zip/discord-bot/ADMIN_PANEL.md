# 🛠️ Admin Panel Documentation

## Overview
The admin panel provides comprehensive bot management capabilities for the bot owner. Access is restricted to the user ID specified in the `OWNER_ID` environment variable.

## 🚀 Access Commands

### `!adminpanel`
**Permissions**: Bot Owner only (OWNER_ID environment variable)
**Description**: Opens the comprehensive admin control panel

### `!setupredeempanel` 
**Permissions**: Server Owner only (Discord guild owner)
**Description**: Creates the interactive redeem panel for users

---

## 🎛️ Admin Panel Features

### 📊 Statistics Dashboard
- **Real-time bot metrics**: Uptime, memory usage, performance
- **System information**: Node.js version, platform, environment
- **Bot status**: Online/offline, feature availability
- **Quick overview**: All essential bot statistics at a glance

### 🔑 Key Management System
- **Generate New Keys**: Create access keys for different store types and durations
- **View All Keys**: Monitor all generated keys and their redemption status
- **Active Subscriptions**: See users with current active access
- **Usage Analytics**: Track key redemption patterns and statistics

### 👥 User Management
- **User Activity Tracking**: Monitor user barcode generation activity
- **Permission Management**: Role-based access control overview
- **Subscription Management**: View and manage user access periods
- **Security Features**: Privacy-focused user data handling

### 🗃️ Database Management
- **Database Health**: Monitor SQLite database status and performance
- **File Information**: Track database file sizes and table structure
- **Backup Tools**: Create database backups for data safety
- **Optimization**: Database vacuum and performance tuning

### ⚙️ System Information
- **Bot Version**: Current bot version and feature set
- **Runtime Info**: Node.js version, uptime, memory usage
- **Platform Details**: Operating system and environment details
- **Performance Metrics**: Real-time system performance data

### 🧹 Cleanup & Maintenance
- **Database Cleanup**: Remove old records and optimize storage
- **Key Expiration**: Force expire unused or old keys
- **Log Management**: Clear application log files
- **System Maintenance**: Database vacuum and optimization tools

---

## 🔐 Security Features

### Access Control
- **Owner-Only Access**: Admin panel restricted to OWNER_ID
- **Server Owner Features**: Setup panels limited to Discord guild owners
- **Role-Based Permissions**: Different access levels for different functions
- **Audit Trail**: All admin actions logged for security

### Privacy Protection
- **User Data Masking**: Usernames masked in logs (user***)
- **Secure Key Generation**: Cryptographically secure key generation
- **Local Storage**: No external API dependencies for sensitive data
- **Data Isolation**: Guild-specific data separation

---

## 📋 Environment Configuration

### Required Environment Variables
```env
# Bot Owner (Admin Panel Access)
OWNER_ID=your_discord_user_id_here

# Discord Bot Configuration
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_client_id_here

# Role IDs (Optional - fallback to name matching)
SAINSBURYS_ROLE_ID=your_sainsburys_role_id_here
ASDA_ROLE_ID=your_asda_role_id_here
MORRISONS_ROLE_ID=your_morrisons_role_id_here
PREMIUM_ROLE_ID=your_premium_role_id_here
```

### Getting Your Owner ID
1. Enable Developer Mode in Discord (Settings > Advanced > Developer Mode)
2. Right-click on your username in any Discord server
3. Select "Copy User ID"
4. Paste the ID as the `OWNER_ID` value in your `.env` file

---

## 🎯 Usage Examples

### Setting Up Admin Access
1. Add your Discord user ID to `.env` as `OWNER_ID`
2. Restart the bot to load the new environment variable
3. Type `!adminpanel` in any channel where the bot has access
4. Use the interactive buttons to navigate different admin features

### Managing Keys
1. Use `!adminpanel` to open the admin panel
2. Click "🔑 Key Management" 
3. Select "🆕 Generate Keys" to create new access keys
4. Choose store type and duration through the modal interface
5. Keys are automatically generated with proper prefixes (SB-, AD-, MR-, PM-)

### Monitoring System Health
1. Open admin panel with `!adminpanel`
2. Click "⚙️ System Info" for runtime metrics
3. Use "🗃️ Database" to check database health
4. Monitor "📊 Statistics" for usage analytics

---

## 🚨 Troubleshooting

### Admin Panel Won't Open
- **Check OWNER_ID**: Ensure your Discord user ID is correctly set in `.env`
- **Restart Bot**: Environment changes require bot restart
- **Check Permissions**: Bot needs message send permissions in the channel

### Key Generation Issues
- **Database Connection**: Ensure SQLite databases are accessible
- **Disk Space**: Check available storage for database operations
- **Permissions**: Verify bot has necessary Discord permissions

### Statistics Not Loading
- **Database Access**: Check database file permissions
- **Memory Issues**: Monitor bot memory usage and restart if needed
- **Query Timeouts**: Large databases may need optimization

---

## 🛡️ Best Practices

### Security
- **Protect OWNER_ID**: Never share your Discord user ID publicly
- **Regular Backups**: Use database backup features regularly
- **Monitor Access**: Review admin panel usage logs
- **Update Environment**: Keep environment variables secure

### Performance  
- **Regular Cleanup**: Use cleanup tools to maintain performance
- **Monitor Memory**: Check system info regularly for memory usage
- **Database Optimization**: Run vacuum operations periodically
- **Log Management**: Clear old logs to save disk space

### User Management
- **Fair Access**: Monitor key distribution across users
- **Abuse Prevention**: Use ban features for misuse
- **Privacy Compliance**: Respect user privacy in data handling
- **Support Quality**: Use admin tools to provide better user support

---

## 📞 Support

### Getting Help
- Check bot logs for error messages
- Use system information panel for diagnostic data
- Monitor database health for storage issues
- Review user statistics for usage patterns

### Reporting Issues
- Include system information from admin panel
- Provide relevant log entries
- Describe steps to reproduce the issue
- Include environment configuration (without sensitive data)

---

**Made with ❤️ for comprehensive bot administration**