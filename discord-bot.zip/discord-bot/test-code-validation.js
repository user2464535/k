// Test the code format validation regex
console.log('🧪 Testing Code Format Validation\n');

const validationRegex = /^[A-Z]{2}-[A-Z0-9]{4}-[A-Z0-9]{6}$/;

// Test cases
const testCodes = [
  // Valid codes
  'SB-ABCD-EFGH23', // Sainsburys
  'AD-1234-WXYZ89', // ASDA
  'MR-TEST-ABC123', // Morrisons
  'PM-PREM-IUMKEY', // Premium
  
  // Invalid codes (old format)
  'ABCD-EFGH-IJKL', // Old 4-4-4 format
  'TEST-1234-5678', // Old 4-4-4 format
  
  // Invalid codes (wrong format)
  'SB-ABC-DEFGH2', // Too short first part
  'SB-ABCDE-FGH23', // Too long first part
  'SB-ABCD-EFG23', // Too short second part
  'SB-ABCD-EFGH234', // Too long second part
  'S-ABCD-EFGH23', // Missing prefix letter
  'SBB-ABCD-EFGH23', // Too long prefix
];

testCodes.forEach(code => {
  const isValid = validationRegex.test(code);
  const status = isValid ? '✅ Valid' : '❌ Invalid';
  console.log(`${status}: ${code}`);
});

console.log('\n🎯 The regex now matches the actual key generation pattern:');
console.log('   PREFIX-XXXX-XXXXXX (e.g., SB-ABCD-EFGH23)');
console.log('\n📋 Valid prefixes:');
console.log('   SB- = Sainsburys');
console.log('   AD- = ASDA'); 
console.log('   MR- = Morrisons');
console.log('   PM- = Premium');