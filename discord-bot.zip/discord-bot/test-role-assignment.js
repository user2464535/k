// Test script to verify role assignment logic
const { Role } = require('discord.js');

// Mock role objects
const mockRoles = [
  { id: '1', name: 'Sainsburys Access' },
  { id: '2', name: 'ASDA Access' }, 
  { id: '3', name: 'Morrisons Access' },
  { id: '4', name: 'Premium Access' }
];

// Mock guild with roles
const mockGuild = {
  roles: {
    cache: {
      find: (predicate) => mockRoles.find(predicate)
    }
  }
};

// Test the role assignment logic
function testRoleAssignment(storeType) {
  console.log(`\n🧪 Testing role assignment for store type: ${storeType}`);
  
  let rolesToAdd = [];
  
  if (storeType === 'Premium') {
    // Premium users get access to all stores
    const sainsburysRole = mockGuild.roles.cache.find(role => role.name === 'Sainsburys Access');
    const asdaRole = mockGuild.roles.cache.find(role => role.name === 'ASDA Access');
    const morrisonsRole = mockGuild.roles.cache.find(role => role.name === 'Morrisons Access');
    const premiumRole = mockGuild.roles.cache.find(role => role.name === 'Premium Access');
    
    if (sainsburysRole) rolesToAdd.push(sainsburysRole);
    if (asdaRole) rolesToAdd.push(asdaRole);
    if (morrisonsRole) rolesToAdd.push(morrisonsRole);
    if (premiumRole) rolesToAdd.push(premiumRole);
  } else {
    // Store-specific access
    const storeRole = mockGuild.roles.cache.find(role => role.name === `${storeType} Access`);
    if (storeRole) {
      rolesToAdd.push(storeRole);
    }
  }
  
  console.log(`✅ Roles to add: ${rolesToAdd.map(r => r.name).join(', ')}`);
  return rolesToAdd;
}

// Test all store types
testRoleAssignment('Sainsburys');
testRoleAssignment('ASDA');
testRoleAssignment('Morrisons');
testRoleAssignment('Premium');

console.log('\n🎉 All role assignment tests completed successfully!');