// Initialize and test the redeem system database
const { RedeemSystem } = require('./src/simple-redeem-system');

async function initAndTest() {
  try {
    console.log('🚀 Initializing redeem system...');
    await RedeemSystem.init();
    console.log('✅ Redeem system initialized successfully!');
    
    // Now test the database schema
    console.log('\n🔍 Testing database operations...');
    
    // Test generating a key
    const testKey = await RedeemSystem.generateKey(5, 'test-user', 'test-guild', 'sainsburys');
    console.log('✅ Test key generated:', testKey.code);
    
    // Test getting all keys
    const allKeys = await new Promise((resolve, reject) => {
      RedeemSystem.getAllKeys('test-guild', (keys) => {
        resolve(keys);
      }, (error) => {
        reject(error);
      });
    });
    
    console.log('✅ Retrieved keys:', allKeys.length);
    console.log('\n🎉 All database tests passed!');
    
  } catch (error) {
    console.error('❌ Error during initialization:', error);
  }
}

initAndTest();