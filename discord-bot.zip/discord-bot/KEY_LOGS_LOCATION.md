# 📋 Key Logs and Storage Locations

## 🗃️ Where Key Data Is Stored

### 1. **Database Files** (Primary Storage)
- **Location**: `/Users/sahinmehmet/Downloads/BarcodeStudio 3/discord-bot/`
- **Files**:
  - `redeem-keys.db` - All generated keys and their status
  - `barcodes.db` - Barcode generation history
  - `redeem-keys.db.backup` - Backup of key database

### 2. **Console Logs** (Runtime)
- **Location**: Terminal output when bot is running
- **Contains**: Real-time key generation, redemption, and role assignment logs
- **Examples**:
  ```
  🔍 Processing redemption for username: premium access
  ✅ Added roles to username: Sainsburys Access, ASDA Access
  ⚠️ No matching roles found for premium in Server Name
  ```

### 3. **Discord Channel Logs** (Optional)
- **Location**: Discord channels (if configured)
- **Channels**:
  - `#barcode-log` - General bot activities
  - `#sainsburys-log` - Sainsburys-specific logs
  - `#asda-log` - ASDA-specific logs  
  - `#morrisons-log` - Morrisons-specific logs

## 🔍 How to View Key Information

### Method 1: Admin Panel (Recommended)
```
!adminpanel
```
- Click "🔑 Key Management"
- View all generated keys and their status
- See redemption statistics
- Monitor active subscriptions

### Method 2: Direct Database Query
```bash
# Navigate to bot directory
cd "/Users/sahinmehmet/Downloads/BarcodeStudio 3/discord-bot"

# View all keys
sqlite3 redeem-keys.db "SELECT * FROM redeem_keys;"

# View active subscriptions
sqlite3 redeem-keys.db "SELECT * FROM user_subscriptions WHERE expires_at > datetime('now');"

# View key statistics
sqlite3 redeem-keys.db "SELECT store_type, COUNT(*) as total, SUM(CASE WHEN used = TRUE THEN 1 ELSE 0 END) as used FROM redeem_keys GROUP BY store_type;"
```

### Method 3: Slash Commands
```
/keystats    - View key statistics (Owner only)
/timeleft    - Check your remaining access time
```

## 📊 Key Database Schema

### `redeem_keys` Table
```sql
- code TEXT PRIMARY KEY           -- The actual key (e.g., SB-ABCD-EFGH23)
- duration INTEGER NOT NULL       -- Duration in days (1, 5, 10, 31)
- store_type TEXT NOT NULL        -- 'sainsburys', 'asda', 'morrisons', 'premium'
- created_by TEXT NOT NULL        -- User ID who created the key
- guild_id TEXT NOT NULL          -- Discord server ID
- used BOOLEAN DEFAULT FALSE      -- Whether key has been redeemed
- used_by TEXT                    -- User ID who redeemed it
- used_at DATETIME               -- When it was redeemed
- created_at DATETIME            -- When it was created
```

### `user_subscriptions` Table
```sql
- user_id TEXT NOT NULL          -- Discord user ID
- guild_id TEXT NOT NULL         -- Discord server ID  
- store_type TEXT NOT NULL       -- Access type granted
- expires_at DATETIME NOT NULL   -- When access expires
- created_at DATETIME           -- When subscription started
- redeemed_with TEXT            -- Which key code was used
- redeemed_at DATETIME          -- When redemption occurred
```

## 🔧 Quick Key Lookup Commands

### View All Keys (SQLite Command)
```bash
sqlite3 redeem-keys.db "
SELECT 
  code, 
  store_type, 
  duration || ' days' as duration,
  CASE WHEN used THEN 'USED' ELSE 'AVAILABLE' END as status,
  created_at,
  used_by,
  used_at 
FROM redeem_keys 
ORDER BY created_at DESC;
"
```

### View Active Users with Access
```bash
sqlite3 redeem-keys.db "
SELECT 
  user_id,
  store_type, 
  expires_at,
  redeemed_with 
FROM user_subscriptions 
WHERE expires_at > datetime('now') 
ORDER BY expires_at;
"
```

### View Key Usage Statistics
```bash
sqlite3 redeem-keys.db "
SELECT 
  store_type,
  COUNT(*) as total_keys,
  SUM(CASE WHEN used = TRUE THEN 1 ELSE 0 END) as used_keys,
  COUNT(*) - SUM(CASE WHEN used = TRUE THEN 1 ELSE 0 END) as available_keys,
  ROUND(SUM(CASE WHEN used = TRUE THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) || '%' as usage_rate
FROM redeem_keys 
GROUP BY store_type;
"
```

## 📱 Real-Time Monitoring

### Console Output Monitoring
When the bot is running, watch for these log patterns:
```
🔍 Processing redemption for [username]: [store_type] access
✅ Added roles to [username]: [role names]
⚠️ No matching roles found for [store_type]
```

### Discord Channel Setup (Optional)
Create these channels for automatic logging:
- `#barcode-log` - General activities
- `#sainsburys-log` - Sainsbury's specific
- `#asda-log` - ASDA specific  
- `#morrisons-log` - Morrisons specific

## 🎯 Most Useful Methods

1. **For Quick Overview**: Use `!adminpanel` → "🔑 Key Management"
2. **For Detailed Analysis**: Query the database directly with SQLite
3. **For Real-Time Monitoring**: Watch console output while bot runs
4. **For User Support**: Use `/timeleft` to help users check their access

The key information is primarily stored in the SQLite database files, with real-time logging to console and optional Discord channel logging!