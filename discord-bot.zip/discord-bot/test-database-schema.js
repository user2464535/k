// Test database schema to ensure store_type column exists
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const db = new sqlite3.Database(path.join(__dirname, '../redeem-keys.db'));

console.log('🔍 Testing database schema...\n');

// Test 1: Check if store_type column exists in redeem_keys table
db.all("PRAGMA table_info(redeem_keys)", (err, rows) => {
  if (err) {
    console.error('❌ Error getting table info:', err);
    return;
  }
  
  console.log('📋 Redeem Keys Table Schema:');
  rows.forEach(column => {
    console.log(`  - ${column.name}: ${column.type} ${column.notnull ? '(NOT NULL)' : ''} ${column.dflt_value ? `DEFAULT ${column.dflt_value}` : ''}`);
  });
  
  const hasStoreType = rows.some(column => column.name === 'store_type');
  console.log(`\n✅ store_type column exists: ${hasStoreType ? '✓' : '❌'}`);
  
  // Test 2: Check user_subscriptions table
  db.all("PRAGMA table_info(user_subscriptions)", (err, rows) => {
    if (err) {
      console.error('❌ Error getting user_subscriptions info:', err);
      return;
    }
    
    console.log('\n📋 User Subscriptions Table Schema:');
    rows.forEach(column => {
      console.log(`  - ${column.name}: ${column.type} ${column.notnull ? '(NOT NULL)' : ''} ${column.dflt_value ? `DEFAULT ${column.dflt_value}` : ''}`);
    });
    
    const hasStoreType = rows.some(column => column.name === 'store_type');
    console.log(`\n✅ store_type column exists: ${hasStoreType ? '✓' : '❌'}`);
    
    // Test 3: Try a simple SELECT to verify the tables work
    db.get("SELECT COUNT(*) as count FROM redeem_keys", (err, row) => {
      if (err) {
        console.error('❌ Error querying redeem_keys:', err);
      } else {
        console.log(`\n📊 Total keys in database: ${row.count}`);
      }
      
      console.log('\n🎉 Database schema test completed!');
      db.close();
    });
  });
});