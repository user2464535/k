import { generateLocalBarcode } from './src/local-barcode-generator';
import * as fs from 'fs';

console.log('🧪 Testing Code 128 Barcode Generation...\n');

// Test with a simple barcode
const result = generateLocalBarcode('sainsburys', '1234567890123', 5.99);

console.log('✅ Generated Code 128 barcode successfully!');
console.log(`Generated code: ${result.generated}`);
console.log(`Image buffer size: ${result.imageBuffer.length} bytes`);

// Save the image
fs.writeFileSync('test-code128.png', result.imageBuffer);
console.log('📁 Saved as test-code128.png');

console.log('\n🔍 Visual representation:');
console.log(result.visualBarcode);

console.log('\n💡 The generated PNG file contains a Code 128 linear barcode (horizontal bars)');
console.log('💡 NOT a QR code (square pattern)');
console.log('💡 Open test-code128.png to verify it shows horizontal black bars');