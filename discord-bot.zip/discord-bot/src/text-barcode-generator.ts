import { generateSainsburysBarcode, generateAsdaBarcode, generateMorrisonsBarcode } from './barcode-utils';
import { BarcodeApiService } from './barcode-api-service';

export interface BarcodeResult {
  original: string;
  generated: string;
  type: 'sainsburys' | 'asda' | 'morrisons';
  price: number;
  visualBarcode: string;
  barcodeImageUrl: string;
  fallbackUrls: string[];
}

export function generateBarcodeText(type: 'sainsburys' | 'asda' | 'morrisons', barcode: string, price: number): BarcodeResult {
  let generated: string;

  switch (type) {
    case 'sainsburys':
      generated = generateSainsburysBarcode(barcode, price);
      break;
    case 'asda':
      generated = generateAsdaBarcode(barcode, price);
      break;
    case 'morrisons':
      generated = generateMorrisonsBarcode(barcode, price);
      break;
    default:
      throw new Error('Invalid barcode type');
  }

  // Create simple visual barcode representation
  const visualBarcode = createVisualBarcode();
  
  // Generate Code 128 barcode image URL using enhanced API service
  const barcodeImageUrl = BarcodeApiService.generateBarcodeImageUrl(generated, 'quickchart', { 
    width: 350, 
    height: 100, 
    format: 'code128' 
  });
  const fallbackUrls = BarcodeApiService.getFallbackUrls(generated, 'quickchart');

  return {
    original: barcode,
    generated,
    type,
    price,
    visualBarcode,
    barcodeImageUrl,
    fallbackUrls
  };
}

function createVisualBarcode(): string {
  // Create a simple visual barcode without showing actual numbers
  let visualBarcode = '';
  
  // Create a generic barcode pattern
  visualBarcode += '```\n';
  visualBarcode += '▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄\n';
  visualBarcode += '█ ▌█ ▌ █▌▌█ ▌█▌ ▌█ ▌▌█▌█ ▌ █▌█ ▌▌█▌ █▌█ ▌ █ █\n';
  visualBarcode += '█ ▌█ ▌ █▌▌█ ▌█▌ ▌█ ▌▌█▌█ ▌ █▌█ ▌▌█▌ █▌█ ▌ █ █\n';
  visualBarcode += '█ ▌█ ▌ █▌▌█ ▌█▌ ▌█ ▌▌█▌█ ▌ █▌█ ▌▌█▌ █▌█ ▌ █ █\n';
  visualBarcode += '█ ▌█ ▌ █▌▌█ ▌█▌ ▌█ ▌▌█▌█ ▌ █▌█ ▌▌█▌ █▌█ ▌ █ █\n';
  visualBarcode += '█ ▌█ ▌ █▌▌█ ▌█▌ ▌█ ▌▌█▌█ ▌ █▌█ ▌▌█▌ █▌█ ▌ █ █\n';
  visualBarcode += '▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\n';
  visualBarcode += '```';
  
  return visualBarcode;
}

// Legacy function - now using BarcodeApiService
// Keep for backwards compatibility
function generateBarcodeImageUrl(barcodeData: string): string {
  return BarcodeApiService.generateBarcodeImageUrl(barcodeData, 'quickchart', { format: 'code128' });
}

export function calculateDiscount(originalPrice: number, discountPercent: number = 65): number {
  const discountedPrice = originalPrice * (1 - discountPercent / 100);
  // Round to nearest 50p
  return Math.round(discountedPrice * 2) / 2;
}

export function validatePrice(price: number, type: 'sainsburys' | 'asda' | 'morrisons'): string | null {
  if (price <= 0) return 'Price must be greater than 0';
  if (price > 999.99) return 'Price must be less than £1000';
  
  switch (type) {
    case 'sainsburys':
      if (price > 999.99) return 'Sainsbury\'s format supports prices up to £999.99';
      break;
    case 'asda':
      if (price > 9.99) return 'ASDA format supports prices up to £9.99';
      break;
    case 'morrisons':
      // No specific limit for Morrisons
      break;
  }
  
  return null;
}

export function validateBarcode(barcode: string): string | null {
  const cleaned = barcode.replace(/\D/g, '');
  if (cleaned.length < 8) return 'Barcode must be at least 8 digits';
  if (cleaned.length > 14) return 'Barcode must be at most 14 digits';
  return null;
}