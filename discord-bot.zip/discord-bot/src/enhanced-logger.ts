import { TextChannel, EmbedBuilder, User } from 'discord.js';

interface ActionLog {
  userId: string;
  username: string;
  action: string;
  timestamp: Date;
  details?: any;
}

export class Logger {
  private static maskUsername(username: string): string {
    // Replace everything after the first character with *****
    return username.length > 1 ? username[0] + '*****' : '*****';
  }

  static async logBarcodeGeneration(
    channel: TextChannel,
    user: User,
    barcodeType: string,
    originalBarcode: string,
    price: number
  ) {
    const maskedUsername = this.maskUsername(user.username);
    
    const embed = new EmbedBuilder()
      .setColor(this.getColorForType(barcodeType))
      .setTitle('🔢 Barcode Generated')
      .addFields(
        { name: 'User', value: maskedUsername, inline: true },
        { name: 'Type', value: barcodeType.toUpperCase(), inline: true },
        { name: 'Price', value: `£${price.toFixed(2)}`, inline: true },
        { name: 'Original Barcode', value: `\`${originalBarcode}\``, inline: false }
      )
      .setTimestamp()
      .setFooter({ text: 'Barcode Studio Bot' });

    try {
      await channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Failed to log action:', error);
    }
  }

  static async logError(
    channel: TextChannel,
    user: User,
    error: string,
    command?: string
  ) {
    const maskedUsername = this.maskUsername(user.username);
    
    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle('❌ Error Occurred')
      .addFields(
        { name: 'User', value: maskedUsername, inline: true },
        { name: 'Command', value: command || 'Unknown', inline: true },
        { name: 'Error', value: error, inline: false }
      )
      .setTimestamp()
      .setFooter({ text: 'Barcode Studio Bot' });

    try {
      await channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Failed to log error:', error);
    }
  }

  static async logStats(
    channel: TextChannel,
    user: User,
    statsType: 'user' | 'guild' | 'leaderboard'
  ) {
    const maskedUsername = this.maskUsername(user.username);
    
    const embed = new EmbedBuilder()
      .setColor(0x0099ff)
      .setTitle('📊 Statistics Requested')
      .addFields(
        { name: 'User', value: maskedUsername, inline: true },
        { name: 'Stats Type', value: statsType, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: 'Barcode Studio Bot' });

    try {
      await channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Failed to log stats request:', error);
    }
  }

  static async logHelp(
    channel: TextChannel,
    user: User,
    helpType?: string
  ) {
    const maskedUsername = this.maskUsername(user.username);
    
    const embed = new EmbedBuilder()
      .setColor(0x00ff00)
      .setTitle('❓ Help Requested')
      .addFields(
        { name: 'User', value: maskedUsername, inline: true },
        { name: 'Help Type', value: helpType || 'General', inline: true }
      )
      .setTimestamp()
      .setFooter({ text: 'Barcode Studio Bot' });

    try {
      await channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Failed to log help request:', error);
    }
  }

  static getColorForType(type: string): number {
    switch (type.toLowerCase()) {
      case 'sainsburys': return 0xf97316;
      case 'asda': return 0x00A651;
      case 'morrisons': return 0x0066cc;
      default: return 0x000000;
    }
  }

  static getLogChannel(guild: any, type: string): TextChannel | null {
    const logChannelNames = {
      'sainsburys': 'sainsburys-log',
      'asda': 'asda-log',
      'morrisons': 'morrisons-log',
      'general': 'barcode-log'
    };

    const channelName = logChannelNames[type as keyof typeof logChannelNames] || logChannelNames.general;
    return guild.channels.cache.find((c: any) => c.name === channelName && c.isTextBased()) as TextChannel || null;
  }
}