import dotenv from 'dotenv';
dotenv.config();

import { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder, AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, Role, MessageFlags } from 'discord.js';
import { generateLocalBarcode, calculateDiscount, validatePrice, validateBarcode } from './local-barcode-generator';
import { generateWaitroseBarcode } from './barcode-utils';
import { createCanvas } from 'canvas';
import JsBarcode from 'jsbarcode';
import { Logger } from './enhanced-logger';
import { database, BarcodeRecord } from './database';
import { ScheduledTasks } from './scheduler';
import { RedeemSystem } from './simple-redeem-system';

const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds, 
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ] 
});

// Generic barcode image generator
async function generateBarcodeImage(barcode: string): Promise<Buffer> {
  const canvas = createCanvas(400, 120);
  
  JsBarcode(canvas, barcode, {
    format: "CODE128",
    width: 2,
    height: 80,
    displayValue: false,
    margin: 10,
    background: "#ffffff",
    lineColor: "#000000"
  });

  return canvas.toBuffer('image/png');
}

const commands = [
  new SlashCommandBuilder()
    .setName('sainsburys')
    .setDescription('Generate a Sainsbury\'s barcode')
    .addStringOption((opt: any) => opt.setName('barcode').setDescription('Original barcode').setRequired(true))
    .addNumberOption((opt: any) => opt.setName('price').setDescription('Price (£)').setRequired(true))
    .addBooleanOption((opt: any) => opt.setName('calculate-discount').setDescription('Calculate 65% discount').setRequired(false)),
    
  new SlashCommandBuilder()
    .setName('asda')
    .setDescription('Generate an ASDA barcode')
    .addStringOption((opt: any) => opt.setName('barcode').setDescription('Original barcode').setRequired(true))
    .addNumberOption((opt: any) => opt.setName('price').setDescription('Price (£)').setRequired(true))
    .addBooleanOption((opt: any) => opt.setName('calculate-discount').setDescription('Calculate 65% discount').setRequired(false)),
    
  new SlashCommandBuilder()
    .setName('morrisons')
    .setDescription('Generate a Morrisons barcode')
    .addStringOption((opt: any) => opt.setName('barcode').setDescription('Original barcode').setRequired(true))
    .addNumberOption((opt: any) => opt.setName('price').setDescription('Price (£)').setRequired(true))
    .addBooleanOption((opt: any) => opt.setName('calculate-discount').setDescription('Calculate 65% discount').setRequired(false)),
    
  new SlashCommandBuilder()
    .setName('waitrose')
    .setDescription('Generate a Waitrose barcode')
    .addStringOption((opt: any) => opt.setName('barcode').setDescription('13-digit item barcode').setRequired(true))
    .addNumberOption((opt: any) => opt.setName('price').setDescription('Price in pence (e.g., 200 for £2.00)').setRequired(true)),
    
  new SlashCommandBuilder()
    .setName('mystats')
    .setDescription('View your barcode generation statistics'),
    
  new SlashCommandBuilder()
    .setName('myhistory')
    .setDescription('View your recent barcode history')
    .addIntegerOption((opt: any) => opt.setName('limit').setDescription('Number of records to show (max 20)').setRequired(false)),
    
  new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the server leaderboard')
    .addIntegerOption((opt: any) => opt.setName('limit').setDescription('Number of users to show (max 25)').setRequired(false)),
    
  new SlashCommandBuilder()
    .setName('serverstats')
    .setDescription('View server-wide statistics'),
    
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Get help with bot commands')
    .addStringOption((opt: any) => opt.setName('topic').setDescription('Specific help topic').setRequired(false)
      .addChoices(
        { name: 'Commands', value: 'commands' },
        { name: 'Permissions', value: 'permissions' },
        { name: 'Barcode Types', value: 'types' },
        { name: 'Pricing', value: 'pricing' }
      )),
      
  new SlashCommandBuilder()
    .setName('calculate')
    .setDescription('Calculate discounted price')
    .addNumberOption((opt: any) => opt.setName('original-price').setDescription('Original price (£)').setRequired(true))
    .addIntegerOption((opt: any) => opt.setName('discount').setDescription('Discount percentage (default 65%)').setRequired(false)),

  // Redeem System Commands
  new SlashCommandBuilder()
    .setName('redeem')
    .setDescription('Redeem a premium access key')
    .addStringOption((opt: any) => opt.setName('code').setDescription('Your redeem code').setRequired(true)),

  new SlashCommandBuilder()
    .setName('generatekeys')
    .setDescription('Generate redeem keys (Owner only)')
    .addIntegerOption((opt: any) => opt.setName('count').setDescription('Number of keys to generate').setRequired(true))
    .addIntegerOption((opt: any) => opt.setName('duration').setDescription('Duration in days').setRequired(true)
      .addChoices(
        { name: '1 Day', value: 1 },
        { name: '5 Days', value: 5 },
        { name: '10 Days', value: 10 },
        { name: '31 Days', value: 31 }
      )),

  new SlashCommandBuilder()
    .setName('keystats')
    .setDescription('View redeem key statistics (Owner only)'),

  new SlashCommandBuilder()
    .setName('setupredeempanel')
    .setDescription('Setup redeem panel in this channel (Owner only)'),

  new SlashCommandBuilder()
    .setName('timeleft')
    .setDescription('Check how much access time you have remaining')
];

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);

async function registerCommands(guildId?: string) {
  try {
    console.log('🔄 Registering slash commands...');
    
    // Register globally for all servers
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID!),
      { body: commands.map(cmd => cmd.toJSON()) }
    );
    
    // Also register for specific guild for immediate availability (if guildId provided)
    if (guildId) {
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID!, guildId),
        { body: commands.map(cmd => cmd.toJSON()) }
      );
      console.log(`✅ Successfully registered slash commands globally and for guild ${guildId}`);
    } else {
      console.log('✅ Successfully registered slash commands globally');
    }
  } catch (error) {
    console.error('❌ Error registering commands:', error);
  }
}

client.once('ready', () => {
  console.log(`✅ Logged in as ${client.user?.tag}`);
  
  // Get the first guild ID for immediate command registration
  const firstGuild = client.guilds.cache.first();
  const guildId = firstGuild?.id;
  
  registerCommands(guildId);
  
  // Initialize redeem system
  RedeemSystem.init().then(() => {
    console.log('✅ Redeem system initialized');
  }).catch(console.error);
  
  // Start scheduled tasks
  const scheduler = new ScheduledTasks(client);
  scheduler.startAllTasks();

  // Check for expired subscriptions every hour
  setInterval(async () => {
    for (const guild of client.guilds.cache.values()) {
      try {
        const expiredUsers = await RedeemSystem.getExpiredUsers(guild.id);
        for (const expiredUser of expiredUsers) {
          const member = await guild.members.fetch(expiredUser.userId).catch(() => null);
          if (member) {
            // Remove specific store role or all if premium
            if (expiredUser.storeType === 'premium') {
              const rolesToRemove = member.roles.cache.filter((role: any) => 
                ['premium', 'sainsburys', 'asda', 'morrisons', 'waitrose'].includes(role.name.toLowerCase())
              );
              await member.roles.remove(rolesToRemove);
            } else {
              const roleToRemove = guild.roles.cache.find((role: any) => 
                role.name.toLowerCase() === expiredUser.storeType
              );
              if (roleToRemove) {
                await member.roles.remove(roleToRemove);
              }
            }
            console.log(`Removed expired ${expiredUser.storeType} role from ${member.user.tag} in ${guild.name}`);
          }
          await RedeemSystem.removeExpiredUser(expiredUser.userId, guild.id, expiredUser.storeType);
        }
      } catch (error) {
        console.error(`Error checking expired users in ${guild.name}:`, error);
      }
    }
  }, 30 * 1000); // Check every 30 seconds for faster expiration handling
});

function hasRoleOrChannel(interaction: any, roleName: string, channelName: string): boolean {
  if (!interaction.isChatInputCommand()) return false;
  const member = interaction.guild?.members.cache.get(interaction.user.id);
  const hasRole = member?.roles.cache.some((role: any) => role.name.toLowerCase() === roleName.toLowerCase());
  const inChannel = interaction.channel && (interaction.channel as any).name?.toLowerCase() === channelName.toLowerCase();
  return Boolean(hasRole || inChannel);
}

// Message handler for !setupredeempanel
client.on('messageCreate', async (message: any) => {
  if (message.author.bot) return;
  
  if (message.content === '!setupredeempanel') {
    // Check if user is server owner
    if (message.author.id !== message.guild.ownerId) {
      await message.reply('❌ Only the server owner can setup redeem panels!');
      return;
    }

    // Delete the command message to keep it clean
    await message.delete().catch(() => {});

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('🎫 Premium Access Portal')
      .setDescription('**Get instant access to premium barcode generation!**\n\n' +
        '🔹 Generate Sainsbury\'s barcodes\n' +
        '🔹 Generate ASDA barcodes\n' +
        '🔹 Generate Morrisons barcodes\n' +
        '🔹 Access discount calculators\n' +
        '🔹 View personal statistics\n\n' +
        '**Click the button below to redeem your access code!**')
      .addFields(
        { name: '⏱️ Available Plans', value: '• **1 Day** - Quick Access\n• **5 Days** - Short Term\n• **10 Days** - Extended Use\n• **31 Days** - Monthly Access', inline: true },
        { name: '🎯 Instant Activation', value: '• Immediate role assignment\n• Automatic expiration\n• Clean barcode generation\n• Professional support', inline: true }
      )
      .setFooter({ text: '🔐 Secure redemption system' })
      .setTimestamp();

    // Create interactive buttons
    const redeemButton = new ButtonBuilder()
      .setCustomId('redeem_code')
      .setLabel('🔑 Redeem Access Code')
      .setStyle(ButtonStyle.Primary);

    const infoButton = new ButtonBuilder()
      .setCustomId('redeem_info')
      .setLabel('ℹ️ How to Get Codes')
      .setStyle(ButtonStyle.Secondary);

    const actionRow = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(redeemButton, infoButton);

    // Owner-only management buttons
    const ownerButtons = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('owner_generate')
          .setLabel('🔧 Generate Keys')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('owner_stats')
          .setLabel('📊 View Statistics')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('owner_keys')
          .setLabel('🗃️ View All Keys')
          .setStyle(ButtonStyle.Secondary)
      );

    await message.channel.send({ 
      embeds: [embed], 
      components: [actionRow, ownerButtons] 
    });
  }

  // New user-focused redeem panel command
  if (message.content === '!setupredeemkeypanel') {
    // Check if user is server owner
    if (message.author.id !== message.guild.ownerId) {
      await message.reply('❌ Only the server owner can setup redeem key panels!');
      return;
    }

    // Delete the command message to keep it clean
    await message.delete().catch(() => {});

    // Enhanced user-focused redeem panel with premium design
    const embed = new EmbedBuilder()
      .setColor('#6366f1')
      .setTitle('✨ Premium Access Portal')
      .setDescription('**🚀 Unlock Exclusive Barcode Generation Features**\n\n' +
        '💎 **What you get with Premium Access:**\n' +
        '🛒 **Sainsbury\'s** - Professional barcode generation\n' +
        '🟢 **ASDA** - Advanced discount calculations\n' +
        '🔵 **Morrisons** - Premium barcode features\n' +
        '🟡 **Waitrose** - Specialized barcode format\n' +
        '⭐ **Premium** - All-in-one access\n\n' +
        '⚡ **Instant activation** • 🛡️ **Secure redemption** • 📱 **Mobile optimized**')
      .addFields(
        { 
          name: '🎯 Quick Actions', 
          value: '• **Redeem Code** - Enter your access key\n• **Get Help** - Learn how to obtain codes\n• **Check Time** - View remaining access time', 
          inline: false 
        },
        { 
          name: '⏰ Duration Options', 
          value: '• **1m** or **1 minute** - Quick testing\n• **1h** or **1 hour** - Short access\n• **1d** or **1 day** - Extended access (1-31 days)\n• **lifetime** - Permanent access', 
          inline: true 
        },
        { 
          name: '🔐 Security Features', 
          value: '• One-time use codes\n• Automatic expiration\n• Role-based permissions\n• Audit logging', 
          inline: true 
        }
      )
      .setFooter({ text: '🎫 Premium Access Portal • Secure & Reliable' })
      .setTimestamp();

    // User action buttons - clean and modern
    const userActionRow = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('redeem_code')
          .setLabel('🔑 Redeem Code')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('check_timeleft')
          .setLabel('⏰ Time Left')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('redeem_info')
          .setLabel('❓ Get Help')
          .setStyle(ButtonStyle.Secondary)
      );

    await message.channel.send({ 
      embeds: [embed], 
      components: [userActionRow] 
    });
  }

  // Admin panel command handler
  if (message.content === '!adminpanel') {
    // Check if user is the bot owner (from environment variable)
    const ownerId = process.env.OWNER_ID;
    if (!ownerId || message.author.id !== ownerId) {
      await message.reply('❌ Only the bot owner can access the admin panel!');
      return;
    }

    // Delete the command message to keep it clean
    await message.delete().catch(() => {});

    // Create comprehensive admin panel
    const embed = new EmbedBuilder()
      .setColor('#ff6b00')
      .setTitle('🛠️ Admin Control Panel')
      .setDescription('**Comprehensive Bot Management Dashboard**\n\n' +
        '📊 **Statistics & Analytics**\n' +
        '🔑 **Key Management System**\n' +
        '👥 **User Management**\n' +
        '🗃️ **Database Operations**\n' +
        '⚙️ **System Monitoring**')
      .addFields(
        { name: '📈 Quick Stats', value: 'View real-time bot statistics', inline: true },
        { name: '🔧 Generate Keys', value: 'Create access keys for users', inline: true },
        { name: '🗂️ Manage Keys', value: 'View and manage all keys', inline: true },
        { name: '👑 User Analytics', value: 'View user activity and subscriptions', inline: true },
        { name: '🏪 Store Statistics', value: 'Store-specific usage analytics', inline: true },
        { name: '🧹 Database Tools', value: 'Cleanup and maintenance tools', inline: true }
      )
      .setFooter({ text: `Admin Panel • Bot Owner: ${message.author.username}` })
      .setTimestamp();

    const adminButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('admin_stats')
          .setLabel('📊 Statistics')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('admin_keys')
          .setLabel('🔑 Key Management')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('admin_users')
          .setLabel('👥 User Management')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('admin_redemptions')
          .setLabel('📜 Redemption History')
          .setStyle(ButtonStyle.Secondary)
      );

    const monitoringButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('admin_subscriptions')
          .setLabel('⏰ Active Subscriptions')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('admin_expired')
          .setLabel('⌛ Expired Users')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('admin_database')
          .setLabel('🗃️ Database Tools')
          .setStyle(ButtonStyle.Secondary)
      );

    const systemButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('admin_system')
          .setLabel('⚙️ System Info')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('admin_cleanup')
          .setLabel('🧹 Cleanup')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('admin_export')
          .setLabel('💾 Export Data')
          .setStyle(ButtonStyle.Secondary)
      );

    await message.channel.send({ 
      embeds: [embed], 
      components: [adminButtons, monitoringButtons, systemButtons] 
    });
  }
});

client.on('interactionCreate', async (interaction: any) => {
  // Handle button interactions
  if (interaction.isButton()) {
    await handleButtonInteraction(interaction);
    return;
  }
  
  // Handle modal submissions
  if (interaction.isModalSubmit()) {
    await handleModalSubmit(interaction);
    return;
  }

  if (!interaction.isChatInputCommand()) return;
  
  const { commandName } = interaction;
  
  try {
    if (['sainsburys', 'asda', 'morrisons'].includes(commandName)) {
      await handleBarcodeCommand(interaction, commandName as 'sainsburys' | 'asda' | 'morrisons');
    } else if (commandName === 'waitrose') {
      await handleWaitroseCommand(interaction);
    } else if (commandName === 'mystats') {
      await handleMyStats(interaction);
    } else if (commandName === 'myhistory') {
      await handleMyHistory(interaction);
    } else if (commandName === 'leaderboard') {
      await handleLeaderboard(interaction);
    } else if (commandName === 'serverstats') {
      await handleServerStats(interaction);
    } else if (commandName === 'help') {
      await handleHelp(interaction);
    } else if (commandName === 'calculate') {
      await handleCalculate(interaction);
    } else if (commandName === 'redeem') {
      await handleRedeem(interaction);
    } else if (commandName === 'generatekeys') {
      await handleGenerateKeys(interaction);
    } else if (commandName === 'keystats') {
      await handleKeyStats(interaction);
    } else if (commandName === 'setupredeempanel') {
      await handleSetupRedeemPanel(interaction);
    } else if (commandName === 'timeleft') {
      await handleTimeLeft(interaction);
    }
  } catch (error) {
    console.error(`Error handling command ${commandName}:`, error);
    
    const errorEmbed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Error')
      .setDescription('An error occurred while processing your command. Please try again later.')
      .setTimestamp();
      
    if (interaction.replied || interaction.deferred) {
      await interaction.editReply({ embeds: [errorEmbed] });
    } else {
      await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
    }
  }
});

async function handleBarcodeCommand(interaction: any, type: 'sainsburys' | 'asda' | 'morrisons') {
  if (!hasRoleOrChannel(interaction, type, type)) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Permission Denied')
      .setDescription(`You need the \`${type}\` role or must be in the \`${type}\` channel to use this command.`)
      .setTimestamp();
      
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const barcode = interaction.options.getString('barcode', true);
  let price = interaction.options.getNumber('price', true);
  const shouldCalculateDiscount = interaction.options.getBoolean('calculate-discount') || false;

  // Validate inputs
  const barcodeError = validateBarcode(barcode);
  if (barcodeError) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Invalid Barcode')
      .setDescription(barcodeError)
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  if (shouldCalculateDiscount) {
    price = calculateDiscount(price);
  }

  const priceError = validatePrice(price, type);
  if (priceError) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Invalid Price')
      .setDescription(priceError)
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  try {
    const result = generateLocalBarcode(type, barcode, price);
    
    // Send confirmation in channel
    const channelEmbed = new EmbedBuilder()
      .setColor(Logger.getColorForType(type) as any)
      .setTitle('✅ Barcode Generated Successfully')
      .setDescription(`Your ${type.charAt(0).toUpperCase() + type.slice(1)} barcode has been generated and sent to your DMs.`)
      .addFields(
        { name: 'Original Barcode', value: `\`${result.original}\``, inline: true },
        { name: 'Price', value: `£${result.price.toFixed(2)}`, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: 'Check your DMs for the full barcode details' });

    await interaction.reply({ embeds: [channelEmbed] });

    // Create detailed DM embed with barcode image
    const dmEmbed = new EmbedBuilder()
      .setColor(Logger.getColorForType(type) as any)
      .setTitle(`🔢 ${type.charAt(0).toUpperCase() + type.slice(1)} Barcode Generated`)
      .setDescription(`Your barcode has been successfully generated.\n\n**Scannable Barcode:**`)
      .addFields(
        { name: '📊 Barcode Details', value: '\u200B', inline: false },
        { name: 'Store Format', value: type.charAt(0).toUpperCase() + type.slice(1), inline: true },
        { name: 'Original Barcode', value: `\`${result.original}\``, inline: true },
        { name: '💰 Price Information', value: '\u200B', inline: false },
        { name: 'Final Price', value: `£${result.price.toFixed(2)}`, inline: true },
        { name: 'Status', value: 'Ready to use', inline: true }
      )
      .setImage('attachment://barcode.png')
      .setTimestamp()
      .setFooter({ 
        text: `Generated in ${interaction.guild.name} • Barcode Studio Bot`,
        iconURL: interaction.guild.iconURL() || undefined
      });

    if (shouldCalculateDiscount) {
      dmEmbed.addFields({ 
        name: '🎯 Discount Applied', 
        value: '65% discount with rounding to nearest 50p', 
        inline: false 
      });
    }

    // Add simple usage instructions
    dmEmbed.addFields({
      name: '📱 Usage Instructions',
      value: 'Present this barcode at checkout. The pricing information is encoded within the barcode.',
      inline: false
    });

    // Create barcode attachment
    const barcodeAttachment = new AttachmentBuilder(result.imageBuffer, { name: 'barcode.png' });

    // Send DM to user
    try {
      await interaction.user.send({ 
        embeds: [dmEmbed],
        files: [barcodeAttachment]
      });
    } catch (dmError) {
      console.error('Failed to send DM to user:', dmError);
      
      // If DM fails, update the channel message with the full details
      const fallbackEmbed = new EmbedBuilder()
        .setColor('#ffaa00')
        .setTitle('⚠️ DM Delivery Failed')
        .setDescription(`Could not send DM. Here are your barcode details:\n\n**Scannable Barcode:**`)
        .addFields(
          { name: 'Original Barcode', value: `\`${result.original}\``, inline: true },
          { name: 'Price', value: `£${result.price.toFixed(2)}`, inline: true },
          { name: 'Status', value: 'Ready to use', inline: true }
        )
        .setImage('attachment://barcode.png')
        .setTimestamp()
        .setFooter({ text: 'Enable DMs to receive detailed barcode information privately' });

      if (shouldCalculateDiscount) {
        fallbackEmbed.addFields({ name: 'Discount Applied', value: '65% off, rounded to nearest 50p', inline: false });
      }

      await interaction.followUp({ 
        embeds: [fallbackEmbed], 
        files: [barcodeAttachment],
        ephemeral: true 
      });
    }

    // Save to database
    const record: BarcodeRecord = {
      userId: interaction.user.id,
      username: interaction.user.username,
      guildId: interaction.guild.id,
      barcodeType: type,
      originalBarcode: result.original,
      generatedBarcode: result.generated,
      price: result.price,
      timestamp: new Date().toISOString()
    };
    
    await database.saveBarcode(record);

    // Log action
    const logChannel = Logger.getLogChannel(interaction.guild, type);
    if (logChannel) {
      await Logger.logBarcodeGeneration(logChannel, interaction.user, type, barcode, price);
    }

  } catch (error) {
    console.error('Error generating barcode:', error);
    throw error;
  }
}

async function handleWaitroseCommand(interaction: any) {
  if (!hasRoleOrChannel(interaction, 'waitrose', 'waitrose')) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Permission Denied')
      .setDescription(`You need the \`waitrose\` role or must be in the \`waitrose\` channel to use this command.`)
      .setTimestamp();
      
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const barcode = interaction.options.getString('barcode', true);
  const priceInPence = interaction.options.getNumber('price', true);

  // Validate 13-digit barcode
  const cleanedBarcode = barcode.replace(/\D/g, '');
  if (cleanedBarcode.length !== 13) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Invalid Barcode')
      .setDescription('Waitrose requires exactly 13 digits for the item barcode.')
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // Validate price (must be positive integer for pence)
  if (!Number.isInteger(priceInPence) || priceInPence < 1 || priceInPence > 99999) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Invalid Price')
      .setDescription('Price must be a whole number between 1 and 99999 pence (e.g., 250 for £2.50).')
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  try {
    await interaction.deferReply({ ephemeral: true });
    
    const generatedBarcode = generateWaitroseBarcode(cleanedBarcode, priceInPence);
    
    // Convert pence to pounds for display
    const priceInPounds = priceInPence / 100;

    // Generate barcode image
    const barcodeBuffer = await generateBarcodeImage(generatedBarcode);
    const barcodeAttachment = new AttachmentBuilder(barcodeBuffer, { name: 'barcode.png' });

    // Send confirmation in channel
    const channelEmbed = new EmbedBuilder()
      .setColor('#228B22')
      .setTitle('🛒 Waitrose Barcode Generated')
      .setDescription(`**Original:** ${cleanedBarcode}\n**Generated:** ${generatedBarcode}\n**Price:** £${priceInPounds.toFixed(2)} (${priceInPence}p)`)
      .setTimestamp();

    await interaction.editReply({ 
      embeds: [channelEmbed]
    });

    // Try to send detailed barcode via DM
    try {
      const dmEmbed = new EmbedBuilder()
        .setColor('#228B22')
        .setTitle('🛒 Your Waitrose Barcode')
        .setDescription('**Scannable Barcode Image:**')
        .addFields(
          { name: 'Original Barcode', value: `\`${cleanedBarcode}\``, inline: true },
          { name: 'Generated Barcode', value: `\`${generatedBarcode}\``, inline: true },
          { name: 'Price', value: `£${priceInPounds.toFixed(2)} (${priceInPence}p)`, inline: true },
          { name: 'Format', value: '10 + 13-digit barcode + 00 + price', inline: false }
        )
        .setImage('attachment://barcode.png')
        .setTimestamp()
        .setFooter({ text: 'Waitrose Barcode Generator' });

      await interaction.user.send({ 
        embeds: [dmEmbed], 
        files: [barcodeAttachment] 
      });
    } catch (dmError) {
      // If DM fails, update the channel message with the full details
      const fallbackEmbed = new EmbedBuilder()
        .setColor('#ffaa00')
        .setTitle('⚠️ DM Delivery Failed')
        .setDescription(`Could not send DM. Here are your barcode details:\n\n**Scannable Barcode:**`)
        .addFields(
          { name: 'Original Barcode', value: `\`${cleanedBarcode}\``, inline: true },
          { name: 'Generated Barcode', value: `\`${generatedBarcode}\``, inline: true },
          { name: 'Price', value: `£${priceInPounds.toFixed(2)} (${priceInPence}p)`, inline: true }
        )
        .setImage('attachment://barcode.png')
        .setTimestamp()
        .setFooter({ text: 'Enable DMs to receive detailed barcode information privately' });

      await interaction.followUp({ 
        embeds: [fallbackEmbed], 
        files: [barcodeAttachment],
        ephemeral: true 
      });
    }

    // Save to database
    const record: BarcodeRecord = {
      userId: interaction.user.id,
      username: interaction.user.username,
      guildId: interaction.guild.id,
      barcodeType: 'waitrose',
      originalBarcode: cleanedBarcode,
      generatedBarcode: generatedBarcode,
      price: priceInPounds,
      timestamp: new Date().toISOString()
    };
    
    await database.saveBarcode(record);

    // Log action
    const logChannel = Logger.getLogChannel(interaction.guild, 'waitrose');
    if (logChannel) {
      await Logger.logBarcodeGeneration(logChannel, interaction.user, 'waitrose', cleanedBarcode, priceInPounds);
    }

  } catch (error) {
    console.error('Error generating Waitrose barcode:', error);
    throw error;
  }
}

async function handleMyStats(interaction: any) {
  const stats = await database.getUserStats(interaction.user.id, interaction.guild.id);
  
  if (!stats) {
    const embed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('📊 Your Statistics')
      .setDescription('You haven\'t generated any barcodes yet! Use `/sainsburys`, `/asda`, `/morrisons`, or `/waitrose` to get started.')
      .setTimestamp();
      
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#0099ff')
    .setTitle('📊 Your Statistics')
    .addFields(
      { name: 'Total Barcodes', value: stats.totalBarcodes.toString(), inline: true },
      { name: 'Sainsbury\'s', value: stats.sainsburysCount.toString(), inline: true },
      { name: 'ASDA', value: stats.asdaCount.toString(), inline: true },
      { name: 'Morrisons', value: stats.morrisonsCount.toString(), inline: true },
      { name: 'Waitrose', value: stats.waitroseCount.toString(), inline: true },
      { name: 'Last Used', value: new Date(stats.lastUsed).toLocaleDateString(), inline: true }
    )
    .setTimestamp()
    .setFooter({ text: 'Barcode Studio Bot' });

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleMyHistory(interaction: any) {
  const limit = Math.min(interaction.options.getInteger('limit') || 10, 20);
  const history = await database.getUserHistory(interaction.user.id, interaction.guild.id, limit);
  
  if (history.length === 0) {
    const embed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('📋 Your History')
      .setDescription('No barcode history found.')
      .setTimestamp();
      
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const historyText = history
    .map((record, index) => 
      `${index + 1}. **${record.barcodeType.toUpperCase()}** - \`${record.originalBarcode}\` → \`${record.generatedBarcode}\` (£${record.price.toFixed(2)}) - ${new Date(record.timestamp).toLocaleDateString()}`
    )
    .join('\n');

  const embed = new EmbedBuilder()
    .setColor('#0099ff')
    .setTitle('📋 Your Recent History')
    .setDescription(historyText)
    .setTimestamp()
    .setFooter({ text: `Showing last ${history.length} records` });

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleLeaderboard(interaction: any) {
  const limit = Math.min(interaction.options.getInteger('limit') || 10, 25);
  const topUsers = await database.getTopUsers(interaction.guild.id, limit);
  
  if (topUsers.length === 0) {
    const embed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('🏆 Leaderboard')
      .setDescription('No users found.')
      .setTimestamp();
      
    await interaction.reply({ embeds: [embed] });
    return;
  }

  const leaderboardText = topUsers
    .map((user, index) => {
      const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
      return `${medal} ${user.username[0]}***** - **${user.totalBarcodes}** barcodes`;
    })
    .join('\n');

  const embed = new EmbedBuilder()
    .setColor('#ffd700')
    .setTitle('🏆 Server Leaderboard')
    .setDescription(leaderboardText)
    .setTimestamp()
    .setFooter({ text: `Top ${topUsers.length} users` });

  await interaction.reply({ embeds: [embed] });
}

async function handleServerStats(interaction: any) {
  const stats = await database.getGuildStats(interaction.guild.id);
  
  const embed = new EmbedBuilder()
    .setColor('#00ff00')
    .setTitle('📊 Server Statistics')
    .addFields(
      { name: 'Total Barcodes', value: stats.totalBarcodes?.toString() || '0', inline: true },
      { name: 'Active Users', value: stats.uniqueUsers?.toString() || '0', inline: true },
      { name: 'Average Price', value: `£${(stats.avgPrice || 0).toFixed(2)}`, inline: true },
      { name: 'Sainsbury\'s', value: stats.sainsburysCount?.toString() || '0', inline: true },
      { name: 'ASDA', value: stats.asdaCount?.toString() || '0', inline: true },
      { name: 'Morrisons', value: stats.morrisonsCount?.toString() || '0', inline: true }
    )
    .setTimestamp()
    .setFooter({ text: 'Barcode Studio Bot' });

  if (stats.lastActivity) {
    embed.addFields({ name: 'Last Activity', value: new Date(stats.lastActivity).toLocaleString(), inline: false });
  }

  await interaction.reply({ embeds: [embed] });
}

async function handleHelp(interaction: any) {
  const topic = interaction.options.getString('topic');
  
  let embed = new EmbedBuilder()
    .setColor('#00ff00')
    .setTitle('❓ Barcode Studio Bot Help')
    .setTimestamp()
    .setFooter({ text: 'Barcode Studio Bot' });

  switch (topic) {
    case 'commands':
      embed.setDescription('**Available Commands:**')
        .addFields(
          { name: '/sainsburys', value: 'Generate Sainsbury\'s barcode', inline: false },
          { name: '/asda', value: 'Generate ASDA barcode', inline: false },
          { name: '/morrisons', value: 'Generate Morrisons barcode', inline: false },
          { name: '/mystats', value: 'View your statistics', inline: false },
          { name: '/myhistory', value: 'View your history', inline: false },
          { name: '/leaderboard', value: 'View server leaderboard', inline: false },
          { name: '/serverstats', value: 'View server statistics', inline: false },
          { name: '/calculate', value: 'Calculate discounted price', inline: false }
        );
      break;
      
    case 'permissions':
      embed.setDescription('**Permission System:**')
        .addFields(
          { name: 'Role-based Access', value: 'You need the corresponding role (`sainsburys`, `asda`, `morrisons`, `waitrose`) to use each command', inline: false },
          { name: 'Channel-based Access', value: 'Alternatively, you can use commands in the corresponding channels', inline: false },
          { name: 'Logging', value: 'Actions are logged in `{store}-log` channels with masked usernames', inline: false }
        );
      break;
      
    case 'types':
      embed.setDescription('**Barcode Types:**')
        .addFields(
          { name: 'Sainsbury\'s', value: 'Format: 91 + 13-digit barcode + 6-digit price + checksum', inline: false },
          { name: 'ASDA', value: 'Format: 330 + 13-digit barcode + 000 + 2-digit price + 2056 + luhn checksum', inline: false },
          { name: 'Morrisons', value: 'Format: 92 + 13-digit barcode + 00003{price}00027', inline: false }
        );
      break;
      
    case 'pricing':
      embed.setDescription('**Pricing Information:**')
        .addFields(
          { name: 'Price Limits', value: 'Sainsbury\'s: up to £999.99\nASDA: up to £9.99\nMorrisons: no limit', inline: false },
          { name: 'Discount Calculator', value: 'Use the `calculate-discount` option for automatic 65% off (rounded to nearest 50p)', inline: false },
          { name: '/calculate Command', value: 'Calculate custom discounts with any percentage', inline: false }
        );
      break;
      
    default:
      embed.setDescription('**Barcode Studio Bot** - Generate retail barcodes with permissions and logging')
        .addFields(
          { name: 'Getting Started', value: 'Use `/help commands` to see all available commands', inline: false },
          { name: 'Permissions', value: 'Use `/help permissions` for access requirements', inline: false },
          { name: 'Barcode Types', value: 'Use `/help types` for format information', inline: false },
          { name: 'Pricing', value: 'Use `/help pricing` for price limits and discounts', inline: false }
        );
  }

  await interaction.reply({ embeds: [embed], ephemeral: true });
  
  // Log help request
  const logChannel = Logger.getLogChannel(interaction.guild, 'general');
  if (logChannel) {
    await Logger.logHelp(logChannel, interaction.user, topic);
  }
}

async function handleCalculate(interaction: any) {
  const originalPrice = interaction.options.getNumber('original-price', true);
  const discountPercent = interaction.options.getInteger('discount') || 65;
  
  if (originalPrice <= 0) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Invalid Price')
      .setDescription('Price must be greater than 0')
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }
  
  if (discountPercent < 0 || discountPercent > 99) {
    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('❌ Invalid Discount')
      .setDescription('Discount must be between 0% and 99%')
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const discountedPrice = calculateDiscount(originalPrice, discountPercent);
  const savings = originalPrice - discountedPrice;

  const embed = new EmbedBuilder()
    .setColor('#00ff00')
    .setTitle('🧮 Price Calculator')
    .addFields(
      { name: 'Original Price', value: `£${originalPrice.toFixed(2)}`, inline: true },
      { name: 'Discount', value: `${discountPercent}%`, inline: true },
      { name: 'Final Price', value: `£${discountedPrice.toFixed(2)}`, inline: true },
      { name: 'You Save', value: `£${savings.toFixed(2)}`, inline: false }
    )
    .setTimestamp()
    .setFooter({ text: 'Prices rounded to nearest 50p' });

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

// Redeem System Handlers
async function handleRedeem(interaction: any) {
  const code = interaction.options.getString('code');
  const userId = interaction.user.id;
  const guildId = interaction.guild.id;

  try {
    const result = await RedeemSystem.redeemKey(code, userId, guildId);
    
    if (result.success) {
      // Add premium role
      const premiumRole = interaction.guild.roles.cache.find((role: any) => 
        role.name.toLowerCase() === 'premium' || 
        role.name.toLowerCase() === 'sainsburys' ||
        role.name.toLowerCase() === 'asda' ||
        role.name.toLowerCase() === 'morrisons'
      );
      
      if (premiumRole) {
        await interaction.member.roles.add(premiumRole);
      }

      const embed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle('✅ Code Redeemed Successfully!')
        .setDescription(result.message)
        .addFields(
          { name: 'Duration', value: `${result.duration} days`, inline: true },
          { name: 'Status', value: 'Premium access granted', inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } else {
      const embed = new EmbedBuilder()
        .setColor('#ff0000')
        .setTitle('❌ Redemption Failed')
        .setDescription(result.message)
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  } catch (error) {
    console.error('Error in redeem:', error);
    await interaction.reply({ content: 'An error occurred while redeeming your code.', ephemeral: true });
  }
}

async function handleGenerateKeys(interaction: any) {
  // Check if user is server owner
  if (interaction.user.id !== interaction.guild.ownerId) {
    await interaction.reply({ content: '❌ Only the server owner can generate keys!', flags: MessageFlags.Ephemeral });
    return;
  }

  const count = interaction.options.getInteger('count');
  const duration = interaction.options.getInteger('duration');

  if (count > 50) {
    await interaction.reply({ content: '❌ Maximum 50 keys can be generated at once!', ephemeral: true });
    return;
  }

  try {
    const keys = await RedeemSystem.createKeys(count, duration, 'premium', interaction.user.id, interaction.guild.id);
    
    const keyList = keys.join('\n');
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('🔑 Keys Generated Successfully')
      .setDescription(`Generated ${count} keys for ${duration} day(s) access`)
      .addFields(
        { name: 'Keys', value: `\`\`\`${keyList}\`\`\``, inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  } catch (error) {
    console.error('Error generating keys:', error);
    await interaction.reply({ content: 'An error occurred while generating keys.', ephemeral: true });
  }
}

async function handleKeyStats(interaction: any) {
  // Check if user is server owner
  if (interaction.user.id !== interaction.guild.ownerId) {
    await interaction.reply({ content: '❌ Only the server owner can view key statistics!', ephemeral: true });
    return;
  }

  try {
    const stats = await RedeemSystem.getKeyStats(interaction.guild.id);
    
    let description = 'Key usage statistics:\n\n';
    stats.forEach((stat: any) => {
      description += `**${stat.duration} Day Keys:**\n`;
      description += `• Total: ${stat.total}\n`;
      description += `• Used: ${stat.used}\n`;
      description += `• Remaining: ${stat.total - stat.used}\n\n`;
    });

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('📊 Redeem Key Statistics')
      .setDescription(description)
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  } catch (error) {
    console.error('Error getting key stats:', error);
    await interaction.reply({ content: 'An error occurred while fetching statistics.', ephemeral: true });
  }
}

async function handleTimeLeft(interaction: any) {
  try {
    // Get user's active subscriptions
    const subscriptions = await RedeemSystem.getAllUserSubscriptions(interaction.user.id, interaction.guild.id);

    if (!subscriptions || subscriptions.length === 0) {
      const embed = new EmbedBuilder()
        .setColor('#ff9900')
        .setTitle('⏰ Access Status')
        .setDescription('❌ **No active access found**\n\nYou don\'t currently have access to any store barcodes.\n\n🔑 Use a redeem code to get access!')
        .addFields(
          { name: '🎫 Get Access', value: 'Ask an admin for a redeem code', inline: true },
          { name: '📝 Redeem Code', value: 'Use the redeem panel to enter your code', inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#00ff88')
      .setTitle('⏰ Your Access Time Remaining')
      .setDescription('**Active subscriptions and remaining time:**')
      .setTimestamp();

    const storeEmojis: Record<string, string> = {
      'sainsburys': '🛒',
      'asda': '🟢', 
      'morrisons': '🔵',
      'premium': '⭐'
    };

    let hasActiveAccess = false;

    subscriptions.forEach((sub: any) => {
      const expiresAt = new Date(sub.expires_at);
      const now = new Date();
      const timeLeft = expiresAt.getTime() - now.getTime();

      if (timeLeft > 0) {
        hasActiveAccess = true;
        
        // Calculate remaining time
        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));

        let timeString = '';
        if (days > 0) timeString += `${days} day${days > 1 ? 's' : ''}, `;
        if (hours > 0) timeString += `${hours} hour${hours > 1 ? 's' : ''}, `;
        timeString += `${minutes} minute${minutes > 1 ? 's' : ''}`;

        const emoji = storeEmojis[sub.store_type] || '🔑';
        const storeName = sub.store_type.charAt(0).toUpperCase() + sub.store_type.slice(1);
        
        embed.addFields({
          name: `${emoji} ${storeName} Access`,
          value: `⏱️ **${timeString}** remaining\n📅 Expires: ${expiresAt.toLocaleString()}`,
          inline: true
        });
      }
    });

    if (!hasActiveAccess) {
      embed.setColor('#ff9900')
        .setDescription('❌ **All subscriptions have expired**\n\nYour access has ended. Use a new redeem code to regain access.');
    } else {
      embed.addFields({
        name: '📊 Access Status',
        value: '✅ You have active access to generate barcodes!',
        inline: false
      });
    }

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });

  } catch (error) {
    console.error('Error checking time left:', error);
    await interaction.reply({ 
      content: '❌ An error occurred while checking your access time.', 
      flags: MessageFlags.Ephemeral 
    });
  }
}

async function handleSetupRedeemPanel(interaction: any) {
  // Check if user is server owner
  if (interaction.user.id !== interaction.guild.ownerId) {
    await interaction.reply({ content: '❌ Only the server owner can setup redeem panels!', ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#0099ff')
    .setTitle('🎫 Premium Access Redeem Panel')
    .setDescription('Use the `/redeem` command with your code to get premium access!')
    .addFields(
      { name: '🔑 Available Durations', value: '• 1 Day Access\n• 5 Day Access\n• 10 Day Access\n• 31 Day Access', inline: false },
      { name: '📝 How to Redeem', value: 'Type `/redeem code:YOUR-CODE-HERE`', inline: false },
      { name: '✨ Premium Benefits', value: 'Access to all barcode generation commands', inline: false }
    )
    .setFooter({ text: 'Contact server admin for redeem codes' })
    .setTimestamp();

  await interaction.reply({ content: '✅ Redeem panel setup complete!', ephemeral: true });
  await interaction.followUp({ embeds: [embed] });
}

// Button Interaction Handler
async function handleButtonInteraction(interaction: any) {
  const { customId } = interaction;

  try {
    if (customId === 'redeem_code') {
      // Create modal for code input
      const modal = new ModalBuilder()
        .setCustomId('redeem_modal')
        .setTitle('🔑 Enter Your Access Code');

      const codeInput = new TextInputBuilder()
        .setCustomId('access_code')
        .setLabel('Redeem Code')
        .setPlaceholder('Enter your code (e.g., SB-ABCD-EFGH23)')
        .setStyle(TextInputStyle.Short)
        .setMaxLength(20)
        .setRequired(true);

      const actionRow = new ActionRowBuilder<TextInputBuilder>().addComponents(codeInput);
      modal.addComponents(actionRow);

      await interaction.showModal(modal);

    } else if (customId === 'redeem_info') {
      const embed = new EmbedBuilder()
        .setColor('#ffa500')
        .setTitle('🆘 How to Get Access Codes')
        .setDescription('**Contact the server administrator to obtain redeem codes.**\n\n' +
          '📞 **Ways to get codes:**\n' +
          '• Message server owner directly\n' +
          '• Check server announcements\n' +
          '• Participate in server events\n' +
          '• Purchase from authorized sellers\n\n' +
          '⚡ **Codes are activated instantly upon redemption!**')
        .addFields(
          { name: '🔒 Security Note', value: 'Never share your codes with others. Each code can only be used once.', inline: false }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });

    } else if (customId === 'check_timeleft') {
      // Handle time left button (same as /timeleft command)
      await handleTimeLeft(interaction);

    } else if (customId === 'owner_generate') {
      // Check if user is server owner
      if (interaction.user.id !== interaction.guild.ownerId) {
        await interaction.reply({ content: '❌ Only the server owner can access this!', ephemeral: true });
        return;
      }

      const modal = new ModalBuilder()
        .setCustomId('generate_keys_modal')
        .setTitle('🔧 Generate Access Keys');

      const storeInput = new TextInputBuilder()
        .setCustomId('store_type')
        .setLabel('Store Type')
        .setPlaceholder('Enter: sainsburys, asda, morrisons, waitrose, or premium')
        .setStyle(TextInputStyle.Short)
        .setMaxLength(15)
        .setRequired(true);

      const countInput = new TextInputBuilder()
        .setCustomId('key_count')
        .setLabel('Number of Keys (1-50)')
        .setPlaceholder('Enter number of keys to generate')
        .setStyle(TextInputStyle.Short)
        .setMaxLength(2)
        .setRequired(true);

      const durationInput = new TextInputBuilder()
        .setCustomId('key_duration')
        .setLabel('Duration (1m, 1h, 1-31d, lifetime)')
        .setPlaceholder('Examples: 1m, 30m, 1h, 1d, 7d, 31d, lifetime')
        .setStyle(TextInputStyle.Short)
        .setMaxLength(10)
        .setRequired(true);

      const actionRow1 = new ActionRowBuilder<TextInputBuilder>().addComponents(storeInput);
      const actionRow2 = new ActionRowBuilder<TextInputBuilder>().addComponents(countInput);
      const actionRow3 = new ActionRowBuilder<TextInputBuilder>().addComponents(durationInput);
      modal.addComponents(actionRow1, actionRow2, actionRow3);

      await interaction.showModal(modal);

    } else if (customId === 'owner_stats') {
      // Check if user is server owner
      if (interaction.user.id !== interaction.guild.ownerId) {
        await interaction.reply({ content: '❌ Only the server owner can access this!', ephemeral: true });
        return;
      }

      await handleKeyStats(interaction);

    } else if (customId === 'owner_keys') {
      // Check if user is server owner
      if (interaction.user.id !== interaction.guild.ownerId) {
        await interaction.reply({ content: '❌ Only the server owner can access this!', ephemeral: true });
        return;
      }

      await showAllKeys(interaction);

    // Admin Panel Button Handlers
    } else if (customId === 'admin_stats') {
      // Check if user is bot owner
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showAdminStatistics(interaction);

    } else if (customId === 'admin_keys') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showKeyManagement(interaction);

    } else if (customId === 'admin_users') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showUserManagement(interaction);

    } else if (customId === 'admin_database') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showDatabaseInfo(interaction);

    } else if (customId === 'admin_system') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showSystemInfo(interaction);

    } else if (customId === 'admin_redemptions') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showRedemptionHistory(interaction);

    } else if (customId === 'admin_subscriptions') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showActiveSubscriptions(interaction);

    } else if (customId === 'admin_expired') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showExpiredUsers(interaction);

    } else if (customId === 'admin_export') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await exportAllData(interaction);

    } else if (customId === 'admin_cleanup') {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId || interaction.user.id !== ownerId) {
        await interaction.reply({ content: '❌ Only the bot owner can access this!', flags: MessageFlags.Ephemeral });
        return;
      }
      await showCleanupOptions(interaction);

    } else if (customId.startsWith('send_keys_dm_')) {
      // Handle sending keys to DM
      const tempKeys = (global as any).tempKeys;
      if (!tempKeys || !tempKeys.has(customId)) {
        await interaction.reply({ content: '❌ Keys expired or not found. Please generate new keys.', ephemeral: true });
        return;
      }

      const keyData = tempKeys.get(customId);
      
      // Verify it's the same user
      if (keyData.userId !== interaction.user.id) {
        await interaction.reply({ content: '❌ You can only send your own keys to DM.', ephemeral: true });
        return;
      }

      // Check if keys are too old (expire after 10 minutes)
      if (Date.now() - keyData.timestamp > 600000) {
        tempKeys.delete(customId);
        await interaction.reply({ content: '❌ Keys expired after 10 minutes. Please generate new keys.', ephemeral: true });
        return;
      }

      try {
        // Send keys as plain text to user's DM
        const keyText = `**${keyData.storeType.toUpperCase()} Keys (${keyData.duration})**\n\n${keyData.keys.join('\n')}\n\n*Generated: ${new Date().toLocaleString()}*`;
        
        await interaction.user.send(keyText);
        
        // Clean up stored keys
        tempKeys.delete(customId);
        
        await interaction.reply({ content: '✅ Keys sent to your DM as plain text!', ephemeral: true });
        
      } catch (dmError) {
        console.error('Error sending DM:', dmError);
        await interaction.reply({ content: '❌ Could not send DM. Please enable DMs from server members.', ephemeral: true });
      }
    }

  } catch (error) {
    console.error('Error handling button interaction:', error);
    await interaction.reply({ content: '❌ An error occurred. Please try again.', ephemeral: true });
  }
}

// Modal Submit Handler
async function handleModalSubmit(interaction: any) {
  const { customId } = interaction;

  try {
    if (customId === 'redeem_modal') {
      const code = interaction.fields.getTextInputValue('access_code').trim().toUpperCase();
      
      // Validate code format - should match: PREFIX-XXXX-XXXXXX (e.g., SB-ABCD-EFGH23)
      if (!/^[A-Z]{2}-[A-Z0-9]{4}-[A-Z0-9]{6}$/.test(code)) {
        await interaction.reply({ 
          content: '❌ Invalid code format! Please use format: XX-XXXX-XXXXXX (e.g., SB-ABCD-EFGH23)', 
          ephemeral: true 
        });
        return;
      }

      const result = await RedeemSystem.redeemKey(code, interaction.user.id, interaction.guild.id);
      
      if (result.success) {
        // Add store-specific role
        const storeType = result.storeType || 'premium';
        let rolesToAdd: Role[] = [];
        
        console.log(`🔍 Processing redemption for ${interaction.user.tag}: ${storeType} access`);
        
        // Function to find role by name or environment variable ID
        const findRole = (storeName: string) => {
          // First try to find by environment variable ID
          let roleId = '';
          switch(storeName.toLowerCase()) {
            case 'sainsburys': roleId = process.env.SAINSBURYS_ROLE_ID || ''; break;
            case 'asda': roleId = process.env.ASDA_ROLE_ID || ''; break;
            case 'morrisons': roleId = process.env.MORRISONS_ROLE_ID || ''; break;
            case 'premium': roleId = process.env.PREMIUM_ROLE_ID || ''; break;
          }
          
          if (roleId) {
            const roleById = interaction.guild.roles.cache.get(roleId);
            if (roleById) return roleById;
          }
          
          // Fallback to finding by name
          return interaction.guild.roles.cache.find((role: any) => 
            role.name.toLowerCase().includes(storeName.toLowerCase())
          );
        };

        if (storeType === 'premium') {
          // Premium gives access to all stores
          const premiumRole = findRole('premium');
          const sainsburysRole = findRole('sainsburys');
          const asdaRole = findRole('asda');
          const morrisonsRole = findRole('morrisons');
          
          if (premiumRole) rolesToAdd.push(premiumRole);
          if (sainsburysRole) rolesToAdd.push(sainsburysRole);
          if (asdaRole) rolesToAdd.push(asdaRole);
          if (morrisonsRole) rolesToAdd.push(morrisonsRole);
        } else {
          // Specific store role
          const storeRole = findRole(storeType);
          if (storeRole) {
            rolesToAdd.push(storeRole);
          }
        }
        
        // Add roles to user
        if (rolesToAdd.length > 0) {
          try {
            await interaction.member.roles.add(rolesToAdd);
            console.log(`✅ Added roles to ${interaction.user.tag}: ${rolesToAdd.map(r => r.name).join(', ')}`);
          } catch (roleError) {
            console.error(`❌ Failed to add roles to ${interaction.user.tag}:`, roleError);
          }
        } else {
          console.log(`⚠️ No matching roles found for ${storeType} in ${interaction.guild.name}`);
        }

        const storeEmoji: Record<string, string> = {
          'sainsburys': '🛒',
          'asda': '🟢', 
          'morrisons': '🔵',
          'premium': '⭐'
        };

        const availableCommands = storeType === 'premium' 
          ? '• `/sainsburys` - Generate Sainsbury\'s barcodes\n• `/asda` - Generate ASDA barcodes\n• `/morrisons` - Generate Morrisons barcodes\n• `/mystats` - View your statistics'
          : `• \`/${storeType}\` - Generate ${storeType.charAt(0).toUpperCase() + storeType.slice(1)} barcodes\n• \`/mystats\` - View your statistics`;

        const embed = new EmbedBuilder()
          .setColor('#00ff00')
          .setTitle(`🎉 ${storeType.charAt(0).toUpperCase() + storeType.slice(1)} Access Granted!`)
          .setDescription(`**Welcome to ${storeType.charAt(0).toUpperCase() + storeType.slice(1)} Access!**\n\nYour ${result.duration}-day access has been activated.`)
          .addFields(
            { name: '⏰ Duration', value: `${result.duration} days`, inline: true },
            { name: `${storeEmoji[storeType] || '🔑'} Store Type`, value: storeType.charAt(0).toUpperCase() + storeType.slice(1), inline: true },
            { name: '🎯 Status', value: '✅ Active', inline: true },
            { name: '📋 Available Commands', value: availableCommands, inline: false }
          )
          .setFooter({ text: '🚀 Start generating barcodes now!' })
          .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
      } else {
        const embed = new EmbedBuilder()
          .setColor('#ff0000')
          .setTitle('❌ Redemption Failed')
          .setDescription(result.message)
          .addFields(
            { name: '💡 Tips', value: '• Check your code format (XXXX-XXXX-XXXX)\n• Make sure the code hasn\'t been used\n• Contact admin if you need a new code', inline: false }
          )
          .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
      }

    } else if (customId === 'generate_keys_modal') {
      // Check if user is server owner
      if (interaction.user.id !== interaction.guild.ownerId) {
        await interaction.reply({ content: '❌ Only the server owner can access this!', ephemeral: true });
        return;
      }

      const storeTypeStr = interaction.fields.getTextInputValue('store_type').toLowerCase().trim();
      const countStr = interaction.fields.getTextInputValue('key_count');
      const durationStr = interaction.fields.getTextInputValue('key_duration').toLowerCase().trim();
      
      const count = parseInt(countStr);
      
      // Parse duration with support for minutes, hours, days, and lifetime
      let durationInMinutes = 0;
      let durationDisplay = '';
      
      // Normalize input - convert to lowercase and handle full words
      const normalizedDuration = durationStr.toLowerCase().trim();
      
      if (normalizedDuration === 'lifetime') {
        durationInMinutes = -1; // Special value for lifetime
        durationDisplay = 'Lifetime';
      } else if (normalizedDuration.endsWith('m')) {
        durationInMinutes = parseInt(normalizedDuration.slice(0, -1));
        durationDisplay = `${durationInMinutes} minute${durationInMinutes > 1 ? 's' : ''}`;
      } else if (normalizedDuration.endsWith('h')) {
        const hours = parseInt(normalizedDuration.slice(0, -1));
        durationInMinutes = hours * 60;
        durationDisplay = `${hours} hour${hours > 1 ? 's' : ''}`;
      } else if (normalizedDuration.endsWith('d')) {
        const days = parseInt(normalizedDuration.slice(0, -1));
        durationInMinutes = days * 1440; // 1440 minutes = 1 day
        durationDisplay = `${days} day${days > 1 ? 's' : ''}`;
      } else if (normalizedDuration.includes('minute')) {
        // Handle "1 minute", "5 minutes", etc.
        const match = normalizedDuration.match(/(\d+)\s*minutes?/);
        if (match) {
          durationInMinutes = parseInt(match[1]);
          durationDisplay = `${durationInMinutes} minute${durationInMinutes > 1 ? 's' : ''}`;
        }
      } else if (normalizedDuration.includes('hour')) {
        // Handle "1 hour", "2 hours", etc.
        const match = normalizedDuration.match(/(\d+)\s*hours?/);
        if (match) {
          const hours = parseInt(match[1]);
          durationInMinutes = hours * 60;
          durationDisplay = `${hours} hour${hours > 1 ? 's' : ''}`;
        }
      } else if (normalizedDuration.includes('day')) {
        // Handle "1 day", "7 days", etc.
        const match = normalizedDuration.match(/(\d+)\s*days?/);
        if (match) {
          const days = parseInt(match[1]);
          durationInMinutes = days * 1440;
          durationDisplay = `${days} day${days > 1 ? 's' : ''}`;
        }
      } else {
        // Try to parse as days (legacy format) - only if it's a pure number
        const days = parseInt(normalizedDuration);
        if (!isNaN(days) && normalizedDuration === days.toString()) {
          durationInMinutes = days * 1440;
          durationDisplay = `${days} day${days > 1 ? 's' : ''}`;
        }
      }

      // Validation
      if (!['sainsburys', 'asda', 'morrisons', 'waitrose', 'premium'].includes(storeTypeStr)) {
        await interaction.reply({ content: '❌ Store type must be: sainsburys, asda, morrisons, waitrose, or premium!', ephemeral: true });
        return;
      }

      if (isNaN(count) || count < 1 || count > 50) {
        await interaction.reply({ content: '❌ Count must be between 1 and 50!', ephemeral: true });
        return;
      }

      if (durationInMinutes === 0 && durationStr !== 'lifetime') {
        await interaction.reply({ content: '❌ Invalid duration format! Use: 1m, 1 minute, 1h, 1 hour, 1d, 1 day, or lifetime', ephemeral: true });
        return;
      }

      const keys = await RedeemSystem.createKeys(count, durationInMinutes, storeTypeStr, interaction.user.id, interaction.guild.id);
      
      const storeEmoji: Record<string, string> = {
        'sainsburys': '🛒',
        'asda': '🟢', 
        'morrisons': '🔵',
        'premium': '⭐'
      };

      const keyList = keys.join('\n');
      const embed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle(`🔑 ${storeTypeStr.charAt(0).toUpperCase() + storeTypeStr.slice(1)} Keys Generated`)
        .setDescription(`**Generated ${count} keys for ${durationDisplay} ${storeTypeStr} access**\n\n🔒 **Your Keys:**`)
        .addFields(
          { name: `📋 ${storeEmoji[storeTypeStr] || '🔑'} Generated Codes`, value: `\`\`\`${keyList}\`\`\``, inline: false },
          { name: '📊 Summary', value: `• **Store**: ${storeTypeStr.charAt(0).toUpperCase() + storeTypeStr.slice(1)}\n• **Count**: ${count} keys\n• **Duration**: ${durationDisplay} each\n• **Type**: ${durationInMinutes === -1 ? 'Permanent Access' : 'Temporary Access'}`, inline: false }
        )
        .setFooter({ text: '⚠️ Keep these codes secure - they can only be used once!' })
        .setTimestamp();

      // Create button to send keys to DM
      const buttonId = `send_keys_dm_${Date.now()}`;
      const dmButton = new ButtonBuilder()
        .setCustomId(buttonId)
        .setLabel('📬 Send to DM (Plain Text)')
        .setStyle(ButtonStyle.Secondary);

      const buttonRow = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(dmButton);

      // Store the keys temporarily for the DM button
      if (!(global as any).tempKeys) {
        (global as any).tempKeys = new Map();
      }
      (global as any).tempKeys.set(buttonId, {
        keys: keys,
        userId: interaction.user.id,
        storeType: storeTypeStr,
        duration: durationDisplay,
        count: count,
        timestamp: Date.now()
      });

      await interaction.reply({ 
        embeds: [embed], 
        components: [buttonRow], 
        ephemeral: true 
      });
    }

  } catch (error) {
    console.error('Error handling modal submit:', error);
    await interaction.reply({ content: '❌ An error occurred. Please try again.', ephemeral: true });
  }
}

// Show all keys function
async function showAllKeys(interaction: any) {
  try {
    const stats = await RedeemSystem.getKeyStats(interaction.guild.id);
    const unusedKeys = await RedeemSystem.getAllKeys(interaction.guild.id, false, 1000); // Get all unused keys
    
    if (!stats || stats.length === 0) {
      await interaction.reply({ 
        content: '📋 No keys have been generated yet. Use the **Generate Keys** button to create some!', 
        ephemeral: true 
      });
      return;
    }

    // First, send a confirmation message in the channel
    await interaction.reply({ 
      content: '📤 Sending all available keys to your DM...', 
      ephemeral: true 
    });

    const storeEmoji: Record<string, string> = {
      'sainsburys': '🛒',
      'asda': '🟢', 
      'morrisons': '🔵',
      'waitrose': '🟡',
      'premium': '⭐'
    };

    // Calculate totals for summary
    let totalKeys = 0;
    let totalUsed = 0;
    stats.forEach((stat: any) => {
      totalKeys += stat.total;
      totalUsed += stat.used;
    });

    try {
      // Create overview embed for DM
      let overviewDescription = '**📊 Key Status Summary:**\n\n';
      
      stats.forEach((stat: any) => {
        const remaining = stat.total - stat.used;
        
        // Format duration display
        let durationDisplay = '';
        if (stat.duration === -1) {
          durationDisplay = 'Lifetime';
        } else if (stat.duration < 1440) {
          const hours = Math.floor(stat.duration / 60);
          const minutes = stat.duration % 60;
          if (hours > 0) {
            durationDisplay = minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
          } else {
            durationDisplay = `${stat.duration}m`;
          }
        } else {
          const days = Math.floor(stat.duration / 1440);
          durationDisplay = `${days}d`;
        }
        
        const emoji = storeEmoji[stat.store_type] || '🔑';
        overviewDescription += `**${emoji} ${stat.store_type.charAt(0).toUpperCase() + stat.store_type.slice(1)} - ${durationDisplay}:**\n`;
        overviewDescription += `• Total: ${stat.total} | Used: ${stat.used} | Available: ${remaining}\n\n`;
      });

      const overviewEmbed = new EmbedBuilder()
        .setColor('#0099ff')
        .setTitle('🗃️ Complete Key Database Overview')
        .setDescription(overviewDescription)
        .addFields(
          { name: '� Overall Statistics', value: `• **Total Keys Created**: ${totalKeys}\n• **Keys Redeemed**: ${totalUsed}\n• **Keys Available**: ${totalKeys - totalUsed}\n• **Success Rate**: ${totalKeys > 0 ? Math.round((totalUsed/totalKeys)*100) : 0}%`, inline: false }
        )
        .setFooter({ text: `Server: ${interaction.guild.name} | Generated: ${new Date().toLocaleString()}` })
        .setTimestamp();

      await interaction.user.send({ embeds: [overviewEmbed] });

      // If no unused keys, send that info
      if (unusedKeys.length === 0) {
        const noKeysEmbed = new EmbedBuilder()
          .setColor('#ffaa00')
          .setTitle('📭 No Available Keys')
          .setDescription('All generated keys have been redeemed. Use the admin panel to create new keys.')
          .setTimestamp();
        
        await interaction.user.send({ embeds: [noKeysEmbed] });
        return;
      }

      // Group keys by store type and duration
      const keysByStoreAndDuration: Record<string, Record<string, any[]>> = {};
      unusedKeys.forEach(key => {
        const storeType = key.store_type;
        let durationKey = '';
        
        if (key.duration === -1) {
          durationKey = 'Lifetime';
        } else if (key.duration < 1440) {
          const hours = Math.floor(key.duration / 60);
          const minutes = key.duration % 60;
          if (hours > 0) {
            durationKey = minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
          } else {
            durationKey = `${key.duration}m`;
          }
        } else {
          const days = Math.floor(key.duration / 1440);
          durationKey = `${days}d`;
        }

        if (!keysByStoreAndDuration[storeType]) {
          keysByStoreAndDuration[storeType] = {};
        }
        if (!keysByStoreAndDuration[storeType][durationKey]) {
          keysByStoreAndDuration[storeType][durationKey] = [];
        }
        keysByStoreAndDuration[storeType][durationKey].push(key);
      });

      // Send keys organized by store type and duration
      for (const [storeType, durationGroups] of Object.entries(keysByStoreAndDuration)) {
        const emoji = storeEmoji[storeType] || '🔑';
        const storeTitle = storeType.charAt(0).toUpperCase() + storeType.slice(1);

        for (const [duration, keys] of Object.entries(durationGroups)) {
          // Split keys into chunks to avoid embed field limits
          const keyCodes = keys.map(key => key.code);
          const chunkSize = 50; // 50 keys per embed to stay within limits
          
          for (let i = 0; i < keyCodes.length; i += chunkSize) {
            const chunk = keyCodes.slice(i, i + chunkSize);
            const isFirstChunk = i === 0;
            const chunkNumber = Math.floor(i / chunkSize) + 1;
            const totalChunks = Math.ceil(keyCodes.length / chunkSize);
            
            const keyListText = chunk.join('\n');
            
            const keyEmbed = new EmbedBuilder()
              .setColor(storeType === 'sainsburys' ? '#ff6600' : 
                       storeType === 'asda' ? '#00aa00' : 
                       storeType === 'morrisons' ? '#0066cc' : 
                       storeType === 'waitrose' ? '#ffcc00' : '#6600cc')
              .setTitle(`${emoji} ${storeTitle} - ${duration} Keys${totalChunks > 1 ? ` (${chunkNumber}/${totalChunks})` : ''}`)
              .setDescription('**🔑 Available Access Codes:**')
              .addFields(
                { name: `📋 Keys (${chunk.length} of ${keyCodes.length} total)`, value: `\`\`\`${keyListText}\`\`\``, inline: false }
              )
              .setFooter({ text: `Store: ${storeTitle} | Duration: ${duration} | Created: ${keys[0].created_at ? new Date(keys[0].created_at).toLocaleDateString() : 'Unknown'}` })
              .setTimestamp();

            await interaction.user.send({ embeds: [keyEmbed] });
            
            // Small delay between messages to avoid rate limiting
            if (i + chunkSize < keyCodes.length) {
              await new Promise(resolve => setTimeout(resolve, 500));
            }
          }
        }
      }

      // Send final summary
      const summaryEmbed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle('✅ Key Export Complete')
        .setDescription(`Successfully exported ${unusedKeys.length} available keys from **${interaction.guild.name}**`)
        .addFields(
          { name: '📊 Export Summary', value: `• **Total Available Keys**: ${unusedKeys.length}\n• **Store Types**: ${Object.keys(keysByStoreAndDuration).length}\n• **Export Time**: ${new Date().toLocaleString()}`, inline: false },
          { name: '🔐 Security Reminder', value: '• These keys are single-use only\n• Keep them secure and private\n• Monitor key usage in the admin panel', inline: false }
        )
        .setTimestamp();

      await interaction.user.send({ embeds: [summaryEmbed] });

    } catch (dmError) {
      console.error('Error sending DM:', dmError);
      await interaction.followUp({ 
        content: '❌ Could not send keys to your DM. Please enable DMs from server members and try again.', 
        ephemeral: true 
      });
    }

  } catch (error) {
    console.error('Error showing all keys:', error);
    await interaction.reply({ content: '❌ Error fetching key information.', ephemeral: true });
  }
}

// Enhanced error handling
process.on('unhandledRejection', (error) => {
  console.error('❌ Unhandled promise rejection:', error);
});

// ===== ADMIN PANEL FUNCTIONS =====

async function showAdminStatistics(interaction: any) {
  try {
    const embed = new EmbedBuilder()
      .setColor('#ff6b00')
      .setTitle('📊 Comprehensive Bot Statistics')
      .setDescription('**Real-time analytics and performance metrics**')
      .addFields(
        { name: '📈 Bot Status', value: '✅ Online and operational', inline: true },
        { name: '⚡ Uptime', value: `${Math.floor(process.uptime() / 60)} minutes`, inline: true },
        { name: '� Memory', value: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: '🔑 Key System', value: 'Redeem system active', inline: true },
        { name: '� Stores', value: 'Sainsburys, ASDA, Morrisons', inline: true },
        { name: '📊 Features', value: 'Code 128 barcodes, Role management', inline: true }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });

  } catch (error) {
    console.error('Error showing admin statistics:', error);
    await interaction.reply({ content: '❌ Error loading statistics.', flags: MessageFlags.Ephemeral });
  }
}

async function showKeyManagement(interaction: any) {
  const embed = new EmbedBuilder()
    .setColor('#00ff88')
    .setTitle('🔑 Key Management System')
    .setDescription('**Manage access keys and user subscriptions**')
    .addFields(
      { name: '🆕 Generate New Keys', value: 'Create keys for different store types and durations', inline: true },
      { name: '📋 View All Keys', value: 'See all generated keys and their status', inline: true },
      { name: '🗑️ Revoke Keys', value: 'Deactivate unused keys if needed', inline: true },
      { name: '👥 Active Subscriptions', value: 'View users with active access', inline: true },
      { name: '⏰ Expiration Management', value: 'Check and manage key expiration dates', inline: true },
      { name: '📊 Usage Analytics', value: 'Detailed key usage statistics', inline: true }
    )
    .setTimestamp();

  const keyButtons = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('admin_generate_keys')
        .setLabel('🆕 Generate Keys')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('admin_view_keys')
        .setLabel('📋 View All Keys')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('admin_active_subs')
        .setLabel('👥 Active Users')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [embed], components: [keyButtons], flags: MessageFlags.Ephemeral });
}

async function showUserManagement(interaction: any) {
  try {
    const embed = new EmbedBuilder()
      .setColor('#4287f5')
      .setTitle('👥 User Management Dashboard')
      .setDescription('**Monitor user activity and manage permissions**')
      .addFields(
        { name: '👤 Active Users', value: 'Use `/serverstats` to view user activity', inline: true },
        { name: '📊 Statistics', value: 'User barcode generation tracked', inline: true },
        { name: '🔒 Permissions', value: 'Role-based access control', inline: true },
        { name: '⏰ Subscriptions', value: 'Automatic expiration management', inline: true },
        { name: '🎯 Features', value: 'User history and leaderboards', inline: true },
        { name: '🛡️ Security', value: 'Privacy-focused logging', inline: true }
      )
      .setTimestamp();

    const userButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('admin_user_stats')
          .setLabel('📊 User Statistics')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('admin_user_search')
          .setLabel('🔍 Search User')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('admin_ban_user')
          .setLabel('🚫 Ban User')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.reply({ embeds: [embed], components: [userButtons], flags: MessageFlags.Ephemeral });

  } catch (error) {
    console.error('Error showing user management:', error);
    await interaction.reply({ content: '❌ Error loading user data.', flags: MessageFlags.Ephemeral });
  }
}

async function showDatabaseInfo(interaction: any) {
  try {
    const embed = new EmbedBuilder()
      .setColor('#9932cc')
      .setTitle('🗃️ Database Information')
      .setDescription('**Database health and statistics**')
      .addFields(
        { name: '📊 Type', value: 'SQLite Database', inline: true },
        { name: '🔑 Files', value: 'barcodes.db\nredeem-keys.db', inline: true },
        { name: '💾 Status', value: '✅ Operational', inline: true },
        { name: '🗄️ Tables', value: 'barcode_history\nredeem_keys\nuser_subscriptions', inline: true },
        { name: '⚡ Performance', value: 'Optimized queries', inline: true },
        { name: '🔒 Security', value: 'Local file storage', inline: true }
      )
      .setTimestamp();

    const dbButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('admin_db_backup')
          .setLabel('💾 Create Backup')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('admin_db_optimize')
          .setLabel('⚡ Optimize')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('admin_db_vacuum')
          .setLabel('🧹 Vacuum')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.reply({ embeds: [embed], components: [dbButtons], flags: MessageFlags.Ephemeral });

  } catch (error) {
    console.error('Error showing database info:', error);
    await interaction.reply({ content: '❌ Error loading database information.', flags: MessageFlags.Ephemeral });
  }
}

async function showSystemInfo(interaction: any) {
  const embed = new EmbedBuilder()
    .setColor('#ff4500')
    .setTitle('⚙️ System Information')
    .setDescription('**Bot performance and system metrics**')
    .addFields(
      { name: '🤖 Bot Version', value: 'v2.0.0', inline: true },
      { name: '📝 Node.js', value: process.version, inline: true },
      { name: '⚡ Uptime', value: `${Math.floor(process.uptime() / 60)} minutes`, inline: true },
      { name: '💾 Memory Usage', value: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
      { name: '🌐 Platform', value: process.platform, inline: true },
      { name: '📊 Discord.js', value: 'v14.14.1', inline: true },
      { name: '⚙️ Environment', value: process.env.NODE_ENV || 'development', inline: true },
      { name: '🔧 Features', value: 'Code 128 Barcodes\nStore-specific Keys\nRole Management\nInteractive UI', inline: true },
      { name: '📈 Performance', value: 'Optimized SQLite\nAsync Operations\nError Handling', inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

async function showCleanupOptions(interaction: any) {
  const embed = new EmbedBuilder()
    .setColor('#ff0000')
    .setTitle('🧹 Cleanup & Maintenance')
    .setDescription('**⚠️ Dangerous operations - use with caution!**\n\nThese tools help maintain database performance and clean up old data.')
    .addFields(
      { name: '🗑️ Clean Old Records', value: 'Remove barcode records older than 90 days', inline: true },
      { name: '⏰ Expire Keys', value: 'Force expire all unused keys', inline: true },
      { name: '🧽 Clear Logs', value: 'Clear application log files', inline: true },
      { name: '💾 Vacuum Database', value: 'Optimize database file size', inline: true },
      { name: '🔄 Reset Statistics', value: 'Clear all usage statistics', inline: true },
      { name: '⚠️ Factory Reset', value: 'Clear ALL data (destructive!)', inline: true }
    )
    .setTimestamp();

  const cleanupButtons = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('admin_clean_old')
        .setLabel('🗑️ Clean Old Data')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('admin_expire_keys')
        .setLabel('⏰ Expire Keys')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('admin_vacuum_db')
        .setLabel('💾 Vacuum DB')
        .setStyle(ButtonStyle.Primary)
    );

  const dangerButtons = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('admin_reset_stats')
        .setLabel('🔄 Reset Statistics')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('admin_factory_reset')
        .setLabel('⚠️ FACTORY RESET')
        .setStyle(ButtonStyle.Danger)
    );

  await interaction.reply({ 
    embeds: [embed], 
    components: [cleanupButtons, dangerButtons], 
    flags: MessageFlags.Ephemeral 
  });
}

// New Enhanced Admin Functions
async function showRedemptionHistory(interaction: any) {
  try {
    const redemptions = await RedeemSystem.getRedemptionHistory(interaction.guild.id, 25);
    
    if (redemptions.length === 0) {
      await interaction.reply({ 
        content: '📜 No redemption history found.', 
        flags: MessageFlags.Ephemeral 
      });
      return;
    }

    let description = '**Recent Key Redemptions:**\n\n';
    
    const storeEmoji: Record<string, string> = {
      'sainsburys': '🛒',
      'asda': '🟢', 
      'morrisons': '🔵',
      'waitrose': '🟡',
      'premium': '⭐'
    };

    redemptions.forEach((redemption: any, index: number) => {
      const emoji = storeEmoji[redemption.store_type] || '🔑';
      const usedDate = new Date(redemption.used_at).toLocaleString();
      const createdDate = new Date(redemption.created_at).toLocaleDateString();
      
      let durationText = '';
      if (redemption.duration === -1) {
        durationText = 'Lifetime';
      } else if (redemption.duration < 1440) {
        const hours = Math.floor(redemption.duration / 60);
        const minutes = redemption.duration % 60;
        if (hours > 0) {
          durationText = minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
        } else {
          durationText = `${redemption.duration}m`;
        }
      } else {
        const days = Math.floor(redemption.duration / 1440);
        durationText = `${days}d`;
      }

      description += `**${index + 1}. ${emoji} ${redemption.store_type.toUpperCase()}** (${durationText})\n`;
      description += `• Code: \`${redemption.code}\`\n`;
      description += `• User: <@${redemption.used_by}>\n`;
      description += `• Redeemed: ${usedDate}\n`;
      description += `• Created: ${createdDate}\n\n`;
    });

    const embed = new EmbedBuilder()
      .setColor('#9932cc')
      .setTitle('📜 Redemption History')
      .setDescription(description)
      .setFooter({ text: `Showing latest ${redemptions.length} redemptions • Total tracked redemptions available` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  } catch (error) {
    console.error('Error showing redemption history:', error);
    await interaction.reply({ content: '❌ Error fetching redemption history.', flags: MessageFlags.Ephemeral });
  }
}

async function showActiveSubscriptions(interaction: any) {
  try {
    const subscriptions = await RedeemSystem.getAllActiveSubscriptions(interaction.guild.id);
    
    if (subscriptions.length === 0) {
      await interaction.reply({ 
        content: '⏰ No active subscriptions found.', 
        flags: MessageFlags.Ephemeral 
      });
      return;
    }

    // Group by store type
    const subsByStore: Record<string, any[]> = {};
    subscriptions.forEach(sub => {
      if (!subsByStore[sub.store_type]) {
        subsByStore[sub.store_type] = [];
      }
      subsByStore[sub.store_type].push(sub);
    });

    const storeEmoji: Record<string, string> = {
      'sainsburys': '🛒',
      'asda': '🟢', 
      'morrisons': '🔵',
      'waitrose': '🟡',
      'premium': '⭐'
    };

    const embed = new EmbedBuilder()
      .setColor('#00ff00')
      .setTitle('⏰ Active Subscriptions')
      .setDescription(`**${subscriptions.length} users currently have active access**\n\n`)
      .setTimestamp();

    // Add fields for each store type
    Object.entries(subsByStore).forEach(([storeType, subs]) => {
      const emoji = storeEmoji[storeType] || '🔑';
      const userList = subs
        .sort((a, b) => new Date(a.expires_at).getTime() - new Date(b.expires_at).getTime())
        .map(sub => {
          const expiresAt = new Date(sub.expires_at);
          const timeLeft = expiresAt.getTime() - Date.now();
          const daysLeft = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
          const hoursLeft = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          
          let timeText = '';
          if (expiresAt.getFullYear() === 2100) {
            timeText = 'Lifetime';
          } else if (daysLeft > 0) {
            timeText = `${daysLeft}d ${hoursLeft}h`;
          } else if (hoursLeft > 0) {
            timeText = `${hoursLeft}h`;
          } else {
            const minutesLeft = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            timeText = `${minutesLeft}m`;
          }
          
          return `<@${sub.user_id}> (${timeText})`;
        })
        .slice(0, 10) // Limit to 10 per store to avoid embed limits
        .join('\n');

      const remaining = subs.length > 10 ? `\n*...and ${subs.length - 10} more*` : '';

      embed.addFields({
        name: `${emoji} ${storeType.charAt(0).toUpperCase() + storeType.slice(1)} (${subs.length})`,
        value: userList + remaining,
        inline: false
      });
    });

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  } catch (error) {
    console.error('Error showing active subscriptions:', error);
    await interaction.reply({ content: '❌ Error fetching active subscriptions.', flags: MessageFlags.Ephemeral });
  }
}

async function showExpiredUsers(interaction: any) {
  try {
    const expired = await RedeemSystem.getAllExpiredSubscriptions(interaction.guild.id, 25);
    
    if (expired.length === 0) {
      await interaction.reply({ 
        content: '⌛ No recently expired subscriptions found.', 
        flags: MessageFlags.Ephemeral 
      });
      return;
    }

    let description = '**Recently Expired Users:**\n\n';
    
    const storeEmoji: Record<string, string> = {
      'sainsburys': '🛒',
      'asda': '🟢', 
      'morrisons': '🔵',
      'waitrose': '🟡',
      'premium': '⭐'
    };

    expired.forEach((exp: any, index: number) => {
      const emoji = storeEmoji[exp.store_type] || '🔑';
      const expiredDate = new Date(exp.expires_at).toLocaleString();
      const createdDate = new Date(exp.created_at).toLocaleDateString();
      
      description += `**${index + 1}. ${emoji} ${exp.store_type.toUpperCase()}**\n`;
      description += `• User: <@${exp.user_id}>\n`;
      description += `• Expired: ${expiredDate}\n`;
      description += `• Created: ${createdDate}\n\n`;
    });

    const embed = new EmbedBuilder()
      .setColor('#ff6600')
      .setTitle('⌛ Recently Expired Subscriptions')
      .setDescription(description)
      .setFooter({ text: `Showing latest ${expired.length} expired subscriptions` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  } catch (error) {
    console.error('Error showing expired users:', error);
    await interaction.reply({ content: '❌ Error fetching expired users.', flags: MessageFlags.Ephemeral });
  }
}

async function exportAllData(interaction: any) {
  try {
    await interaction.reply({ 
      content: '💾 Preparing comprehensive data export to your DM...', 
      flags: MessageFlags.Ephemeral 
    });

    // Get all data
    const stats = await RedeemSystem.getDetailedKeyStats(interaction.guild.id);
    const allKeys = await RedeemSystem.getAllKeys(interaction.guild.id, false, 1000);
    const usedKeys = await RedeemSystem.getAllKeys(interaction.guild.id, true, 1000);
    const activeSubscriptions = await RedeemSystem.getAllActiveSubscriptions(interaction.guild.id);
    const expiredSubscriptions = await RedeemSystem.getAllExpiredSubscriptions(interaction.guild.id, 100);

    try {
      // Summary Export
      const summaryEmbed = new EmbedBuilder()
        .setColor('#6600cc')
        .setTitle('📊 Complete Data Export Summary')
        .setDescription(`**Full database export for ${interaction.guild.name}**`)
        .addFields(
          { name: '📋 Available Keys', value: allKeys.length.toString(), inline: true },
          { name: '✅ Used Keys', value: usedKeys.length.toString(), inline: true },
          { name: '⏰ Active Users', value: activeSubscriptions.length.toString(), inline: true },
          { name: '⌛ Expired Records', value: expiredSubscriptions.length.toString(), inline: true },
          { name: '📈 Store Types', value: stats.length.toString(), inline: true },
          { name: '💫 Export Date', value: new Date().toLocaleString(), inline: true }
        )
        .setTimestamp();

      await interaction.user.send({ embeds: [summaryEmbed] });

      // Detailed Statistics Export
      if (stats.length > 0) {
        let statsText = '**DETAILED STORE STATISTICS:**\n\n';
        stats.forEach((stat: any) => {
          let durationText = stat.duration === -1 ? 'Lifetime' : 
                           stat.duration < 1440 ? `${Math.floor(stat.duration / 60)}h ${stat.duration % 60}m` :
                           `${Math.floor(stat.duration / 1440)}d`;
          
          statsText += `**${stat.store_type.toUpperCase()} - ${durationText}:**\n`;
          statsText += `• Created: ${stat.total_created} | Used: ${stat.total_used}\n`;
          statsText += `• Creators: ${stat.unique_creators} | Users: ${stat.unique_redeemers}\n`;
          statsText += `• First Created: ${stat.first_created ? new Date(stat.first_created).toLocaleDateString() : 'N/A'}\n`;
          statsText += `• Last Used: ${stat.last_redeemed ? new Date(stat.last_redeemed).toLocaleDateString() : 'N/A'}\n\n`;
        });

        const statsEmbed = new EmbedBuilder()
          .setColor('#ff6600')
          .setTitle('📈 Detailed Statistics Export')
          .setDescription(statsText.length > 4000 ? statsText.substring(0, 4000) + '...' : statsText)
          .setTimestamp();

        await interaction.user.send({ embeds: [statsEmbed] });
      }

      // Available Keys Export (organized)
      if (allKeys.length > 0) {
        const keysByStore: Record<string, any[]> = {};
        allKeys.forEach(key => {
          if (!keysByStore[key.store_type]) {
            keysByStore[key.store_type] = [];
          }
          keysByStore[key.store_type].push(key);
        });

        for (const [storeType, keys] of Object.entries(keysByStore)) {
          const chunkSize = 50;
          for (let i = 0; i < keys.length; i += chunkSize) {
            const chunk = keys.slice(i, i + chunkSize);
            const keyList = chunk.map(key => key.code).join('\n');
            const chunkNum = Math.floor(i / chunkSize) + 1;
            const totalChunks = Math.ceil(keys.length / chunkSize);

            const keyEmbed = new EmbedBuilder()
              .setColor('#00aa00')
              .setTitle(`🔑 Available ${storeType.toUpperCase()} Keys ${totalChunks > 1 ? `(${chunkNum}/${totalChunks})` : ''}`)
              .setDescription('```\n' + keyList + '\n```')
              .setFooter({ text: `${chunk.length} keys in this batch | Total: ${keys.length}` })
              .setTimestamp();

            await interaction.user.send({ embeds: [keyEmbed] });
            
            if (i + chunkSize < keys.length) {
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
          }
        }
      }

      // Export completion message
      const completionEmbed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle('✅ Data Export Complete')
        .setDescription(`Successfully exported all data from **${interaction.guild.name}**`)
        .addFields(
          { name: '📦 Export Contents', value: `• ${allKeys.length} available keys\n• ${usedKeys.length} redemption records\n• ${activeSubscriptions.length} active subscriptions\n• ${expiredSubscriptions.length} expired records`, inline: false },
          { name: '🔐 Security Note', value: 'This export contains sensitive key data. Keep it secure and delete when no longer needed.', inline: false }
        )
        .setTimestamp();

      await interaction.user.send({ embeds: [completionEmbed] });

    } catch (dmError) {
      console.error('Error sending export DM:', dmError);
      await interaction.followUp({ 
        content: '❌ Could not send export to your DM. Please enable DMs from server members.', 
        flags: MessageFlags.Ephemeral 
      });
    }

  } catch (error) {
    console.error('Error exporting data:', error);
    await interaction.reply({ content: '❌ Error preparing data export.', flags: MessageFlags.Ephemeral });
  }
}

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught exception:', error);
  process.exit(1);
});

// Debug environment variables
console.log('🔍 Environment check:');
console.log('DISCORD_TOKEN exists:', !!process.env.DISCORD_TOKEN);
console.log('CLIENT_ID exists:', !!process.env.CLIENT_ID);
console.log('Token starts with:', process.env.DISCORD_TOKEN?.substring(0, 10) + '...');

client.login(process.env.DISCORD_TOKEN);