import { TextChannel } from 'discord.js';

export async function logAction(channel: TextChannel, userTag: string, action: string) {
  // Mask the user tag (replace everything after @ with *****)
  const maskedTag = userTag.replace(/@.*/, '@*****');
  await channel.send(`Action: ${action} by ${maskedTag}`);
}
