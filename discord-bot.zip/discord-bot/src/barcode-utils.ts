// Utility functions for barcode generation
export function generateSainsburysBarcode(barcode: string, price: number): string {
  let cleaned = barcode.replace(/\D/g, '');
  if (cleaned.length > 13) cleaned = cleaned.slice(0, 13);
  else if (cleaned.length < 13) cleaned = cleaned.padStart(13, '0');
  const penceAmount = Math.round(price * 100);
  const paddedPrice = penceAmount.toString().padStart(6, '0');
  const baseBarcode = `91${cleaned}${paddedPrice}`;
  const sumOfDigits = baseBarcode.split('').reduce((sum, digit) => sum + parseInt(digit), 0);
  const checkDigit = (sumOfDigits % 10).toString();
  return `${baseBarcode}${checkDigit}`;
}

export function generateAsdaBarcode(barcode: string, price: number): string {
  let cleaned = barcode.replace(/\D/g, '');
  if (cleaned.length > 13) cleaned = cleaned.slice(0, 13);
  else if (cleaned.length < 13) cleaned = cleaned.padStart(13, '0');
  const cents = ((Math.round(price * 100) % 100) + 100) % 100;
  const paddedPrice = cents.toString().padStart(2, '0');
  const baseBarcode = `330${cleaned}000${paddedPrice}2056`;
  const checkDigit = calculateLuhnCheckDigit(baseBarcode);
  return `${baseBarcode}${checkDigit}`;
}

export function generateMorrisonsBarcode(barcode: string, price: number): string {
  let cleaned = barcode.replace(/\D/g, '');
  if (cleaned.length > 13) cleaned = cleaned.slice(0, 13);
  else if (cleaned.length < 13) cleaned = cleaned.padStart(13, '0');
  const penceAmount = Math.round(price * 100);
  const middleSegment = `00003${penceAmount}00027`;
  return `92${cleaned}${middleSegment}`;
}

export function generateWaitroseBarcode(barcode: string, priceInPence: number): string {
  // Waitrose format: 10{13-digit-item-barcode}00{price}
  // 1. Start with 10
  // 2. Add the 13-digit item barcode
  // 3. Add 00
  // 4. Add the price in pence (e.g., 002 for 2p)
  
  let cleaned = barcode.replace(/\D/g, '');
  
  // Ensure exactly 13 digits
  if (cleaned.length > 13) {
    cleaned = cleaned.slice(0, 13);
  } else if (cleaned.length < 13) {
    cleaned = cleaned.padStart(13, '0');
  }
  
  // Format price - pad to at least 3 digits for proper display
  const paddedPrice = priceInPence.toString().padStart(3, '0');
  
  return `10${cleaned}00${paddedPrice}`;
}

function calculateLuhnCheckDigit(barcode: string): string {
  let sum = 0;
  let shouldDouble = true;
  for (let i = barcode.length - 1; i >= 0; i--) {
    let digit = parseInt(barcode[i]);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return ((10 - (sum % 10)) % 10).toString();
}
