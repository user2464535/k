import sqlite3 from 'sqlite3';
import path from 'path';

// Simple redeem key system
const redeemDb = new sqlite3.Database(path.join(__dirname, '../redeem-keys.db'));

export interface RedeemKey {
  code: string;
  duration: number; // Duration in minutes (1440 = 1 day, -1 = lifetime)
  storeType: 'sainsburys' | 'asda' | 'morrisons' | 'waitrose' | 'premium';
  createdBy: string;
  guildId: string;
  used: boolean;
}

export class RedeemSystem {
  
  static async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      redeemDb.serialize(() => {
        redeemDb.run(`
          CREATE TABLE IF NOT EXISTS redeem_keys (
            code TEXT PRIMARY KEY,
            duration INTEGER NOT NULL,
            store_type TEXT NOT NULL DEFAULT 'premium',
            created_by TEXT NOT NULL,
            guild_id TEXT NOT NULL,
            used BOOLEAN DEFAULT FALSE,
            used_by TEXT,
            used_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Add store_type column to existing table if it doesn't exist
        redeemDb.run(`
          ALTER TABLE redeem_keys ADD COLUMN store_type TEXT DEFAULT 'premium'
        `, () => {
          // Ignore error if column already exists
        });

        redeemDb.run(`
          CREATE TABLE IF NOT EXISTS user_subscriptions (
            user_id TEXT NOT NULL,
            guild_id TEXT NOT NULL,
            store_type TEXT NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, guild_id, store_type)
          )
        `, (err: any) => {
          if (err) reject(err);
          else resolve();
        });
      });
    });
  }

  static generateKey(storeType: string): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let prefix = '';
    
    // Store-specific prefixes
    switch (storeType) {
      case 'sainsburys': prefix = 'SB'; break;
      case 'asda': prefix = 'AD'; break;
      case 'morrisons': prefix = 'MR'; break;
      case 'waitrose': prefix = 'WR'; break;
      case 'premium': prefix = 'PM'; break;
      default: prefix = 'GN'; break;
    }
    
    let result = prefix + '-';
    for (let i = 0; i < 10; i++) {
      if (i === 4) result += '-';
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  static async createKeys(count: number, duration: number, storeType: string, createdBy: string, guildId: string): Promise<string[]> {
    const keys: string[] = [];
    
    return new Promise((resolve, reject) => {
      const stmt = redeemDb.prepare(`
        INSERT INTO redeem_keys (code, duration, store_type, created_by, guild_id)
        VALUES (?, ?, ?, ?, ?)
      `);

      for (let i = 0; i < count; i++) {
        const code = this.generateKey(storeType);
        keys.push(code);
        stmt.run(code, duration, storeType, createdBy, guildId);
      }

      stmt.finalize((err: any) => {
        if (err) reject(err);
        else resolve(keys);
      });
    });
  }

  static async redeemKey(code: string, userId: string, guildId: string): Promise<{success: boolean, message: string, duration?: number, storeType?: string}> {
    return new Promise((resolve) => {
      redeemDb.get(`
        SELECT * FROM redeem_keys 
        WHERE code = ? AND guild_id = ? AND used = FALSE
      `, [code, guildId], (err: any, row: any) => {
        if (err || !row) {
          resolve({ success: false, message: 'Invalid or already used code!' });
          return;
        }

        const expiresAt = new Date();
        let durationMessage = '';
        
        if (row.duration === -1) {
          // Lifetime key - set expiration to year 2100
          expiresAt.setFullYear(2100);
          durationMessage = `lifetime ${row.store_type} access!`;
        } else if (row.duration < 1440) {
          // Duration in minutes
          expiresAt.setMinutes(expiresAt.getMinutes() + row.duration);
          const hours = Math.floor(row.duration / 60);
          const minutes = row.duration % 60;
          if (hours > 0) {
            durationMessage = `${hours} hour${hours > 1 ? 's' : ''} ${minutes > 0 ? `and ${minutes} minute${minutes > 1 ? 's' : ''}` : ''} of ${row.store_type} access!`;
          } else {
            durationMessage = `${row.duration} minute${row.duration > 1 ? 's' : ''} of ${row.store_type} access!`;
          }
        } else {
          // Duration in days (convert from minutes)
          const days = Math.floor(row.duration / 1440);
          expiresAt.setDate(expiresAt.getDate() + days);
          durationMessage = `${days} day${days > 1 ? 's' : ''} of ${row.store_type} access!`;
        }

        redeemDb.serialize(() => {
          redeemDb.run(`UPDATE redeem_keys SET used = TRUE, used_by = ?, used_at = CURRENT_TIMESTAMP WHERE code = ?`, [userId, code]);
          
          redeemDb.run(`
            INSERT OR REPLACE INTO user_subscriptions 
            (user_id, guild_id, store_type, expires_at) 
            VALUES (?, ?, ?, ?)
          `, [userId, guildId, row.store_type, expiresAt.toISOString()], (err: any) => {
            if (err) {
              resolve({ success: false, message: 'Database error!' });
            } else {
              resolve({ 
                success: true, 
                message: `Redeemed ${durationMessage}`,
                duration: row.duration,
                storeType: row.store_type
              });
            }
          });
        });
      });
    });
  }

  static async getExpiredUsers(guildId: string): Promise<{userId: string, storeType: string}[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT user_id, store_type FROM user_subscriptions 
        WHERE guild_id = ? AND expires_at <= CURRENT_TIMESTAMP
      `, [guildId], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows.map(row => ({ userId: row.user_id, storeType: row.store_type })));
      });
    });
  }

  static async removeExpiredUser(userId: string, guildId: string, storeType: string): Promise<void> {
    return new Promise((resolve, reject) => {
      redeemDb.run(`DELETE FROM user_subscriptions WHERE user_id = ? AND guild_id = ? AND store_type = ?`, [userId, guildId, storeType], (err: any) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  static async getUserSubscription(userId: string, guildId: string): Promise<any> {
    return new Promise((resolve, reject) => {
      redeemDb.get(`SELECT * FROM user_subscriptions WHERE user_id = ? AND guild_id = ?`, [userId, guildId], (err: any, row: any) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static async getAllUserSubscriptions(userId: string, guildId: string): Promise<any[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`SELECT * FROM user_subscriptions WHERE user_id = ? AND guild_id = ? AND expires_at > datetime('now')`, [userId, guildId], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows || []);
      });
    });
  }

  static async getKeyStats(guildId: string): Promise<any> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT 
          store_type,
          duration,
          COUNT(*) as total,
          SUM(CASE WHEN used = TRUE THEN 1 ELSE 0 END) as used
        FROM redeem_keys 
        WHERE guild_id = ?
        GROUP BY store_type, duration
        ORDER BY store_type, duration
      `, [guildId], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static async getAllKeys(guildId: string, used: boolean = false, limit: number = 50): Promise<any[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT code, store_type, duration, created_by, used, used_by, used_at, created_at
        FROM redeem_keys 
        WHERE guild_id = ? AND used = ?
        ORDER BY created_at DESC
        LIMIT ?
      `, [guildId, used ? 1 : 0, limit], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows || []);
      });
    });
  }

  static async getRedemptionHistory(guildId: string, limit: number = 50): Promise<any[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT code, store_type, duration, created_by, used_by, used_at, created_at
        FROM redeem_keys 
        WHERE guild_id = ? AND used = TRUE
        ORDER BY used_at DESC
        LIMIT ?
      `, [guildId, limit], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows || []);
      });
    });
  }

  static async getAllActiveSubscriptions(guildId: string): Promise<any[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT user_id, store_type, expires_at, created_at
        FROM user_subscriptions 
        WHERE guild_id = ? AND expires_at > datetime('now')
        ORDER BY expires_at ASC
      `, [guildId], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows || []);
      });
    });
  }

  static async getAllExpiredSubscriptions(guildId: string, limit: number = 50): Promise<any[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT user_id, store_type, expires_at, created_at
        FROM user_subscriptions 
        WHERE guild_id = ? AND expires_at <= datetime('now')
        ORDER BY expires_at DESC
        LIMIT ?
      `, [guildId, limit], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows || []);
      });
    });
  }

  static async getUserSubscriptionHistory(userId: string, guildId: string): Promise<any[]> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT rk.code, rk.store_type, rk.duration, rk.used_at, us.expires_at, us.created_at
        FROM redeem_keys rk
        LEFT JOIN user_subscriptions us ON rk.used_by = us.user_id AND rk.store_type = us.store_type
        WHERE rk.guild_id = ? AND rk.used_by = ? AND rk.used = TRUE
        ORDER BY rk.used_at DESC
      `, [guildId, userId], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows || []);
      });
    });
  }

  static async getDetailedKeyStats(guildId: string): Promise<any> {
    return new Promise((resolve, reject) => {
      redeemDb.all(`
        SELECT 
          store_type,
          duration,
          COUNT(*) as total_created,
          SUM(CASE WHEN used = TRUE THEN 1 ELSE 0 END) as total_used,
          COUNT(DISTINCT created_by) as unique_creators,
          COUNT(DISTINCT used_by) as unique_redeemers,
          MIN(created_at) as first_created,
          MAX(created_at) as last_created,
          MIN(used_at) as first_redeemed,
          MAX(used_at) as last_redeemed
        FROM redeem_keys 
        WHERE guild_id = ?
        GROUP BY store_type, duration
        ORDER BY store_type, duration
      `, [guildId], (err: any, rows: any[]) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
}