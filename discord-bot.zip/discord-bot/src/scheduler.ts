import * as cron from 'node-cron';
import { Client, TextChannel, EmbedBuilder } from 'discord.js';
import { database } from './database';

export class ScheduledTasks {
  private client: Client;

  constructor(client: Client) {
    this.client = client;
  }

  startAllTasks() {
    // Daily stats report at 9 AM
    cron.schedule('0 9 * * *', () => {
      this.sendDailyStats();
    });

    // Weekly leaderboard on Sundays at 6 PM
    cron.schedule('0 18 * * 0', () => {
      this.sendWeeklyLeaderboard();
    });

    // Database cleanup - remove old records (older than 90 days) every week
    cron.schedule('0 2 * * 1', () => {
      this.cleanupOldRecords();
    });

    console.log('📅 Scheduled tasks started');
  }

  private async sendDailyStats() {
    const guilds = this.client.guilds.cache;
    
    for (const [guildId, guild] of guilds) {
      try {
        const stats = await database.getGuildStats(guildId);
        const logChannel = guild.channels.cache.find(c => 
          (c.name === 'barcode-log' || c.name === 'general') && c.isTextBased()
        ) as TextChannel;

        if (!logChannel || !stats) continue;

        const embed = new EmbedBuilder()
          .setColor('#0099ff')
          .setTitle('📊 Daily Statistics Report')
          .addFields(
            { name: 'Total Barcodes', value: stats.totalBarcodes.toString(), inline: true },
            { name: 'Active Users', value: stats.uniqueUsers.toString(), inline: true },
            { name: 'Average Price', value: `£${(stats.avgPrice || 0).toFixed(2)}`, inline: true },
            { name: 'Sainsbury\'s', value: stats.sainsburysCount.toString(), inline: true },
            { name: 'ASDA', value: stats.asdaCount.toString(), inline: true },
            { name: 'Morrisons', value: stats.morrisonsCount.toString(), inline: true }
          )
          .setTimestamp()
          .setFooter({ text: 'Daily Report - Barcode Studio Bot' });

        await logChannel.send({ embeds: [embed] });
      } catch (error) {
        console.error(`Failed to send daily stats for guild ${guildId}:`, error);
      }
    }
  }

  private async sendWeeklyLeaderboard() {
    const guilds = this.client.guilds.cache;
    
    for (const [guildId, guild] of guilds) {
      try {
        const topUsers = await database.getTopUsers(guildId, 10);
        const logChannel = guild.channels.cache.find(c => 
          (c.name === 'barcode-log' || c.name === 'general') && c.isTextBased()
        ) as TextChannel;

        if (!logChannel || topUsers.length === 0) continue;

        const leaderboardText = topUsers
          .map((user, index) => 
            `${index + 1}. ${user.username[0]}***** - ${user.totalBarcodes} barcodes`
          )
          .join('\n');

        const embed = new EmbedBuilder()
          .setColor('#ffd700')
          .setTitle('🏆 Weekly Leaderboard')
          .setDescription(leaderboardText)
          .addFields(
            { name: 'Top Performer', value: `${topUsers[0].username[0]}***** with ${topUsers[0].totalBarcodes} barcodes!`, inline: false }
          )
          .setTimestamp()
          .setFooter({ text: 'Weekly Report - Barcode Studio Bot' });

        await logChannel.send({ embeds: [embed] });
      } catch (error) {
        console.error(`Failed to send weekly leaderboard for guild ${guildId}:`, error);
      }
    }
  }

  private async cleanupOldRecords() {
    // Note: This would need to be implemented in the database class
    console.log('🧹 Running database cleanup...');
    // Implementation would go here
  }
}