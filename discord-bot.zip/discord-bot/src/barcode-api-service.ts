// Enhanced barcode API integration with multiple providers
export interface BarcodeApiConfig {
  primary: string;
  fallback: string[];
  format: 'auto' | 'code128' | 'ean13';
}

export class BarcodeApiService {
  private static readonly API_CONFIGS: Record<string, BarcodeApiConfig> = {
    barcodeapi: {
      primary: 'https://barcodeapi.org/api/auto/',
      fallback: [
        'https://barcodeapi.org/api/code128/',
        'https://barcodeapi.org/api/ean/'
      ],
      format: 'auto'
    },
    barcodelookup: {
      primary: 'https://api.barcodelookup.com/v3/products?barcode=',
      fallback: [],
      format: 'auto'
    },
    quickchart: {
      primary: 'https://quickchart.io/barcode?type=code128&text=',
      fallback: [
        'https://quickchart.io/barcode?type=ean13&text=',
        'https://quickchart.io/barcode?type=code39&text='
      ],
      format: 'code128'
    }
  };

  static generateBarcodeImageUrl(
    barcodeData: string, 
    provider: 'barcodeapi' | 'quickchart' = 'quickchart',
    options: {
      width?: number;
      height?: number;
      format?: string;
    } = {}
  ): string {
    const config = this.API_CONFIGS[provider];
    const encodedData = encodeURIComponent(barcodeData);
    
    let url = `${config.primary}${encodedData}`;
    
    // Add options for specific providers
    if (provider === 'quickchart') {
      const params = new URLSearchParams();
      if (options.width) params.append('width', options.width.toString());
      if (options.height) params.append('height', options.height.toString());
      if (params.toString()) {
        url += `&${params.toString()}`;
      }
    }
    
    return url;
  }

  static getFallbackUrls(barcodeData: string, provider: 'barcodeapi' | 'quickchart' = 'barcodeapi'): string[] {
    const config = this.API_CONFIGS[provider];
    const encodedData = encodeURIComponent(barcodeData);
    
    return config.fallback.map(fallbackUrl => `${fallbackUrl}${encodedData}`);
  }

  static async validateBarcodeImage(url: string): Promise<boolean> {
    try {
      const response = await fetch(url, { method: 'HEAD' });
      const contentType = response.headers.get('content-type');
      return response.ok && Boolean(contentType?.startsWith('image/'));
    } catch {
      return false;
    }
  }

  static generateMultipleFormats(barcodeData: string): Record<string, string> {
    return {
      code128: this.generateBarcodeImageUrl(barcodeData, 'quickchart', { format: 'code128' }),
      code128_large: this.generateBarcodeImageUrl(barcodeData, 'quickchart', { 
        width: 400, 
        height: 120, 
        format: 'code128' 
      }),
      code128_small: this.generateBarcodeImageUrl(barcodeData, 'quickchart', { 
        width: 250, 
        height: 80, 
        format: 'code128' 
      })
    };
  }
}