import { createCanvas } from 'canvas';
import JsBarcode from 'jsbarcode';
import { generateSainsburysBarcode, generateAsdaBarcode, generateMorrisonsBarcode } from './barcode-utils';

export interface LocalBarcodeResult {
  original: string;
  generated: string;
  type: 'sainsburys' | 'asda' | 'morrisons';
  price: number;
  visualBarcode: string;
  imageBuffer: Buffer;
}

export function generateLocalBarcode(
  type: 'sainsburys' | 'asda' | 'morrisons', 
  barcode: string, 
  price: number,
  options: {
    width?: number;
    height?: number;
    fontSize?: number;
    textMargin?: number;
  } = {}
): LocalBarcodeResult {
  let generated: string;

  // Generate the barcode based on store type
  switch (type) {
    case 'sainsburys':
      generated = generateSainsburysBarcode(barcode, price);
      break;
    case 'asda':
      generated = generateAsdaBarcode(barcode, price);
      break;
    case 'morrisons':
      generated = generateMorrisonsBarcode(barcode, price);
      break;
    default:
      throw new Error('Invalid barcode type');
  }

  // Create canvas for barcode generation
  const canvas = createCanvas(
    options.width || 400, 
    options.height || 120
  );

  // Generate Code 128 barcode using JsBarcode
  JsBarcode(canvas, generated, {
    format: "CODE128",
    width: 2,
    height: 80,
    displayValue: false,  // Hide numbers under barcode for privacy
    margin: 10,
    background: "#ffffff",
    lineColor: "#000000"
  });

  // Convert canvas to buffer
  const imageBuffer = canvas.toBuffer('image/png');

  // Create simple visual barcode representation (ASCII art)
  const visualBarcode = createVisualCode128();

  return {
    original: barcode,
    generated,
    type,
    price,
    visualBarcode,
    imageBuffer
  };
}

function createVisualCode128(): string {
  // Create a Code 128 style visual barcode pattern
  let visualBarcode = '';
  
  visualBarcode += '```\n';
  visualBarcode += '║ ▌ ║ ▌▌║  ▌║▌ ║ ▌║▌▌║ ▌ ║▌║ ▌▌║  ▌║ ▌║ ▌ ║\n';
  visualBarcode += '║ ▌ ║ ▌▌║  ▌║▌ ║ ▌║▌▌║ ▌ ║▌║ ▌▌║  ▌║ ▌║ ▌ ║\n';
  visualBarcode += '║ ▌ ║ ▌▌║  ▌║▌ ║ ▌║▌▌║ ▌ ║▌║ ▌▌║  ▌║ ▌║ ▌ ║\n';
  visualBarcode += '```';
  
  return visualBarcode;
}

// Enhanced barcode generation with different styles
export function generateStyledBarcode(
  type: 'sainsburys' | 'asda' | 'morrisons', 
  barcode: string, 
  price: number,
  style: 'compact' | 'standard' | 'large' = 'standard'
): LocalBarcodeResult {
  let options;
  
  switch (style) {
    case 'compact':
      options = { width: 250, height: 80, fontSize: 10, textMargin: 4 };
      break;
    case 'standard':
      options = { width: 400, height: 120, fontSize: 14, textMargin: 8 };
      break;
    case 'large':
      options = { width: 500, height: 150, fontSize: 16, textMargin: 12 };
      break;
  }
  
  return generateLocalBarcode(type, barcode, price, options);
}

// Validation functions (keeping from original)
export function calculateDiscount(originalPrice: number, discountPercent: number = 65): number {
  const discountedPrice = originalPrice * (1 - discountPercent / 100);
  // Round to nearest 50p
  return Math.round(discountedPrice * 2) / 2;
}

export function validatePrice(price: number, type: 'sainsburys' | 'asda' | 'morrisons'): string | null {
  if (price <= 0) return 'Price must be greater than 0';
  if (price > 999.99) return 'Price must be less than £1000';
  
  switch (type) {
    case 'sainsburys':
      if (price > 999.99) return 'Sainsbury\'s format supports prices up to £999.99';
      break;
    case 'asda':
      if (price > 9.99) return 'ASDA format supports prices up to £9.99';
      break;
    case 'morrisons':
      // No specific limit for Morrisons
      break;
  }
  
  return null;
}

export function validateBarcode(barcode: string): string | null {
  const cleaned = barcode.replace(/\D/g, '');
  if (cleaned.length < 8) return 'Barcode must be at least 8 digits';
  if (cleaned.length > 14) return 'Barcode must be at most 14 digits';
  return null;
}