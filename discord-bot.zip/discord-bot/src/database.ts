import sqlite3 from 'sqlite3';
import { promisify } from 'util';

export interface BarcodeRecord {
  id?: number;
  userId: string;
  username: string;
  guildId: string;
  barcodeType: 'sainsburys' | 'asda' | 'morrisons' | 'waitrose';
  originalBarcode: string;
  generatedBarcode: string;
  price: number;
  timestamp: string;
}

export interface UserStats {
  userId: string;
  username: string;
  totalBarcodes: number;
  sainsburysCount: number;
  asdaCount: number;
  morrisonsCount: number;
  waitroseCount: number;
  lastUsed: string;
}

class Database {
  private db: sqlite3.Database;

  constructor() {
    this.db = new sqlite3.Database('barcodes.db');
    this.initTables();
  }

  private initTables() {
    const createTable = `
      CREATE TABLE IF NOT EXISTS barcode_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId TEXT NOT NULL,
        username TEXT NOT NULL,
        guildId TEXT NOT NULL,
        barcodeType TEXT NOT NULL,
        originalBarcode TEXT NOT NULL,
        generatedBarcode TEXT NOT NULL,
        price REAL NOT NULL,
        timestamp TEXT NOT NULL
      )
    `;
    this.db.run(createTable);
  }

  async saveBarcode(record: BarcodeRecord): Promise<void> {
    return new Promise((resolve, reject) => {
      const stmt = this.db.prepare(`
        INSERT INTO barcode_history 
        (userId, username, guildId, barcodeType, originalBarcode, generatedBarcode, price, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run(
        record.userId,
        record.username,
        record.guildId,
        record.barcodeType,
        record.originalBarcode,
        record.generatedBarcode,
        record.price,
        record.timestamp,
        function(err: any) {
          if (err) reject(err);
          else resolve();
        }
      );
      stmt.finalize();
    });
  }

  async getUserHistory(userId: string, guildId: string, limit: number = 10): Promise<BarcodeRecord[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT * FROM barcode_history 
         WHERE userId = ? AND guildId = ? 
         ORDER BY timestamp DESC 
         LIMIT ?`,
        [userId, guildId, limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  async getUserStats(userId: string, guildId: string): Promise<UserStats | null> {
    return new Promise((resolve, reject) => {
      this.db.get(
        `SELECT 
           userId,
           username,
           COUNT(*) as totalBarcodes,
           SUM(CASE WHEN barcodeType = 'sainsburys' THEN 1 ELSE 0 END) as sainsburysCount,
           SUM(CASE WHEN barcodeType = 'asda' THEN 1 ELSE 0 END) as asdaCount,
           SUM(CASE WHEN barcodeType = 'morrisons' THEN 1 ELSE 0 END) as morrisonsCount,
           SUM(CASE WHEN barcodeType = 'waitrose' THEN 1 ELSE 0 END) as waitroseCount,
           MAX(timestamp) as lastUsed
         FROM barcode_history 
         WHERE userId = ? AND guildId = ?
         GROUP BY userId`,
        [userId, guildId],
        (err, row: any) => {
          if (err) reject(err);
          else resolve(row || null);
        }
      );
    });
  }

  async getTopUsers(guildId: string, limit: number = 10): Promise<UserStats[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT 
           userId,
           username,
           COUNT(*) as totalBarcodes,
           SUM(CASE WHEN barcodeType = 'sainsburys' THEN 1 ELSE 0 END) as sainsburysCount,
           SUM(CASE WHEN barcodeType = 'asda' THEN 1 ELSE 0 END) as asdaCount,
           SUM(CASE WHEN barcodeType = 'morrisons' THEN 1 ELSE 0 END) as morrisonsCount,
           SUM(CASE WHEN barcodeType = 'waitrose' THEN 1 ELSE 0 END) as waitroseCount,
           MAX(timestamp) as lastUsed
         FROM barcode_history 
         WHERE guildId = ?
         GROUP BY userId 
         ORDER BY totalBarcodes DESC 
         LIMIT ?`,
        [guildId, limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  async getGuildStats(guildId: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.db.get(
        `SELECT 
           COUNT(*) as totalBarcodes,
           COUNT(DISTINCT userId) as uniqueUsers,
           SUM(CASE WHEN barcodeType = 'sainsburys' THEN 1 ELSE 0 END) as sainsburysCount,
           SUM(CASE WHEN barcodeType = 'asda' THEN 1 ELSE 0 END) as asdaCount,
           SUM(CASE WHEN barcodeType = 'morrisons' THEN 1 ELSE 0 END) as morrisonsCount,
           SUM(CASE WHEN barcodeType = 'waitrose' THEN 1 ELSE 0 END) as waitroseCount,
           AVG(price) as avgPrice,
           MAX(timestamp) as lastActivity
         FROM barcode_history 
         WHERE guildId = ?`,
        [guildId],
        (err, row: any) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }
}

export const database = new Database();