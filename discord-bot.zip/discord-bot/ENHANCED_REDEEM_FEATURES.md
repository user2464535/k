# Enhanced Redeem Key Panel Features

## Overview
The Discord bot now supports an enhanced user-focused redeem key panel with improved UI and new duration options.

## New Features

### 1. User-Focused Redeem Panel (`!setupredeemkeypanel`)
- **Clean UI**: Only shows user-relevant buttons (no admin controls)
- **Modern Design**: Premium portal aesthetic with better visual hierarchy
- **User Actions**:
  - 🔑 **Redeem Code** - Enter access keys
  - ⏰ **Time Left** - Check remaining access time
  - ❓ **Get Help** - Learn how to obtain codes

### 2. Enhanced Duration Support

#### Available Duration Formats:
- **Minutes**: `1m`, `5m`, `30m`, `59m`
- **Hours**: `1h`, `2h`, `12h`, `23h`
- **Days**: `1d`, `7d`, `31d` (or legacy format: `1`, `7`, `31`)
- **Lifetime**: `lifetime` (permanent access)

#### Examples:
- `1m` - 1 minute access (perfect for testing)
- `30m` - 30 minutes access
- `2h` - 2 hours access
- `1d` - 1 day access
- `lifetime` - Permanent access (never expires)

### 3. Security Features
- **One-time Use**: Each key can only be redeemed once
- **Automatic Expiration**: Users are automatically removed from roles when access expires
- **Fast Checking**: System checks for expired users every 30 seconds
- **Audit Logging**: All redemptions are logged in the database

### 4. Improved User Experience
- **Better Duration Display**: Shows human-readable formats (e.g., "2h 30m", "Lifetime")
- **Enhanced Embed Design**: Premium portal styling with better visual hierarchy
- **Responsive UI**: Works well on both desktop and mobile Discord clients
- **Clear Feedback**: Detailed success/error messages for all actions

## Commands

### For Server Owners:
- `!setupredeemkeypanel` - Creates user-focused redeem panel (no admin buttons)
- `!setupredeempanel` - Creates legacy redeem panel (with admin buttons)
- `!adminpanel` - Access comprehensive admin control panel

### For Users:
- Use the **Redeem Code** button in the panel
- Use the **Time Left** button to check remaining access
- Use `/timeleft` slash command as alternative

## Key Generation Examples

When generating keys through the admin interface, use these formats:

### Duration Input Examples:
```
1m          # 1 minute
30m         # 30 minutes  
1h          # 1 hour
2h          # 2 hours
1d          # 1 day
7d          # 7 days
31d         # 31 days
lifetime    # Permanent access
```

### Store Types:
- `sainsburys` - Sainsbury's store access
- `asda` - ASDA store access  
- `morrisons` - Morrisons store access
- `premium` - All stores access

## Database Schema

The system stores durations in minutes for precise control:
- **1 minute** = 1
- **1 hour** = 60 minutes
- **1 day** = 1440 minutes
- **Lifetime** = -1 (special value)

## Benefits

1. **Flexibility**: Support for very short testing periods (1 minute) to permanent access
2. **User-Friendly**: Clean interface focused on what users actually need
3. **Secure**: One-time use codes with automatic role removal
4. **Responsive**: Fast expiration checking for short-duration keys
5. **Comprehensive**: Detailed logging and statistics for administrators

## Migration Notes

- Existing keys continue to work normally
- Legacy duration formats (numbers only) still supported
- Admin panels remain unchanged for server owners
- New user panel is completely separate from admin functionality

## Technical Implementation

- **Fast Expiration**: 30-second check interval for responsive role removal
- **Precise Duration**: Minute-level precision for all durations
- **Lifetime Support**: Special handling for permanent access keys
- **Format Flexibility**: Multiple input formats automatically parsed
- **Enhanced Display**: Human-readable duration formatting throughout UI