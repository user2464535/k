import { generateLocalBarcode } from './src/local-barcode-generator';
import { createCanvas } from 'canvas';
import JsBarcode from 'jsbarcode';
import * as fs from 'fs';

console.log('🔍 Comparison: Barcode with vs without numbers\n');

// Test the new version (no numbers)
const resultNoNumbers = generateLocalBarcode('sainsburys', '1234567890123', 5.99);
fs.writeFileSync('barcode-no-numbers.png', resultNoNumbers.imageBuffer);
console.log('✅ Generated barcode WITHOUT numbers: barcode-no-numbers.png');
console.log(`   Size: ${resultNoNumbers.imageBuffer.length} bytes`);

// Create comparison with numbers for reference
const canvas = createCanvas(400, 120);
JsBarcode(canvas, resultNoNumbers.generated, {
  format: "CODE128",
  width: 2,
  height: 80,
  displayValue: true,  // Show numbers for comparison
  fontSize: 14,
  textMargin: 8,
  margin: 10,
  background: "#ffffff",
  lineColor: "#000000"
});

const withNumbersBuffer = canvas.toBuffer('image/png');
fs.writeFileSync('barcode-with-numbers.png', withNumbersBuffer);
console.log('📊 Generated barcode WITH numbers: barcode-with-numbers.png');
console.log(`   Size: ${withNumbersBuffer.length} bytes`);

console.log('\n🎯 Results:');
console.log('• barcode-no-numbers.png = Clean barcode (no text below)');
console.log('• barcode-with-numbers.png = Comparison (shows text below)');
console.log('\n✅ Discord bot now sends barcodes WITHOUT visible numbers!');