# ⏰ Time Left Command Documentation

## New Slash Command: `/timeleft`

### 🎯 Purpose
Check how much access time you have remaining for store-specific barcode generation.

### 🔧 Usage
```
/timeleft
```
**No parameters required** - Shows your personal access status

### 📊 What It Shows

#### ✅ If You Have Active Access:
- **Store-specific access**: Shows each store you have access to
- **Precise time remaining**: Days, hours, and minutes left
- **Expiration dates**: Exact date and time when access expires
- **Visual indicators**: Emojis for each store type

#### ❌ If You Have No Access:
- Clear message that you don't have active access
- Instructions on how to get access
- Links to redeem process

#### ⏰ If Access Has Expired:
- Shows that subscriptions have ended
- Prompts to use new redeem codes

### 📋 Example Outputs

#### Active Access Example:
```
⏰ Your Access Time Remaining

🛒 Sainsburys Access
⏱️ 2 days, 14 hours, 32 minutes remaining
📅 Expires: 10/5/2025, 2:30:15 PM

🟢 ASDA Access  
⏱️ 8 hours, 45 minutes remaining
📅 Expires: 10/3/2025, 11:45:22 PM

⭐ Premium Access
⏱️ 29 days, 23 hours, 12 minutes remaining
📅 Expires: 11/2/2025, 10:15:30 AM
```

#### No Access Example:
```
⏰ Access Status

❌ No active access found

You don't currently have access to any store barcodes.

🔑 Use a redeem code to get access!

🎫 Get Access: Ask an admin for a redeem code
📝 Redeem Code: Use the redeem panel to enter your code
```

### 🏪 Store Types & Emojis

| Store | Emoji | Access Type |
|-------|-------|-------------|
| Sainsburys | 🛒 | Store-specific access |
| ASDA | 🟢 | Store-specific access |
| Morrisons | 🔵 | Store-specific access |
| Premium | ⭐ | All stores access |

### ⚡ Features

- **Real-time calculation**: Shows exact time remaining down to minutes
- **Multiple subscriptions**: Displays all active access types
- **Privacy-focused**: Only shows your own access (ephemeral response)
- **User-friendly**: Clear, easy-to-read format with emojis
- **Automatic filtering**: Only shows non-expired subscriptions

### 🔐 Privacy & Security

- **Personal information**: Only you can see your access times
- **Ephemeral responses**: Messages disappear after interaction
- **No sensitive data**: No codes or personal identifiers shown
- **Guild-specific**: Only shows access for the current server

### 📱 Usage Tips

1. **Check before generating**: Use `/timeleft` before creating barcodes
2. **Plan ahead**: See when you need to renew access
3. **Track multiple stores**: Monitor all your active subscriptions
4. **Verify redemption**: Confirm new codes activated properly

### 🔧 Technical Details

- **Command Type**: Slash command
- **Permissions**: Available to all users
- **Response Type**: Ephemeral (private)
- **Data Source**: SQLite user_subscriptions table
- **Real-time**: Calculates remaining time at request time

### 🎯 Integration

Works seamlessly with:
- **Redeem system**: Shows time from redeemed codes
- **Admin panel**: Complements admin monitoring tools
- **Role assignment**: Reflects current role-based access
- **Expiration system**: Shows same data used for automatic cleanup

---

**Example Usage Flow:**
1. User redeems a code: `SB-ABCD-EFGH23` (5-day Sainsburys access)
2. User checks time: `/timeleft`
3. Bot shows: "4 days, 23 hours, 45 minutes remaining"
4. User can track access and plan accordingly

This command provides users with full transparency about their access status and remaining time! ⏰✨