# 🚀 Quick Setup Guide

## Prerequisites
- Node.js 18+ installed
- Discord Bot Token and Client ID
- Discord Server with appropriate permissions

## Installation Steps

### 1. Install Dependencies
```bash
cd discord-bot
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your bot credentials:
# DISCORD_TOKEN=your_bot_token_here
# CLIENT_ID=your_bot_client_id_here
```

### 3. Discord Server Setup

#### Required Roles
Create these roles in your Discord server:
- `sainsburys` - Access to Sainsbury's commands
- `asda` - Access to ASDA commands  
- `morrisons` - Access to Morrisons commands

#### Optional Channels
Create these channels for organized access:
- `#sainsburys` - Sainsbury's barcode generation
- `#asda` - ASDA barcode generation
- `#morrisons` - Morrisons barcode generation

#### Log Channels (Optional)
Create these channels for action logging:
- `#sainsburys-log` - Sainsbury's activity logs
- `#asda-log` - ASDA activity logs
- `#morrisons-log` - Morrisons activity logs
- `#barcode-log` - General barcode activities

### 4. Bot Permissions
Ensure your bot has these permissions:
- Send Messages
- Send Messages in Threads
- Embed Links
- Attach Files
- Read Message History
- Use Slash Commands
- Send Private Messages

### 5. Start the Bot
```bash
# Production
npm start

# Development with auto-restart
npm run dev
```

## Testing

### Test Barcode Generation
```bash
npx ts-node test-barcodes.ts
```

### Test API Integration
```bash
npx ts-node barcode-api-demo.ts
```

## Usage Examples

### Basic Commands
```
/sainsburys barcode:1234567890123 price:5.99
/asda barcode:9876543210987 price:3.50 calculate-discount:true
/morrisons barcode:5555666677778 price:7.25
```

### Utility Commands
```
/mystats
/myhistory limit:10
/leaderboard limit:5
/calculate original-price:10.00 discount:70
/help topic:commands
```

## Features Overview

### 🔢 Barcode Generation
- **Sainsbury's**: 22-digit format with checksum
- **ASDA**: 26-digit format with Luhn validation
- **Morrisons**: Custom format with price encoding

### 🖼️ API Integration
- **Primary API**: barcodeapi.org (free, reliable)
- **Fallback API**: quickchart.io (high-quality images)
- **Multiple Formats**: Auto-detection, Code128, high-res

### 🛡️ Security & Privacy
- **Role-Based Access**: Requires specific roles or channels
- **Masked Logging**: Usernames shown as `u*****`
- **No Data Exposure**: Generated codes not displayed
- **Private Delivery**: Barcodes sent via DM

### 📊 Statistics & Analytics
- **Personal Stats**: Individual usage tracking
- **Server Leaderboards**: Top users and activity
- **Automated Reports**: Daily stats and weekly summaries
- **History Tracking**: Complete audit trail

## Troubleshooting

### Common Issues

**Bot not responding:**
- Check if bot is online in Discord
- Verify token and client ID are correct
- Ensure bot has required permissions

**Permission denied errors:**
- User needs appropriate role (`sainsburys`, `asda`, `morrisons`)
- Or user must be in corresponding channel
- Check role names are exact match (case-sensitive)

**Database errors:**
- Ensure SQLite3 is installed
- Check file permissions for `barcodes.db`
- Verify disk space availability

**API errors:**
- Barcode APIs are external services
- Fallback URLs provided for reliability
- Visual barcode still shown if API fails

### Support
- Check logs for detailed error messages
- Use `/help` command for in-bot assistance
- Test with `npx ts-node test-barcodes.ts`

## Production Deployment

### Environment Variables
```env
DISCORD_TOKEN=your_production_bot_token
CLIENT_ID=your_production_client_id
NODE_ENV=production
```

### Process Management
```bash
# Using PM2
npm install -g pm2
pm2 start src/index-text.ts --name barcode-bot

# Using systemd
sudo systemctl enable barcode-bot
sudo systemctl start barcode-bot
```

### Monitoring
- Check bot status in Discord
- Monitor database growth
- Review error logs regularly
- Update dependencies monthly

---
**Ready to generate barcodes! 🎯**