import { generateBarcodeText } from './src/text-barcode-generator';

// Test the barcode generation
console.log('🧪 Testing Barcode Generation...\n');

// Test Sainsbury's
const sainsburysResult = generateBarcodeText('sainsburys', '1234567890123', 5.99);
console.log('🔶 Sainsbury\'s Test:');
console.log(`Original: ${sainsburysResult.original}`);
console.log(`Price: £${sainsburysResult.price.toFixed(2)}`);
console.log(`Type: ${sainsburysResult.type}`);
console.log(`Primary Barcode API: ${sainsburysResult.barcodeImageUrl}`);
console.log(`Fallback URLs: ${sainsburysResult.fallbackUrls.join(', ')}`);
console.log(sainsburysResult.visualBarcode);
console.log('\n');

// Test ASDA
const asdaResult = generateBarcodeText('asda', '9876543210987', 3.50);
console.log('🟢 ASDA Test:');
console.log(`Original: ${asdaResult.original}`);
console.log(`Price: £${asdaResult.price.toFixed(2)}`);
console.log(`Type: ${asdaResult.type}`);
console.log(`Barcode Image URL: ${asdaResult.barcodeImageUrl}`);
console.log(asdaResult.visualBarcode);
console.log('\n');

// Test Morrisons
const morrisonsResult = generateBarcodeText('morrisons', '5555666677778', 7.25);
console.log('🔵 Morrisons Test:');
console.log(`Original: ${morrisonsResult.original}`);
console.log(`Price: £${morrisonsResult.price.toFixed(2)}`);
console.log(`Type: ${morrisonsResult.type}`);
console.log(`Barcode Image URL: ${morrisonsResult.barcodeImageUrl}`);
console.log(morrisonsResult.visualBarcode);

console.log('\n✅ All tests completed successfully!');