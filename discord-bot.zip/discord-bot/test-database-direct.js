// Test database schema with correct path
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Use the same path as the RedeemSystem
const dbPath = path.join(__dirname, 'redeem-keys.db'); // Since we're in root, not src
console.log('Database path:', dbPath);

const db = new sqlite3.Database(dbPath);

console.log('🔍 Testing database schema...\n');

// Test 1: Check if store_type column exists in redeem_keys table
db.all("PRAGMA table_info(redeem_keys)", (err, rows) => {
  if (err) {
    console.error('❌ Error getting table info:', err);
    return;
  }
  
  console.log('📋 Redeem Keys Table Schema:');
  rows.forEach(column => {
    console.log(`  - ${column.name}: ${column.type} ${column.notnull ? '(NOT NULL)' : ''} ${column.dflt_value ? `DEFAULT ${column.dflt_value}` : ''}`);
  });
  
  const hasStoreType = rows.some(column => column.name === 'store_type');
  console.log(`\n✅ store_type column exists: ${hasStoreType ? '✓' : '❌'}`);
  
  if (rows.length === 0) {
    console.log('❌ No table found - table may not exist');
  }
  
  db.close();
});