import { generateBarcodeText, validateBarcode, validatePrice, calculateDiscount } from './src/text-barcode-generator';

console.log('🔒 Privacy-Focused Barcode Bot Test\n');

// Test validation
console.log('✅ Testing input validation...');
console.log('Barcode validation:', validateBarcode('1234567890123') || 'Valid');
console.log('Price validation:', validatePrice(5.99, 'sainsburys') || 'Valid');

// Test discount calculation
console.log('\n💰 Testing discount calculation...');
const originalPrice = 10.00;
const discountedPrice = calculateDiscount(originalPrice, 65);
console.log(`Original: £${originalPrice.toFixed(2)} → Discounted: £${discountedPrice.toFixed(2)}`);

// Test barcode generation (privacy focused)
console.log('\n🔢 Testing privacy-focused barcode generation...');
const result = generateBarcodeText('sainsburys', '1234567890123', 5.99);

console.log('📊 Generated Information:');
console.log(`- Store: ${result.type}`);
console.log(`- Original Barcode: ${result.original}`);
console.log(`- Price: £${result.price.toFixed(2)}`);
console.log('\n📱 Visual Barcode for User:');
console.log(result.visualBarcode);

console.log('\n✅ Privacy test completed - no sensitive data exposed!');