import { generateBarcodeText } from './src/text-barcode-generator';
import { BarcodeApiService } from './src/barcode-api-service';

console.log('🚀 Barcode API Integration Demo\n');

// Test basic generation
const result = generateBarcodeText('sainsburys', '1234567890123', 5.99);

console.log('📊 Generated Barcode Details:');
console.log(`- Store: ${result.type.charAt(0).toUpperCase() + result.type.slice(1)}`);
console.log(`- Original: ${result.original}`);
console.log(`- Price: £${result.price.toFixed(2)}`);
console.log(`- Generated: ${result.generated}`);

console.log('\n🌐 API Integration:');
console.log(`- Primary URL: ${result.barcodeImageUrl}`);
console.log(`- Fallback URLs: ${result.fallbackUrls.length}`);

console.log('\n🔗 All Available Formats:');
const multiFormats = BarcodeApiService.generateMultipleFormats(result.generated);
Object.entries(multiFormats).forEach(([format, url]) => {
  console.log(`- ${format.toUpperCase()}: ${url}`);
});

console.log('\n📱 Visual Preview:');
console.log(result.visualBarcode);

console.log('\n✅ Discord Bot Features:');
console.log('- ✅ Real barcode images via API');
console.log('- ✅ Multiple fallback URLs for reliability');
console.log('- ✅ Privacy-focused (no sensitive data shown)');
console.log('- ✅ Professional visual presentation');
console.log('- ✅ Ready for Discord DM delivery');

console.log('\n🎯 Ready to scan and use!');