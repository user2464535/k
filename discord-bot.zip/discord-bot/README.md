# 🤖 Barcode Studio Discord Bot

A com#### **�️ Barcode API Integration**
- **Real Barcode Images**: Generated using external APIs (barcodeapi.org, quickchart.io)
- **Multiple Formats**: Auto, Code128, and high-resolution options
- **Fallback URLs**: Multiple providers ensure reliability
- **Privacy-Focused**: No sensitive barcode numbers or generation formulas shown
- **Scannable Output**: Ready for actual use at checkout systemsrehensive Discord bot for generating retail barcodes with advanced features including role-based permissions, channel restrictions, user statistics, leaderboards, and automated logging.

## ✨ Features

### 🔢 Barcode Generation
- **Sainsbury's Format**: `91 + 13-digit barcode + 6-digit price + checksum`
- **ASDA Format**: `330 + 13-digit barcode + 000 + 2-digit price + 2056 + luhn checksum`
- **Morrisons Format**: `92 + 13-digit barcode + 00003{price}00027`

### 🛡️ Security & Permissions
- **Role-Based Access**: Users need specific roles (`sainsburys`, `asda`, `morrisons`)
- **Channel Restrictions**: Commands work in designated channels
- **Action Logging**: All activities logged with masked usernames (`user*****`)

### 📊 Statistics & Analytics
- **Personal Statistics**: View your barcode generation history
- **Server Leaderboards**: See top users and their statistics
- **Guild Analytics**: Server-wide statistics and insights
- **Scheduled Reports**: Daily stats and weekly leaderboards

### 🎯 Advanced Features
- **Discount Calculator**: Automatic 65% discount with 50p rounding
- **Price Validation**: Format-specific price limits
- **Barcode Validation**: Input validation for all barcode formats
- **Visual Barcodes**: Generated barcode images with store branding
- **Database Storage**: SQLite database for persistent data

## 🚀 Commands

### Barcode Generation
- `/sainsburys <barcode> <price> [calculate-discount]` - Generate Sainsbury's barcode
- `/asda <barcode> <price> [calculate-discount]` - Generate ASDA barcode  
- `/morrisons <barcode> <price> [calculate-discount]` - Generate Morrisons barcode

**New Features:**
- 📩 **DM Delivery**: Barcodes sent privately to your DMs
- �️ **Real Barcode Images**: Generated via external API services for actual scanning
- �📊 **Visual Barcodes**: Clean barcode representation without exposing sensitive data
- 🔒 **Privacy Focus**: No barcode numbers or formulas displayed for security
- 🔄 **Fallback System**: Multiple API providers for reliability
- 🎯 **Scannable**: Ready-to-use barcodes for checkout systems

### Statistics & History
- `/mystats` - View your personal statistics
- `/myhistory [limit]` - View your recent barcode history (max 20)
- `/leaderboard [limit]` - View server leaderboard (max 25)
- `/serverstats` - View server-wide statistics

### Utilities
- `/calculate <original-price> [discount]` - Calculate discounted prices
- `/help [topic]` - Get help (commands, permissions, types, pricing)

## 🏗️ Setup

### Prerequisites
```bash
# macOS (required for canvas dependency)
brew install pkg-config cairo pango libpng jpeg giflib librsvg

# Or use a compatible Node.js version (18 or 20)
nvm use 18
```

### Installation
```bash
# Navigate to discord-bot directory
cd discord-bot

# Install dependencies
npm install

# Create environment file
cp .env.example .env
```

### Environment Variables
```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_bot_client_id_here
```

### Running the Bot
```bash
# Production (lightweight version - no canvas dependency)
npm start

# Development (with auto-restart)
npm run dev

# Alternative with canvas images (requires system dependencies)
npm run start-canvas
```

### Testing
```bash
# Test barcode generation
npx ts-node test-barcodes.ts
```

## 🏢 Server Setup

### Required Roles
Create these roles in your Discord server:
- `sainsburys` - Access to Sainsbury's commands
- `asda` - Access to ASDA commands  
- `morrisons` - Access to Morrisons commands

### Required Channels
Create these channels for command access:
- `#sainsburys` - Sainsbury's barcode generation
- `#asda` - ASDA barcode generation
- `#morrisons` - Morrisons barcode generation

### Log Channels (Optional)
Create these channels for action logging:
- `#sainsburys-log` - Sainsbury's activity logs
- `#asda-log` - ASDA activity logs
- `#morrisons-log` - Morrisons activity logs
- `#barcode-log` - General barcode activities

## 🔧 Configuration

### Price Limits
- **Sainsbury's**: Up to £999.99 (6-digit price encoding)
- **ASDA**: Up to £9.99 (2-digit price encoding)  
- **Morrisons**: No specific limit

### Discount System
- **Default Discount**: 65% off original price
- **Rounding**: Prices rounded to nearest 50p
- **Custom Discounts**: Use `/calculate` for custom percentages

### Database
- **Type**: SQLite (barcodes.db)
- **Automatic Creation**: Database and tables created on first run
- **Data Retention**: All barcode generation history stored

## 📝 Usage Examples

```bash
# Generate Sainsbury's barcode with discount
/sainsburys barcode:1234567890123 price:5.99 calculate-discount:true

# Generate ASDA barcode  
/asda barcode:9876543210987 price:2.50

# View personal stats
/mystats

# Check server leaderboard
/leaderboard limit:10

# Calculate 70% discount
/calculate original-price:10.00 discount:70
```

## 🤝 Permissions System

### Role-Based Access
Users must have the corresponding role to use commands:
- `sainsburys` role → `/sainsburys` command
- `asda` role → `/asda` command
- `morrisons` role → `/morrisons` command

### Channel-Based Access
Alternatively, users can use commands in designated channels:
- Commands work in channels with matching names
- No role required when using correct channel

### Admin Commands
Statistics and utility commands available to all users:
- `/mystats`, `/myhistory` - Personal data only
- `/leaderboard`, `/serverstats` - Public server data
- `/help`, `/calculate` - Utility functions

## 📊 Scheduled Features

### Daily Reports (9 AM)
- Server statistics summary
- Total barcodes generated
- Active users count
- Average prices

### Weekly Leaderboards (Sunday 6 PM)  
- Top 10 users by barcode count
- Performance highlights
- Achievement recognition

### Database Maintenance (Monday 2 AM)
- Cleanup old records (90+ days)
- Performance optimization
- Data integrity checks

## 🛠️ Development

### File Structure
```
src/
├── index.ts              # Main bot file
├── barcode-utils.ts      # Barcode generation logic
├── barcode-generator.ts  # Enhanced barcode features  
├── database.ts           # SQLite database layer
├── enhanced-logger.ts    # Logging and embeds
├── scheduler.ts          # Scheduled tasks
└── logger.ts             # Basic logging (legacy)
```

### Adding New Features
1. Update command definitions in `index.ts`
2. Add handler functions for new commands  
3. Update database schema if needed
4. Add logging for new actions
5. Update help system

### Database Schema
```sql
CREATE TABLE barcode_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId TEXT NOT NULL,
  username TEXT NOT NULL, 
  guildId TEXT NOT NULL,
  barcodeType TEXT NOT NULL,
  originalBarcode TEXT NOT NULL,
  generatedBarcode TEXT NOT NULL,
  price REAL NOT NULL,
  timestamp TEXT NOT NULL
);
```

## 🐛 Troubleshooting

### Canvas Installation Issues
```bash
# macOS - Install system dependencies
brew install pkg-config cairo pango libpng jpeg giflib librsvg

# Alternative: Use compatible Node version
nvm install 18
nvm use 18
npm install
```

### Permission Denied Errors
- Verify user has required role or is in correct channel
- Check role names match exactly (case-sensitive)
- Ensure bot has proper Discord permissions

### Database Errors
- Check file permissions for `barcodes.db`
- Ensure SQLite3 is properly installed
- Verify disk space availability

### Command Not Found
- Ensure bot is online and responsive
- Check if commands are properly registered
- Verify `CLIENT_ID` and `DISCORD_TOKEN` are correct

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/barcode-studio-bot/issues)
- **Documentation**: This README and inline code comments
- **Discord**: Use `/help` command for in-bot assistance

---

**Made with ❤️ for retail barcode generation**