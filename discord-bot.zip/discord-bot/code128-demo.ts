import { generateBarcodeText } from './src/text-barcode-generator';
import { BarcodeApiService } from './src/barcode-api-service';

console.log('🔢 Code 128 Barcode Demo\n');

// Test barcode generation
const result = generateBarcodeText('sainsburys', '1234567890123', 5.99);

console.log('📊 Generated Barcode Details:');
console.log(`Store: ${result.type.toUpperCase()}`);
console.log(`Original Barcode: ${result.original}`);
console.log(`Generated Code: ${result.generated}`);
console.log(`Price: £${result.price.toFixed(2)}\n`);

console.log('🖼️ Code 128 Image URLs:');
console.log(`Primary URL: ${result.barcodeImageUrl}`);
console.log(`Fallback URLs: ${result.fallbackUrls.join(', ')}\n`);

// Test different sizes
console.log('📏 Different Code 128 Sizes:');
const formats = BarcodeApiService.generateMultipleFormats(result.generated);
Object.entries(formats).forEach(([format, url]) => {
  console.log(`${format.toUpperCase()}: ${url}`);
});

console.log('\n✅ All URLs generate Code 128 linear barcodes (not QR codes)!');
console.log('💡 You can open these URLs in your browser to see the actual barcodes.');