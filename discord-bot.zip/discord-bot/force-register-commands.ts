// Force re-register Discord slash commands
import { REST, Routes } from 'discord.js';
import dotenv from 'dotenv';

dotenv.config();

const commands = [
  {
    name: 'sainsburys',
    description: 'Generate Sainsbury\'s barcode'
  },
  {
    name: 'asda', 
    description: 'Generate ASDA barcode'
  },
  {
    name: 'morrisons',
    description: 'Generate Morrisons barcode'
  },
  {
    name: 'generate-barcode',
    description: 'Generate a barcode with store selection'
  },
  {
    name: 'mystats',
    description: 'View your personal statistics'
  },
  {
    name: 'myhistory',
    description: 'View your barcode generation history'
  },
  {
    name: 'serverstats',
    description: 'View server statistics'
  },
  {
    name: 'leaderboard',
    description: 'View server leaderboard'
  },
  {
    name: 'calculate',
    description: 'Calculate discounted prices'
  },
  {
    name: 'help',
    description: 'Get help information'
  },
  {
    name: 'barcode-statistics',
    description: 'View comprehensive barcode statistics'
  },
  {
    name: 'redeem',
    description: 'Redeem an access code'
  },
  {
    name: 'generatekeys',
    description: 'Generate access keys (Owner only)'
  },
  {
    name: 'keystats',
    description: 'View redeem key statistics (Owner only)'
  },
  {
    name: 'setupredeempanel',
    description: 'Setup redeem panel in this channel (Owner only)'
  },
  {
    name: 'timeleft',
    description: 'Check how much access time you have remaining'
  }
];

async function forceRegisterCommands() {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);
  
  try {
    console.log('🔄 Force registering ALL slash commands...');
    
    // Clear existing commands first
    console.log('🗑️ Clearing existing commands...');
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID!), { body: [] });
    
    // Wait a moment
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Register new commands
    console.log('📝 Registering new commands...');
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID!),
      { body: commands }
    );
    
    console.log('✅ Successfully force-registered all slash commands!');
    console.log(`📊 Total commands registered: ${commands.length}`);
    console.log('📋 Commands registered:');
    commands.forEach(cmd => {
      console.log(`  - /${cmd.name}: ${cmd.description}`);
    });
    
  } catch (error) {
    console.error('❌ Error force-registering commands:', error);
  }
}

forceRegisterCommands();