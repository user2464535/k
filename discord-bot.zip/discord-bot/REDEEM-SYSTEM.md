# 🎫 Redeem Key System Documentation

## Overview
The redeem key system allows server owners to create time-limited access codes that grant users premium roles and barcode generation access.

## Features
- **Multiple Duration Options**: 1, 5, 10, and 31-day access codes
- **Automatic Role Management**: Adds and removes roles based on expiration
- **Owner-Only Controls**: Only server owners can generate keys and view statistics
- **Automatic Expiration**: Roles are automatically removed when keys expire
- **Statistics Tracking**: View key usage and remaining codes

## Commands

### For Server Owners

#### `/generatekeys count:5 duration:10`
Generate redeem keys for your server
- **count**: Number of keys to generate (1-50)
- **duration**: Key duration in days (1, 5, 10, or 31)
- **Example**: `/generatekeys count:10 duration:31` - Creates 10 keys for 31-day access

#### `/keystats`
View statistics about generated keys
- Shows total, used, and remaining keys by duration
- Owner-only command

#### `!setupredeempanel` or `/setupredeempanel`
Sets up a redeem panel in the current channel
- Creates an informative embed about how to redeem codes
- Provides instructions for users

### For All Users

#### `/redeem code:YOUR-CODE-HERE`
Redeem a premium access key
- **code**: The redeem code (format: XXXX-XXXX-XXXX)
- **Example**: `/redeem code:A8K9-2N7Q-P6R4`
- Grants premium access and applicable roles

## Role System

### Automatic Role Assignment
When a user redeems a key, the bot automatically assigns one of these roles (in order of preference):
1. `premium` role
2. `sainsburys` role  
3. `asda` role
4. `morrisons` role

### Automatic Role Removal
The bot checks every hour for expired subscriptions and automatically removes premium roles.

## Database Structure

### Redeem Keys Table
```sql
CREATE TABLE redeem_keys (
    code TEXT PRIMARY KEY,           -- Unique redeem code
    duration INTEGER NOT NULL,       -- Duration in days
    created_by TEXT NOT NULL,        -- User ID who created the key
    guild_id TEXT NOT NULL,          -- Server ID
    used BOOLEAN DEFAULT FALSE,      -- Whether key has been used
    used_by TEXT,                   -- User ID who redeemed it
    used_at DATETIME,               -- When it was redeemed
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### User Subscriptions Table
```sql
CREATE TABLE user_subscriptions (
    user_id TEXT NOT NULL,           -- Discord user ID
    guild_id TEXT NOT NULL,          -- Discord server ID  
    role_id TEXT NOT NULL,           -- Role that was assigned
    expires_at DATETIME NOT NULL,    -- When access expires
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, guild_id)
);
```

## Usage Examples

### 1. Server Setup
```
Owner: !setupredeempanel
Bot: ✅ Redeem panel setup complete!
     [Shows embed with instructions]
```

### 2. Generating Keys
```
Owner: /generatekeys count:5 duration:10
Bot: 🔑 Keys Generated Successfully
     Generated 5 keys for 10 day(s) access
     
     Keys:
     A8K9-2N7Q-P6R4
     B7M3-9X4T-L8N5
     C6P2-8Y5R-M9K7
     D5Q1-7Z6S-N8L4
     E4R9-6A3T-P7M2
```

### 3. Key Statistics
```
Owner: /keystats
Bot: 📊 Redeem Key Statistics
     
     1 Day Keys:
     • Total: 10
     • Used: 3
     • Remaining: 7
     
     31 Day Keys:
     • Total: 5
     • Used: 2
     • Remaining: 3
```

### 4. User Redemption
```
User: /redeem code:A8K9-2N7Q-P6R4
Bot: ✅ Code Redeemed Successfully!
     Redeemed 10 days successfully!
     Duration: 10 days
     Status: Premium access granted
```

## Error Handling

### Invalid Codes
- Non-existent codes: "Invalid or already used code!"
- Already used codes: "Invalid or already used code!"

### Permission Errors  
- Non-owners trying to generate keys: "Only the server owner can generate keys!"
- Non-owners viewing stats: "Only the server owner can view key statistics!"

### Limits
- Maximum 50 keys per generation request
- Database errors are handled gracefully with user-friendly messages

## Security Features

### Owner-Only Operations
- Key generation restricted to server owner
- Statistics viewing restricted to server owner
- Panel setup restricted to server owner

### Code Format
- 12-character codes in format XXXX-XXXX-XXXX
- Uses non-confusing characters (excludes I, L, O, 0, 1)
- Cryptographically random generation

### Automatic Cleanup
- Expired subscriptions are automatically removed
- Roles are removed precisely when access expires
- Database is kept clean of expired entries

## Integration with Barcode System

The redeem system is fully integrated with the barcode generation system:
- Premium users get access to all barcode commands
- Role-based permissions work seamlessly
- Access automatically expires based on key duration

## Monitoring

### Logs
- Key generation is logged
- Redemptions are logged  
- Role removals are logged
- Errors are logged for debugging

### Automatic Tasks
- Hourly expiration checks
- Automatic role removal
- Database cleanup

---

## Quick Start Guide

1. **Setup**: Run `!setupredeempanel` in desired channel
2. **Generate**: Use `/generatekeys count:10 duration:31` to create keys
3. **Distribute**: Share the generated codes with users
4. **Monitor**: Use `/keystats` to track usage
5. **Users Redeem**: Users run `/redeem code:THEIR-CODE`

The system handles everything else automatically! 🎯