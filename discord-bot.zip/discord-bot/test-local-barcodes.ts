import { generateLocalBarcode, generateStyledBarcode } from './src/local-barcode-generator';
import * as fs from 'fs';

console.log('🔢 Local Code 128 Barcode Test\n');

try {
  // Test Sainsbury's barcode
  console.log('Testing Sainsbury\'s barcode generation...');
  const sainsburysResult = generateLocalBarcode('sainsburys', '1234567890123', 5.99);
  
  console.log('📊 Sainsbury\'s Result:');
  console.log(`Original: ${sainsburysResult.original}`);
  console.log(`Generated: ${sainsburysResult.generated}`);
  console.log(`Price: £${sainsburysResult.price.toFixed(2)}`);
  console.log(`Image buffer size: ${sainsburysResult.imageBuffer.length} bytes`);
  
  // Save barcode image to file for testing
  fs.writeFileSync('sainsburys-test.png', sainsburysResult.imageBuffer);
  console.log('✅ Sainsbury\'s barcode saved as sainsburys-test.png');
  
  console.log('\n' + sainsburysResult.visualBarcode);

  // Test ASDA barcode
  console.log('\nTesting ASDA barcode generation...');
  const asdaResult = generateLocalBarcode('asda', '9876543210987', 3.50);
  
  console.log('📊 ASDA Result:');
  console.log(`Original: ${asdaResult.original}`);
  console.log(`Generated: ${asdaResult.generated}`);
  console.log(`Price: £${asdaResult.price.toFixed(2)}`);
  console.log(`Image buffer size: ${asdaResult.imageBuffer.length} bytes`);
  
  fs.writeFileSync('asda-test.png', asdaResult.imageBuffer);
  console.log('✅ ASDA barcode saved as asda-test.png');

  // Test different styles
  console.log('\nTesting different barcode styles...');
  const compactResult = generateStyledBarcode('morrisons', '5555666677778', 7.25, 'compact');
  const largeResult = generateStyledBarcode('morrisons', '5555666677778', 7.25, 'large');
  
  fs.writeFileSync('morrisons-compact.png', compactResult.imageBuffer);
  fs.writeFileSync('morrisons-large.png', largeResult.imageBuffer);
  
  console.log('✅ Morrisons compact barcode saved as morrisons-compact.png');
  console.log('✅ Morrisons large barcode saved as morrisons-large.png');

  console.log('\n🎯 All local barcode generation tests passed!');
  console.log('📁 Check the generated .png files to see your Code 128 barcodes.');
  
} catch (error) {
  console.error('❌ Error during barcode generation:', error);
}