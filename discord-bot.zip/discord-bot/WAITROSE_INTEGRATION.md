# Waitrose Barcode Integration

## Overview
Added full Waitrose support to the Discord barcode generation bot with a specialized barcode format designed for Waitrose stores.

## Waitrose Barcode Format

### Structure
```
10{13-digit-item-barcode}00{price-in-pence}
```

### Components
1. **Prefix**: `10` (fixed)
2. **Item Barcode**: 13-digit barcode (padded with leading zeros if needed)
3. **Separator**: `00` (fixed)
4. **Price**: Price in pence (padded to minimum 3 digits)

### Examples
- Input: `1234567890123`, `250p` → Output: `10123456789012300250`
- Input: `7622210966`, `50p` → Output: `10000762221096600050`
- Input: `123`, `2p` → Output: `10000000000012300002`

## New Features Added

### 1. `/waitrose` Slash Command
```
/waitrose barcode:1234567890123 price:250
```

**Parameters:**
- `barcode` (required): 13-digit item barcode
- `price` (required): Price in pence (e.g., 250 for £2.50)

**Validation:**
- Barcode must be exactly 13 digits (after cleaning)
- Price must be whole number between 1-99999 pence
- User must have `waitrose` role or be in `waitrose` channel

### 2. Database Integration
- Added `waitrose` to `BarcodeRecord` type
- Updated all database queries to include Waitrose counts
- Added Waitrose statistics to user stats and server stats
- Enhanced leaderboard to show Waitrose usage

### 3. User Interface Updates
- Added Waitrose to all help commands and descriptions
- Updated `/mystats` to show Waitrose barcode count
- Added Waitrose support to redeem key system
- Updated admin panels to include Waitrose statistics

### 4. Access Control
- Role-based access: `waitrose` role required
- Channel-based access: `waitrose` channel
- Premium role includes Waitrose access
- Integrated with existing permission system

### 5. Redeem Key System
- Added `waitrose` store type for key generation
- Waitrose keys use `WR-` prefix (e.g., `WR-ABCD-EFGH12`)
- Full integration with duration options (1m, 1h, 1d, lifetime)
- Automatic role management for expired keys

## Technical Implementation

### Barcode Generation Function
```typescript
export function generateWaitroseBarcode(barcode: string, priceInPence: number): string {
  let cleaned = barcode.replace(/\D/g, '');
  
  // Ensure exactly 13 digits
  if (cleaned.length > 13) {
    cleaned = cleaned.slice(0, 13);
  } else if (cleaned.length < 13) {
    cleaned = cleaned.padStart(13, '0');
  }
  
  // Format price - pad to at least 3 digits
  const paddedPrice = priceInPence.toString().padStart(3, '0');
  
  return `10${cleaned}00${paddedPrice}`;
}
```

### Command Handler Features
- Input validation for 13-digit barcodes
- Price validation (whole pence amounts)
- Barcode image generation using Code128 format
- DM delivery with fallback to channel
- Database logging and statistics tracking
- Enhanced error handling and user feedback

### Price Format
Unlike other stores that use pounds (£), Waitrose uses **pence only**:
- ✅ Correct: `/waitrose barcode:1234567890123 price:250` (for £2.50)
- ❌ Incorrect: `/waitrose barcode:1234567890123 price:2.50`

## Integration Points

### 1. Permission System
```typescript
['premium', 'sainsburys', 'asda', 'morrisons', 'waitrose'].includes(role.name.toLowerCase())
```

### 2. Statistics Tracking
```sql
SUM(CASE WHEN barcodeType = 'waitrose' THEN 1 ELSE 0 END) as waitroseCount
```

### 3. Redeem Keys
```typescript
storeType: 'sainsburys' | 'asda' | 'morrisons' | 'waitrose' | 'premium'
```

### 4. UI Components
- Added 🟡 emoji for Waitrose throughout the interface
- Updated all help text and descriptions
- Enhanced error messages with Waitrose context
- Consistent branding across all commands

## Usage Examples

### Basic Command
```
/waitrose barcode:5000169119784 price:199
```
Generates: `10500016911978400199` for £1.99

### Admin Key Generation
```
Store Type: waitrose
Count: 10  
Duration: 7d
```
Creates 10 Waitrose keys with 7-day access

### User Statistics
```
📊 Your Statistics
Total Barcodes: 25
Sainsbury's: 8
ASDA: 5
Morrisons: 7
Waitrose: 5
Last Used: 03/10/2025
```

## Error Handling

### Invalid Barcode Length
```
❌ Invalid Barcode
Waitrose requires exactly 13 digits for the item barcode.
```

### Invalid Price Format
```
❌ Invalid Price
Price must be a whole number between 1 and 99999 pence (e.g., 250 for £2.50).
```

### Permission Denied
```
❌ Permission Denied
You need the `waitrose` role or must be in the `waitrose` channel to use this command.
```

## Benefits

1. **Specialized Format**: Custom barcode structure optimized for Waitrose systems
2. **Pence Precision**: Direct pence input eliminates decimal conversion errors
3. **Full Integration**: Seamless integration with existing bot infrastructure
4. **Consistent UX**: Maintains familiar interface while adding new capabilities
5. **Comprehensive Logging**: Full audit trail for all Waitrose barcode generation

## Migration Notes

- Existing users automatically get Waitrose support
- No database migration required - new fields added dynamically
- Backward compatible with all existing features
- Premium users automatically have Waitrose access

## Command Summary

| Command | Description | New Feature |
|---------|-------------|-------------|
| `/waitrose` | Generate Waitrose barcode | ✅ New |
| `/mystats` | View statistics | ➕ Added Waitrose count |
| `/serverstats` | Server statistics | ➕ Added Waitrose metrics |
| `!adminpanel` | Admin management | ➕ Waitrose key generation |
| `/redeem` | Redeem access keys | ➕ Waitrose key support |

The Waitrose integration is now fully functional and provides users with a comprehensive barcode generation solution for all major UK supermarket chains.