#!/data/data/com.termux/files/usr/bin/bash

# Termux Radar Quick Installer and Runner
# This script provides easy installation and execution

RADAR_DIR="$HOME/termux-radar"
GITHUB_URL="https://github.com/user/termux-radar"  # Update with actual repo URL

show_banner() {
    clear
    echo ""
    echo "🎯 ███████   █████   ██████   ██████"
    echo "   ██       ██   ██ ██       ██    ██"
    echo "   ███████  ███████ ██   ███ ██    ██"
    echo "   ██    ██ ██   ██ ██    ██ ██    ██"
    echo "   ███████  ██   ██  ██████   ██████"
    echo "                                      v1"
    echo ""
    echo "🎯 SAGO v1 - External Device Scanner"
    echo "==================================="
    echo ""
}

show_menu() {
    echo "📋 Choose an option:"
    echo ""
    echo "1. 🚀 Quick Start (Install & Run SAGO v1)"
    echo "2. 📦 Install SAGO v1 Only"
    echo "3. ▶️  Run SAGO v1 (Foreground)"
    echo "4. 🔄 Run SAGO v1 as Service (Background)"
    echo "5. ⏹️  Stop SAGO v1 Service"
    echo "6. 📊 Check SAGO v1 Service Status"
    echo "7. 📝 View SAGO v1 Logs"
    echo "8. 🔧 Update SAGO v1 Installation"
    echo "9. ❌ Uninstall SAGO v1"
    echo "0. 🚪 Exit"
    echo ""
    echo -n "👆 Select option [0-9]: "
}

install_radar() {
    echo "📦 Installing SAGO v1..."
    
    # Check if already installed
    if [ -d "$RADAR_DIR" ]; then
        echo "⚠️  SAGO v1 already installed at $RADAR_DIR"
        echo -n "🔄 Update installation? [y/N]: "
        read -r update
        if [[ ! $update =~ ^[Yy]$ ]]; then
            return
        fi
    fi
    
    # Create directory and navigate
    mkdir -p "$RADAR_DIR"
    cd "$RADAR_DIR"
    
    # Run installation
    if [ -f "install.sh" ]; then
        chmod +x install.sh
        ./install.sh
    else
        echo "❌ install.sh not found. Please ensure all files are in $RADAR_DIR"
        return 1
    fi
    
    echo "✅ Installation completed!"
}

run_foreground() {
    echo "🚀 Starting SAGO v1 in foreground mode..."
    cd "$RADAR_DIR"
    
    if [ ! -f "app.py" ]; then
        echo "❌ SAGO v1 not installed. Please install first."
        return 1
    fi
    
    # Check if already running
    if pgrep -f "python.*app.py" > /dev/null; then
        echo "⚠️  SAGO v1 is already running!"
        echo -n "🔄 Stop and restart? [y/N]: "
        read -r restart
        if [[ $restart =~ ^[Yy]$ ]]; then
            stop_service
            sleep 2
        else
            return
        fi
    fi
    
    echo "🎯 Starting SAGO v1..."
    echo "🌐 Access at: http://localhost:5000"
    echo "📱 Or from network: http://"$(hostname -I | awk '{print $1}')":5000"
    echo "⏹️  Press Ctrl+C to stop"
    echo ""
    
    python app.py
}

run_service() {
    echo "🔄 Starting SAGO v1 as background service..."
    cd "$RADAR_DIR"
    
    if [ ! -f "radar_service.sh" ]; then
        echo "❌ Service script not found. Please reinstall."
        return 1
    fi
    
    chmod +x radar_service.sh
    ./radar_service.sh start
    
    echo ""
    echo "🌐 Access URLs:"
    echo "   http://localhost:5000"
    echo "   http://$(hostname -I | awk '{print $1}'):5000"
}

stop_service() {
    echo "⏹️  Stopping SAGO v1 service..."
    cd "$RADAR_DIR"
    
    if [ -f "radar_service.sh" ]; then
        ./radar_service.sh stop
    fi
    
    # Force kill if still running
    pkill -f "python.*app.py" 2>/dev/null
    
    echo "✅ SAGO v1 stopped"
}

check_status() {
    echo "📊 Checking SAGO v1 status..."
    cd "$RADAR_DIR"
    
    if [ -f "radar_service.sh" ]; then
        ./radar_service.sh status
    else
        if pgrep -f "python.*app.py" > /dev/null; then
            echo "✅ SAGO v1 is running"
        else
            echo "❌ SAGO v1 is not running"
        fi
    fi
    
    echo ""
    echo "📈 System Info:"
    echo "   CPU Usage: $(top -n1 | grep "CPU:" | awk '{print $2}')"
    echo "   Memory: $(free -h | grep Mem | awk '{print $3 "/" $2}')"
    echo "   Storage: $(df -h ~ | tail -1 | awk '{print $4 " free"}')"
}

view_logs() {
    echo "📝 Viewing SAGO v1 logs..."
    cd "$RADAR_DIR"
    
    if [ -f "sago.log" ]; then
        echo "📄 Recent log entries (last 20 lines):"
        echo "======================================"
        tail -20 sago.log
        echo ""
        echo -n "📖 View full log? [y/N]: "
        read -r view_full
        if [[ $view_full =~ ^[Yy]$ ]]; then
            less sago.log
        fi
    else
        echo "❌ No log file found. Start SAGO v1 to generate logs."
    fi
}

update_installation() {
    echo "🔧 Updating SAGO v1..."
    
    # Backup current installation
    if [ -d "$RADAR_DIR" ]; then
        cp -r "$RADAR_DIR" "$RADAR_DIR.backup.$(date +%s)"
        echo "📁 Current installation backed up"
    fi
    
    # Stop service if running
    stop_service
    
    # Reinstall
    install_radar
    
    echo "✅ Update completed!"
}

uninstall_radar() {
    echo "❌ Uninstalling SAGO v1..."
    echo ""
    echo "⚠️  This will remove:"
    echo "   - All SAGO v1 files"
    echo "   - Configuration"
    echo "   - Log files"
    echo "   - Service scripts"
    echo ""
    echo -n "🗑️  Are you sure? [y/N]: "
    read -r confirm
    
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo "❌ Uninstallation cancelled"
        return
    fi
    
    # Stop service
    stop_service
    
    # Remove directory
    if [ -d "$RADAR_DIR" ]; then
        rm -rf "$RADAR_DIR"
        echo "✅ SAGO v1 files removed"
    fi
    
    # Clean up processes
    pkill -f "python.*app.py" 2>/dev/null
    
    echo "✅ Uninstallation completed"
}

# Main execution
while true; do
    show_banner
    
    # Check installation status
    if [ -d "$RADAR_DIR" ] && [ -f "$RADAR_DIR/app.py" ]; then
        echo "✅ Status: SAGO v1 is installed"
        if pgrep -f "python.*app.py" > /dev/null; then
            echo "🟢 Service: Running"
        else
            echo "🔴 Service: Stopped"
        fi
    else
        echo "❌ Status: Not installed"
    fi
    
    echo ""
    show_menu
    read -r choice
    
    case $choice in
        1)
            echo "🚀 Quick Start: Installing and running SAGO v1..."
            install_radar && run_foreground
            ;;
        2)
            install_radar
            ;;
        3)
            run_foreground
            ;;
        4)
            run_service
            ;;
        5)
            stop_service
            ;;
        6)
            check_status
            ;;
        7)
            view_logs
            ;;
        8)
            update_installation
            ;;
        9)
            uninstall_radar
            ;;
        0)
            echo "👋 Goodbye!"
            exit 0
            ;;
        *)
            echo "❌ Invalid option. Please select 0-9."
            ;;
    esac
    
    echo ""
    echo -n "📱 Press Enter to continue..."
    read -r
done