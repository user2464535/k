#!/data/data/com.termux/files/usr/bin/bash
# Root Radar Launcher - Explicit root execution script

echo "🔑 Termux Radar - ROOT MODE"
echo "=========================="
echo ""

# Function to check root requirements
check_root_requirements() {
    echo "🔍 Checking root requirements..."
    
    # Check if su binary exists
    if ! command -v su >/dev/null 2>&1; then
        echo "❌ ERROR: 'su' binary not found"
        echo "   This device doesn't appear to be rooted"
        echo "   Please root your device first"
        return 1
    fi
    
    # Test root access
    if ! su -c 'echo "Root access test"' >/dev/null 2>&1; then
        echo "❌ ERROR: Root access denied"
        echo "   Possible causes:"
        echo "   - Root access not properly configured"
        echo "   - Termux not granted root permissions"
        echo "   - Root manager (SuperSU/Magisk) blocking access"
        return 1
    fi
    
    echo "✅ Root access confirmed"
    return 0
}

# Function to set up root environment
setup_root_env() {
    echo "🔧 Setting up root environment..."
    
    su -c "
        # Set environment variables for better scanning
        export PATH=/system/bin:/system/xbin:\$PATH
        
        # Check for additional tools
        if command -v iwlist >/dev/null 2>&1; then
            echo '✅ iwlist available for WiFi scanning'
        else
            echo '⚠️  iwlist not found - limited WiFi scanning'
        fi
        
        if command -v hcitool >/dev/null 2>&1; then
            echo '✅ hcitool available for Bluetooth scanning' 
        else
            echo '⚠️  hcitool not found - limited Bluetooth scanning'
        fi
        
        if command -v nmap >/dev/null 2>&1; then
            echo '✅ nmap available for network scanning'
        else
            echo '⚠️  nmap not found - using basic scanning'
        fi
    "
}

# Function to start radar with root privileges
start_root_radar() {
    echo "🚀 Starting Radar with ROOT privileges..."
    echo ""
    
    cd "$(dirname "$0")"
    
    # Export root mode flag for the application
    export TERMUX_RADAR_ROOT_MODE=1
    
    # Start the application with root
    su -c "
        cd '$(pwd)'
        export TERMUX_RADAR_ROOT_MODE=1
        export PATH=/system/bin:/system/xbin:\$PATH
        python app.py
    "
}

# Main execution
echo "🎯 Initializing ROOT MODE radar..."
echo ""

# Check if we're already root
if [ "$EUID" -eq 0 ]; then
    echo "✅ Already running as root"
    export TERMUX_RADAR_ROOT_MODE=1
    cd "$(dirname "$0")"
    python app.py
    exit 0
fi

# Perform root checks
if ! check_root_requirements; then
    echo ""
    echo "💡 SOLUTIONS:"
    echo "============"
    echo ""
    echo "1. 🔓 ROOT YOUR DEVICE:"
    echo "   - Use Magisk, SuperSU, or similar root method"
    echo "   - Ensure root is properly installed and working"
    echo ""
    echo "2. 📱 GRANT TERMUX ROOT ACCESS:"
    echo "   - Open your root manager app"
    echo "   - Grant root permissions to Termux"
    echo "   - Some managers require explicit app approval"
    echo ""
    echo "3. 🧪 TEST ROOT ACCESS:"
    echo "   - Run: su -c 'id'"
    echo "   - Should show: uid=0(root) gid=0(root)"
    echo ""
    echo "4. 🔄 ALTERNATIVE:"
    echo "   - Run without root: ./start_radar.sh"
    echo "   - Some features will be limited but app will work"
    echo ""
    exit 1
fi

# Set up environment and start
setup_root_env
echo ""
echo "🔥 ROOT MODE ACTIVE - Enhanced scanning capabilities enabled"
echo "⚡ All network interfaces accessible"
echo "🔍 Deep packet inspection available"
echo "📡 Raw socket access enabled"
echo ""
echo "🌐 Access radar at: http://localhost:5000"
echo "⏹️  Press Ctrl+C to stop"
echo ""

start_root_radar