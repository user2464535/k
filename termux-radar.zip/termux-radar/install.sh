#!/data/data/com.termux/files/usr/bin/bash
# Termux Radar Installation Script
# This script installs all dependencies and sets up the radar application

echo "🎯 SAGO v1 Installation Script"
echo "============================"
echo ""

# Update package lists
echo "📦 Updating package lists..."
pkg update -y

# Install required system packages
echo "🔧 Installing system packages..."
pkg install -y python python-pip git nmap wireless-tools bluetooth net-tools

# Install Termux API for enhanced device access
echo "📱 Installing Termux API..."
pkg install -y termux-api

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip install --upgrade pip
pip install flask==2.3.3
pip install flask-socketio==5.3.6
pip install psutil==5.9.5
pip install netifaces==0.11.0
pip install python-nmap==0.7.1
pip install scapy==2.5.0

# Try to install optional Bluetooth libraries
echo "📡 Installing Bluetooth support..."
pip install pybluez || echo "⚠️  Bluetooth support may be limited"

# Try to install WiFi libraries
echo "📶 Installing WiFi support..."
pip install wifi || echo "⚠️  Some WiFi features may be limited"

# Set up permissions for network scanning
echo "🔑 Setting up permissions..."
echo "Please grant the following permissions when prompted:"
echo "- Location (for WiFi scanning)"
echo "- Camera (for some network features)"
echo "- Storage (for saving scan results)"

# Create launcher script
echo "🚀 Creating launcher script..."
cat > start_radar.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

echo "🎯 Starting SAGO v1..."
echo "===================="
echo ""

# Function to check and request root access
check_root() {
    if command -v su >/dev/null 2>&1; then
        echo "🔑 Root access available - checking permissions..."
        if su -c 'echo "Root test successful"' >/dev/null 2>&1; then
            echo "✅ Root access confirmed"
            return 0
        else
            echo "❌ Root access denied"
            return 1
        fi
    else
        echo "❌ No su binary found - device not rooted"
        return 1
    fi
}

# Check if running as root for better scanning capabilities
if [ "$EUID" -eq 0 ]; then
    echo "✅ Already running with root privileges - full scanning capabilities enabled"
    ROOT_MODE=true
elif check_root; then
    echo "🚀 Starting with root privileges for enhanced scanning..."
    echo "⚠️  You may be prompted to grant root access"
    exec su -c "cd '$(pwd)' && python app.py"
else
    echo "⚠️  Running without root - some features may be limited"
    echo "   Advanced network scanning and some device detection features disabled"
    echo "   For full functionality:"
    echo "   1. Root your device"
    echo "   2. Install a root manager (SuperSU, Magisk, etc.)"
    echo "   3. Run: su -c './start_radar.sh'"
    ROOT_MODE=false
fi

# Start the radar application
cd "$(dirname "$0")"
if [ "$ROOT_MODE" = "true" ]; then
    echo "🔥 Running in ROOT MODE - Enhanced capabilities enabled"
fi
python app.py
EOF

chmod +x start_radar.sh

# Create root launcher script (made executable during installation)  
if [ -f "start_root.sh" ]; then
    chmod +x start_root.sh
    echo "🔑 Root launcher script ready: ./start_root.sh"
fi

# Create stop script
echo "⏹️  Creating stop script..."
cat > stop_radar.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

echo "⏹️  Stopping SAGO v1..."
pkill -f "python app.py"
echo "🛑 SAGO v1 stopped"
EOF

chmod +x stop_radar.sh

# Create service script for background running
echo "🔄 Creating service script..."
cat > radar_service.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

case "$1" in
    start)
        echo "🚀 Starting SAGO v1 service in background..."
        
        # Check for root access
        if command -v su >/dev/null 2>&1 && su -c 'echo "Root check"' >/dev/null 2>&1; then
            echo "🔑 Starting with root privileges for enhanced scanning..."
            su -c "cd '$(pwd)' && nohup python app.py > sago.log 2>&1 & echo \$! > sago.pid"
        else
            echo "⚠️  Starting without root - some features limited"
            nohup python app.py > sago.log 2>&1 &
            echo $! > sago.pid
        fi
        
        if [ -f sago.pid ]; then
            echo "✅ SAGO v1 service started (PID: $(cat sago.pid))"
            echo "📊 Check sago.log for output"
        else
            echo "❌ Failed to start SAGO v1 service"
        fi
        ;;
    stop)
        echo "⏹️  Stopping SAGO v1 service..."
        if [ -f sago.pid ]; then
            PID=$(cat sago.pid)
            if kill -0 "$PID" 2>/dev/null; then
                kill "$PID"
                rm sago.pid
                echo "✅ SAGO v1 service stopped"
            else
                echo "⚠️  Process not running, cleaning up pid file"
                rm sago.pid
            fi
        else
            echo "❌ No sago.pid file found"
            # Fallback: kill any running sago processes
            pkill -f "python.*app.py" && echo "🧹 Killed any remaining SAGO v1 processes"
        fi
        ;;
    status)
        if [ -f sago.pid ] && kill -0 $(cat sago.pid) 2>/dev/null; then
            PID=$(cat sago.pid)
            echo "✅ SAGO v1 service is running (PID: $PID)"
            
            # Check if running as root
            if ps -o uid= -p "$PID" | grep -q '^0$'; then
                echo "🔑 Running with root privileges"
            else
                echo "👤 Running with user privileges"
            fi
        else
            echo "❌ SAGO v1 service is not running"
            # Clean up stale pid file
            [ -f sago.pid ] && rm sago.pid
        fi
        ;;
    root)
        echo "🔑 Starting SAGO v1 with explicit root request..."
        if command -v su >/dev/null 2>&1; then
            su -c "cd '$(pwd)' && nohup python app.py > sago.log 2>&1 & echo \$! > sago.pid"
            echo "✅ SAGO v1 started with root privileges"
        else
            echo "❌ Root access not available on this device"
            exit 1
        fi
        ;;
    *)
        echo "Usage: $0 {start|stop|status|root}"
        echo ""
        echo "Commands:"
        echo "  start  - Start radar service (auto-detects root)"
        echo "  stop   - Stop radar service"
        echo "  status - Check service status"
        echo "  root   - Force start with root privileges"
        exit 1
        ;;
esac
EOF

chmod +x radar_service.sh

# Create quick access scripts
echo "⚡ Creating quick access commands..."

# Create termux-url-opener for easy access
mkdir -p ~/.termux
cat > ~/.termux/termux-url-opener << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
if [[ $1 == *"radar"* ]]; then
    cd ~/termux-radar
    ./start_radar.sh
fi
EOF

chmod +x ~/.termux/termux-url-opener

echo ""
echo "🎉 Installation Complete!"
echo "======================="
echo ""
echo "📋 Available Commands:"
echo "   ./start_radar.sh          - Start SAGO v1 in foreground"
echo "   ./start_root.sh           - Start SAGO v1 with ROOT privileges"
echo "   ./stop_radar.sh           - Stop SAGO v1"
echo "   ./radar_service.sh start  - Start as background service"
echo "   ./radar_service.sh root   - Start as ROOT background service"
echo "   ./radar_service.sh stop   - Stop background service"
echo "   ./radar_service.sh status - Check service status"
echo ""
echo "🌐 Access URLs:"
echo "   http://localhost:5000     - From this device"
echo "   http://$(hostname -I | awk '{print $1}'):5000 - From other devices on network"
echo ""
echo "📱 Termux API Setup:"
echo "   1. Install 'Termux:API' app from F-Droid or Google Play"
echo "   2. Grant all requested permissions"
echo "   3. Run: termux-setup-storage"
echo ""
echo "🔒 For best results:"
echo "   - Grant location permissions for WiFi scanning"
echo "   - Enable Bluetooth for device detection"
echo "   - Consider rooting device for advanced features"
echo ""
echo "🚀 To start SAGO v1 now, run:"
echo "   ./start_radar.sh"
echo ""