#!/data/data/com.termux/files/usr/bin/bash
# Termux Radar Installation Script
# This script installs all dependencies and sets up the radar application

echo "🎯 Termux Radar Installation Script"
echo "=================================="
echo ""

# Update package lists
echo "📦 Updating package lists..."
pkg update -y

# Install required system packages
echo "🔧 Installing system packages..."
pkg install -y python python-pip git nmap wireless-tools bluetooth net-tools

# Install Termux API for enhanced device access
echo "📱 Installing Termux API..."
pkg install -y termux-api

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip install --upgrade pip
pip install flask==2.3.3
pip install flask-socketio==5.3.6
pip install psutil==5.9.5
pip install netifaces==0.11.0
pip install python-nmap==0.7.1
pip install scapy==2.5.0

# Try to install optional Bluetooth libraries
echo "📡 Installing Bluetooth support..."
pip install pybluez || echo "⚠️  Bluetooth support may be limited"

# Try to install WiFi libraries
echo "📶 Installing WiFi support..."
pip install wifi || echo "⚠️  Some WiFi features may be limited"

# Set up permissions for network scanning
echo "🔑 Setting up permissions..."
echo "Please grant the following permissions when prompted:"
echo "- Location (for WiFi scanning)"
echo "- Camera (for some network features)"
echo "- Storage (for saving scan results)"

# Create launcher script
echo "🚀 Creating launcher script..."
cat > start_radar.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

echo "🎯 Starting Termux Radar..."
echo "=========================="
echo ""

# Check if running as root for better scanning capabilities
if [ "$EUID" -eq 0 ]; then
    echo "✅ Running with root privileges - full scanning capabilities enabled"
else
    echo "⚠️  Running without root - some features may be limited"
    echo "   For full functionality, consider rooting your device"
fi

# Start the radar application
cd "$(dirname "$0")"
python app.py
EOF

chmod +x start_radar.sh

# Create stop script
echo "⏹️  Creating stop script..."
cat > stop_radar.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

echo "⏹️  Stopping Termux Radar..."
pkill -f "python app.py"
echo "🛑 Radar stopped"
EOF

chmod +x stop_radar.sh

# Create service script for background running
echo "🔄 Creating service script..."
cat > radar_service.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

case "$1" in
    start)
        echo "🚀 Starting Radar service in background..."
        nohup python app.py > radar.log 2>&1 &
        echo $! > radar.pid
        echo "✅ Radar service started (PID: $(cat radar.pid))"
        echo "📊 Check radar.log for output"
        ;;
    stop)
        echo "⏹️  Stopping Radar service..."
        if [ -f radar.pid ]; then
            kill $(cat radar.pid)
            rm radar.pid
            echo "✅ Radar service stopped"
        else
            echo "❌ No radar.pid file found"
        fi
        ;;
    status)
        if [ -f radar.pid ] && kill -0 $(cat radar.pid) 2>/dev/null; then
            echo "✅ Radar service is running (PID: $(cat radar.pid))"
        else
            echo "❌ Radar service is not running"
        fi
        ;;
    *)
        echo "Usage: $0 {start|stop|status}"
        exit 1
        ;;
esac
EOF

chmod +x radar_service.sh

# Create quick access scripts
echo "⚡ Creating quick access commands..."

# Create termux-url-opener for easy access
mkdir -p ~/.termux
cat > ~/.termux/termux-url-opener << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
if [[ $1 == *"radar"* ]]; then
    cd ~/termux-radar
    ./start_radar.sh
fi
EOF

chmod +x ~/.termux/termux-url-opener

echo ""
echo "🎉 Installation Complete!"
echo "======================="
echo ""
echo "📋 Available Commands:"
echo "   ./start_radar.sh          - Start radar in foreground"
echo "   ./stop_radar.sh           - Stop radar"
echo "   ./radar_service.sh start  - Start as background service"
echo "   ./radar_service.sh stop   - Stop background service"
echo "   ./radar_service.sh status - Check service status"
echo ""
echo "🌐 Access URLs:"
echo "   http://localhost:5000     - From this device"
echo "   http://$(hostname -I | awk '{print $1}'):5000 - From other devices on network"
echo ""
echo "📱 Termux API Setup:"
echo "   1. Install 'Termux:API' app from F-Droid or Google Play"
echo "   2. Grant all requested permissions"
echo "   3. Run: termux-setup-storage"
echo ""
echo "🔒 For best results:"
echo "   - Grant location permissions for WiFi scanning"
echo "   - Enable Bluetooth for device detection"
echo "   - Consider rooting device for advanced features"
echo ""
echo "🚀 To start the radar now, run:"
echo "   ./start_radar.sh"
echo ""