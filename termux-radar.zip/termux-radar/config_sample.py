# Termux Radar Configuration File
# Copy this file to config.py and modify as needed

# Server Configuration
HOST = '0.0.0.0'  # Bind to all interfaces (allows network access)
PORT = 5000       # Web server port
DEBUG = False     # Set to True for development

# Scanning Configuration
SCAN_INTERVAL = 30        # Seconds between automatic scans
WIFI_TIMEOUT = 10         # Timeout for WiFi scanning
BLUETOOTH_TIMEOUT = 15    # Timeout for Bluetooth scanning  
NETWORK_TIMEOUT = 3       # Timeout for network device pings

# Port Scanning Configuration
COMMON_PORTS = [
    21,    # FTP
    22,    # SSH
    23,    # Telnet
    25,    # SMTP
    53,    # DNS
    80,    # HTTP
    110,   # POP3
    143,   # IMAP
    443,   # HTTPS
    993,   # IMAPS
    995,   # POP3S
    1723,  # PPTP
    3389,  # RDP
    5900,  # VNC
    8080,  # HTTP Alt
    8443,  # HTTPS Alt
]

# Network Scanning Configuration
MAX_CONCURRENT_PINGS = 20  # Maximum parallel ping processes
NETWORK_SCAN_RANGE = 255   # Number of IPs to scan in subnet

# UI Configuration
RADAR_REFRESH_RATE = 2000  # Milliseconds between radar updates
MAX_DEVICES_DISPLAY = 100  # Maximum devices to show on radar

# Security Settings
ENABLE_CORS = True         # Enable CORS for cross-origin requests
SECRET_KEY = 'radar_secret_key_change_me_2025'

# Logging Configuration
LOG_LEVEL = 'INFO'         # DEBUG, INFO, WARNING, ERROR
LOG_FILE = 'radar.log'     # Log file name
MAX_LOG_SIZE = 10485760    # 10MB max log file size

# Features Toggle
ENABLE_WIFI_SCAN = True
ENABLE_BLUETOOTH_SCAN = True  
ENABLE_NETWORK_SCAN = True
ENABLE_PORT_SCAN = True

# Advanced Options
USE_TERMUX_API = True      # Use Termux API when available
AGGRESSIVE_SCAN = False    # More thorough but slower scanning
SAVE_SCAN_HISTORY = False  # Save scan results to file

# Device Detection Sensitivity
WIFI_MIN_SIGNAL = -90      # Minimum WiFi signal strength (dBm)
BLUETOOTH_SCAN_DURATION = 10  # Bluetooth discovery duration
NETWORK_PING_COUNT = 1     # Number of pings per device

# Performance Tuning
THREAD_POOL_SIZE = 5       # Number of scanning threads
MEMORY_LIMIT_MB = 100      # Memory usage limit
CPU_LIMIT_PERCENT = 50     # CPU usage limit