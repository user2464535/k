#!/usr/bin/env python3
"""
Termux Radar Application
A web-based radar interface to detect nearby devices, networks, and services
"""

import os
import sys
import json
import time
import threading
import subprocess
from datetime import datetime
from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO, emit
import psutil
import netifaces
import socket
import struct

try:
    import nmap
except ImportError:
    nmap = None

try:
    import bluetooth
except ImportError:
    bluetooth = None

app = Flask(__name__)
app.config['SECRET_KEY'] = 'radar_secret_key_2025'
socketio = SocketIO(app, cors_allowed_origins="*")

class RadarScanner:
    def __init__(self):
        self.detected_devices = {}
        self.scan_active = False
        self.scan_thread = None
        
    def get_local_ip(self):
        """Get the local IP address"""
        try:
            # Get default gateway
            gateways = netifaces.gateways()
            default_gateway = gateways['default'][netifaces.AF_INET][0]
            
            # Get local IP
            for interface in netifaces.interfaces():
                addrs = netifaces.ifaddresses(interface)
                if netifaces.AF_INET in addrs:
                    for addr in addrs[netifaces.AF_INET]:
                        ip = addr['addr']
                        if not ip.startswith('127.') and '.' in ip:
                            return ip, default_gateway
            return "127.0.0.1", default_gateway
        except:
            return "127.0.0.1", "192.168.1.1"
    
    def scan_wifi_networks(self):
        """Scan for WiFi networks using termux-wifi-scaninfo"""
        wifi_devices = []
        try:
            # Try termux-wifi-scaninfo command first
            result = subprocess.run(['termux-wifi-scaninfo'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'SSID:' in line or 'BSSID:' in line:
                        wifi_devices.append({
                            'type': 'wifi',
                            'info': line.strip(),
                            'signal_strength': 'unknown',
                            'timestamp': datetime.now().isoformat()
                        })
        except:
            pass
            
        # Fallback: Try parsing iwlist output
        try:
            result = subprocess.run(['iwlist', 'scan'], 
                                  capture_output=True, text=True, timeout=15)
            if result.returncode == 0:
                current_network = {}
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    if 'Cell' in line and 'Address:' in line:
                        if current_network:
                            wifi_devices.append(current_network)
                        current_network = {
                            'type': 'wifi',
                            'mac': line.split('Address: ')[1].strip(),
                            'timestamp': datetime.now().isoformat()
                        }
                    elif 'ESSID:' in line:
                        current_network['ssid'] = line.split('ESSID:')[1].strip().strip('"')
                    elif 'Signal level=' in line:
                        current_network['signal_strength'] = line.split('Signal level=')[1].split(' ')[0]
                
                if current_network:
                    wifi_devices.append(current_network)
        except:
            pass
            
        return wifi_devices
    
    def scan_bluetooth_devices(self):
        """Scan for Bluetooth devices"""
        bt_devices = []
        try:
            # Try termux-bluetooth-scaninfo
            result = subprocess.run(['termux-bluetooth-scaninfo'], 
                                  capture_output=True, text=True, timeout=15)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.strip():
                        bt_devices.append({
                            'type': 'bluetooth',
                            'info': line.strip(),
                            'timestamp': datetime.now().isoformat()
                        })
        except:
            pass
            
        # Try hcitool if available
        try:
            result = subprocess.run(['hcitool', 'scan'], 
                                  capture_output=True, text=True, timeout=15)
            if result.returncode == 0:
                for line in result.stdout.split('\n')[1:]:  # Skip header
                    if line.strip():
                        parts = line.strip().split('\t')
                        if len(parts) >= 2:
                            bt_devices.append({
                                'type': 'bluetooth',
                                'mac': parts[0].strip(),
                                'name': parts[1].strip() if len(parts) > 1 else 'Unknown',
                                'timestamp': datetime.now().isoformat()
                            })
        except:
            pass
            
        return bt_devices
    
    def scan_network_devices(self):
        """Scan for devices on the local network"""
        network_devices = []
        local_ip, gateway = self.get_local_ip()
        
        try:
            # Get network range
            network_parts = local_ip.split('.')
            network_base = '.'.join(network_parts[:3]) + '.'
            
            # Quick ping sweep of common IPs
            common_ips = [gateway] + [f"{network_base}{i}" for i in [1, 2, 3, 4, 5, 10, 20, 100, 101, 102, 254]]
            
            for ip in common_ips:
                try:
                    result = subprocess.run(['ping', '-c', '1', '-W', '1', ip], 
                                          capture_output=True, timeout=3)
                    if result.returncode == 0:
                        # Try to get hostname
                        try:
                            hostname = socket.gethostbyaddr(ip)[0]
                        except:
                            hostname = 'Unknown'
                        
                        network_devices.append({
                            'type': 'network',
                            'ip': ip,
                            'hostname': hostname,
                            'status': 'active',
                            'timestamp': datetime.now().isoformat()
                        })
                except:
                    continue
        except:
            pass
            
        return network_devices
    
    def scan_open_ports(self, ip, common_ports=None):
        """Scan for open ports on a given IP"""
        if common_ports is None:
            common_ports = [21, 22, 23, 25, 53, 80, 110, 443, 993, 995, 1723, 3389, 5900, 8080]
        
        open_ports = []
        for port in common_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    open_ports.append(port)
                sock.close()
            except:
                pass
        return open_ports
    
    def perform_full_scan(self):
        """Perform a comprehensive scan"""
        all_devices = []
        
        print("🔍 Scanning WiFi networks...")
        wifi_devices = self.scan_wifi_networks()
        all_devices.extend(wifi_devices)
        
        print("📡 Scanning Bluetooth devices...")
        bt_devices = self.scan_bluetooth_devices()
        all_devices.extend(bt_devices)
        
        print("🌐 Scanning network devices...")
        network_devices = self.scan_network_devices()
        all_devices.extend(network_devices)
        
        # Add port scanning for active network devices
        for device in network_devices:
            if device['type'] == 'network':
                print(f"🔍 Scanning ports on {device['ip']}...")
                open_ports = self.scan_open_ports(device['ip'])
                if open_ports:
                    device['open_ports'] = open_ports
        
        return all_devices
    
    def continuous_scan(self):
        """Continuous scanning loop"""
        while self.scan_active:
            try:
                devices = self.perform_full_scan()
                
                # Update detected devices
                for device in devices:
                    device_id = f"{device['type']}_{hash(str(device))}"
                    device['id'] = device_id
                    self.detected_devices[device_id] = device
                
                # Emit update to web interface
                socketio.emit('radar_update', {
                    'devices': list(self.detected_devices.values()),
                    'scan_time': datetime.now().isoformat()
                })
                
                print(f"📊 Found {len(devices)} devices in this scan")
                time.sleep(30)  # Scan every 30 seconds
                
            except Exception as e:
                print(f"❌ Scan error: {e}")
                time.sleep(10)
    
    def start_scanning(self):
        """Start the continuous scanning process"""
        if not self.scan_active:
            self.scan_active = True
            self.scan_thread = threading.Thread(target=self.continuous_scan)
            self.scan_thread.daemon = True
            self.scan_thread.start()
            print("🚀 Radar scanning started!")
    
    def stop_scanning(self):
        """Stop the scanning process"""
        self.scan_active = False
        if self.scan_thread:
            self.scan_thread.join(timeout=5)
        print("⏹️ Radar scanning stopped!")

# Initialize radar scanner
radar = RadarScanner()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/devices')
def get_devices():
    return jsonify({
        'devices': list(radar.detected_devices.values()),
        'scan_active': radar.scan_active,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/start_scan')
def start_scan():
    radar.start_scanning()
    return jsonify({'status': 'started'})

@app.route('/api/stop_scan')
def stop_scan():
    radar.stop_scanning()
    return jsonify({'status': 'stopped'})

@socketio.on('connect')
def handle_connect():
    print('🔌 Client connected to radar')
    emit('radar_status', {'scan_active': radar.scan_active})

@socketio.on('disconnect')
def handle_disconnect():
    print('🔌 Client disconnected from radar')

@socketio.on('start_radar')
def handle_start_radar():
    radar.start_scanning()
    emit('radar_status', {'scan_active': True})

@socketio.on('stop_radar')
def handle_stop_radar():
    radar.stop_scanning()
    emit('radar_status', {'scan_active': False})

if __name__ == '__main__':
    print("🎯 Termux Radar Application Starting...")
    print("🌐 Access the radar interface at: http://localhost:5000")
    print("📱 Or from your phone's IP address on port 5000")
    
    # Get local IP for display
    local_ip, _ = radar.get_local_ip()
    print(f"📡 Local IP: {local_ip}:5000")
    
    # Start the radar automatically
    radar.start_scanning()
    
    # Run the Flask-SocketIO server
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)