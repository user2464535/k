#!/usr/bin/env python3
"""
SAGO v1 - External Device Scanner
A web-based scanner to detect external devices, networks, and connections
"""

import os
import sys
import json
import time
import threading
import subprocess
from datetime import datetime
from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO, emit
import psutil
import netifaces
import socket
import struct

try:
    import nmap
eif __name__ == '__main__':
    print("🎯 SAGO v1 - External Device Scanner Starting...")
    print("==============================================")
    print("")
    
    # Get local IP for display
    local_ip, _ = sago.get_local_ip()
    print(f"📡 Local IP: {local_ip}:5000")
    print("🌐 Access SAGO v1 at: http://localhost:5000")
    print("📱 Or from network: http://" + local_ip + ":5000")
    print("")
    print("🔍 Scanning for external devices:")
    print("   📶 WiFi Networks")
    print("   📡 Bluetooth Devices") 
    print("   🌐 External Connections")
    print("   🔌 USB Devices")
    print("")
    
    # Start the scanner automatically
    sago.start_scanning()
    
    # Run the Flask-SocketIO server
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)ror:
    nmap = None

try:
    import bluetooth
except ImportError:
    bluetooth = None

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sago_v1_secret_key_2025'
socketio = SocketIO(app, cors_allowed_origins="*")

class SagoScanner:
    def __init__(self):
        self.detected_devices = {}
        self.scan_active = False
        self.scan_thread = None
        self.root_mode = os.getenv('TERMUX_RADAR_ROOT_MODE', '0') == '1'
        
        if self.root_mode:
            print("🔥 ROOT MODE ENABLED - Enhanced scanning capabilities active")
        else:
            print("👤 USER MODE - Limited scanning capabilities")
        
    def get_local_ip(self):
        """Get the local IP address"""
        try:
            # Get default gateway
            gateways = netifaces.gateways()
            default_gateway = gateways['default'][netifaces.AF_INET][0]
            
            # Get local IP
            for interface in netifaces.interfaces():
                addrs = netifaces.ifaddresses(interface)
                if netifaces.AF_INET in addrs:
                    for addr in addrs[netifaces.AF_INET]:
                        ip = addr['addr']
                        if not ip.startswith('127.') and '.' in ip:
                            return ip, default_gateway
            return "127.0.0.1", default_gateway
        except:
            return "127.0.0.1", "192.168.1.1"
    
    def scan_wifi_networks(self):
        """Scan for WiFi networks using termux-wifi-scaninfo"""
        wifi_devices = []
        try:
            # Try termux-wifi-scaninfo command first
            result = subprocess.run(['termux-wifi-scaninfo'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'SSID:' in line or 'BSSID:' in line:
                        wifi_devices.append({
                            'type': 'wifi',
                            'info': line.strip(),
                            'signal_strength': 'unknown',
                            'timestamp': datetime.now().isoformat()
                        })
        except:
            pass
            
        # Enhanced scanning with root privileges
        if self.root_mode:
            try:
                # Use iwlist with root for better results
                result = subprocess.run(['su', '-c', 'iwlist scan'], 
                                      capture_output=True, text=True, timeout=20)
                if result.returncode == 0:
                    current_network = {}
                    for line in result.stdout.split('\n'):
                        line = line.strip()
                        if 'Cell' in line and 'Address:' in line:
                            if current_network:
                                current_network['enhanced'] = True
                                wifi_devices.append(current_network)
                            current_network = {
                                'type': 'wifi',
                                'mac': line.split('Address: ')[1].strip(),
                                'timestamp': datetime.now().isoformat(),
                                'root_scan': True
                            }
                        elif 'ESSID:' in line:
                            current_network['ssid'] = line.split('ESSID:')[1].strip().strip('"')
                        elif 'Signal level=' in line:
                            current_network['signal_strength'] = line.split('Signal level=')[1].split(' ')[0]
                        elif 'Encryption key:' in line:
                            current_network['encryption'] = 'on' if 'on' in line else 'off'
                        elif 'Quality=' in line:
                            current_network['quality'] = line.split('Quality=')[1].split(' ')[0]
                    
                    if current_network:
                        current_network['enhanced'] = True
                        wifi_devices.append(current_network)
            except:
                pass
        else:
            # Fallback: Try regular iwlist output
            try:
                result = subprocess.run(['iwlist', 'scan'], 
                                      capture_output=True, text=True, timeout=15)
                if result.returncode == 0:
                    current_network = {}
                    for line in result.stdout.split('\n'):
                        line = line.strip()
                        if 'Cell' in line and 'Address:' in line:
                            if current_network:
                                wifi_devices.append(current_network)
                            current_network = {
                                'type': 'wifi',
                                'mac': line.split('Address: ')[1].strip(),
                                'timestamp': datetime.now().isoformat()
                            }
                        elif 'ESSID:' in line:
                            current_network['ssid'] = line.split('ESSID:')[1].strip().strip('"')
                        elif 'Signal level=' in line:
                            current_network['signal_strength'] = line.split('Signal level=')[1].split(' ')[0]
                    
                    if current_network:
                        wifi_devices.append(current_network)
            except:
                pass
            
        return wifi_devices
    
    def scan_bluetooth_devices(self):
        """Scan for external Bluetooth devices"""
        bt_devices = []
        try:
            # Try termux-bluetooth-scaninfo for external devices
            result = subprocess.run(['termux-bluetooth-scaninfo'], 
                                  capture_output=True, text=True, timeout=15)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.strip():
                        bt_devices.append({
                            'type': 'bluetooth',
                            'info': line.strip(),
                            'timestamp': datetime.now().isoformat(),
                            'external': True
                        })
        except:
            pass
            
        # Enhanced Bluetooth scanning with root privileges
        if self.root_mode:
            try:
                # Use hcitool for comprehensive external device discovery
                result = subprocess.run(['su', '-c', 'hcitool scan'], 
                                      capture_output=True, text=True, timeout=20)
                if result.returncode == 0:
                    for line in result.stdout.split('\n')[1:]:  # Skip header
                        if line.strip():
                            parts = line.strip().split('\t')
                            if len(parts) >= 2:
                                bt_devices.append({
                                    'type': 'bluetooth',
                                    'mac': parts[0].strip(),
                                    'name': parts[1].strip() if len(parts) > 1 else 'Unknown Device',
                                    'timestamp': datetime.now().isoformat(),
                                    'external': True,
                                    'root_scan': True
                                })
                                
                # Also try bluetoothctl for modern devices
                try:
                    result = subprocess.run(['su', '-c', 'timeout 10 bluetoothctl scan on'], 
                                          capture_output=True, text=True, timeout=15)
                    if result.returncode == 0:
                        for line in result.stdout.split('\n'):
                            if 'Device' in line and 'NEW' in line:
                                parts = line.split()
                                if len(parts) >= 3:
                                    bt_devices.append({
                                        'type': 'bluetooth',
                                        'mac': parts[2],
                                        'name': ' '.join(parts[3:]) if len(parts) > 3 else 'Unknown',
                                        'timestamp': datetime.now().isoformat(),
                                        'external': True,
                                        'modern_scan': True
                                    })
                except:
                    pass
                    
            except:
                pass
        else:
            # Try hcitool without root for basic external device discovery
            try:
                result = subprocess.run(['hcitool', 'scan'], 
                                      capture_output=True, text=True, timeout=15)
                if result.returncode == 0:
                    for line in result.stdout.split('\n')[1:]:  # Skip header
                        if line.strip():
                            parts = line.strip().split('\t')
                            if len(parts) >= 2:
                                bt_devices.append({
                                    'type': 'bluetooth',
                                    'mac': parts[0].strip(),
                                    'name': parts[1].strip() if len(parts) > 1 else 'Unknown Device',
                                    'timestamp': datetime.now().isoformat(),
                                    'external': True
                                })
            except:
                pass
            
        return bt_devices
    
    def scan_network_devices(self):
        """Scan for external network connections and devices"""
        external_devices = []
        
        # Focus on external connections rather than internal network
        try:
            # Check for active external connections
            result = subprocess.run(['netstat', '-tuln'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'ESTABLISHED' in line or 'LISTEN' in line:
                        parts = line.split()
                        if len(parts) >= 4:
                            local_addr = parts[3]
                            remote_addr = parts[4] if len(parts) > 4 else ''
                            
                            # Focus on external connections (not localhost)
                            if remote_addr and not remote_addr.startswith('127.') and not remote_addr.startswith('0.0.0.0'):
                                try:
                                    # Try to resolve hostname for external connections
                                    hostname = socket.gethostbyaddr(remote_addr.split(':')[0])[0]
                                except:
                                    hostname = 'External Device'
                                
                                external_devices.append({
                                    'type': 'network',
                                    'local_addr': local_addr,
                                    'remote_addr': remote_addr,
                                    'hostname': hostname,
                                    'status': 'active',
                                    'external': True,
                                    'timestamp': datetime.now().isoformat()
                                })
        except:
            pass
            
        # Check for active internet connections
        try:
            result = subprocess.run(['ss', '-tuln'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.strip() and not line.startswith('Netid'):
                        parts = line.split()
                        if len(parts) >= 5:
                            local_addr = parts[4]
                            if ':' in local_addr:
                                # This indicates an external connection
                                external_devices.append({
                                    'type': 'network',
                                    'connection': local_addr,
                                    'status': 'listening',
                                    'external': True,
                                    'timestamp': datetime.now().isoformat()
                                })
        except:
            pass
            
        return external_devices
    
    def scan_open_ports(self, ip, common_ports=None):
        """Scan for open ports on a given IP"""
        if common_ports is None:
            common_ports = [21, 22, 23, 25, 53, 80, 110, 443, 993, 995, 1723, 3389, 5900, 8080]
        
        open_ports = []
        for port in common_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    open_ports.append(port)
                sock.close()
            except:
                pass
        return open_ports
    
    def perform_full_scan(self):
        """Perform a comprehensive scan for external devices"""
        all_devices = []
        
        print("🔍 Scanning external WiFi networks...")
        wifi_devices = self.scan_wifi_networks()
        all_devices.extend(wifi_devices)
        
        print("📡 Scanning external Bluetooth devices...")
        bt_devices = self.scan_bluetooth_devices()
        all_devices.extend(bt_devices)
        
        print("🌐 Scanning external network connections...")
        network_devices = self.scan_network_devices()
        all_devices.extend(network_devices)
        
        # Check for additional external connections
        print("🔗 Checking for other external connections...")
        try:
            # Check for USB devices
            result = subprocess.run(['lsusb'], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.strip():
                        all_devices.append({
                            'type': 'usb',
                            'info': line.strip(),
                            'external': True,
                            'timestamp': datetime.now().isoformat()
                        })
        except:
            pass
            
        # Check for connected peripherals
        try:
            result = subprocess.run(['dmesg', '|', 'grep', '-i', 'usb'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                usb_count = len([line for line in result.stdout.split('\n') if 'usb' in line.lower()])
                if usb_count > 0:
                    all_devices.append({
                        'type': 'usb',
                        'count': usb_count,
                        'info': f'{usb_count} USB devices detected',
                        'external': True,
                        'timestamp': datetime.now().isoformat()
                    })
        except:
            pass
            
        return all_devices
    
    def continuous_scan(self):
        """Continuous scanning loop"""
        while self.scan_active:
            try:
                devices = self.perform_full_scan()
                
                # Update detected devices
                for device in devices:
                    device_id = f"{device['type']}_{hash(str(device))}"
                    device['id'] = device_id
                    self.detected_devices[device_id] = device
                
                # Emit update to web interface
                socketio.emit('radar_update', {
                    'devices': list(self.detected_devices.values()),
                    'scan_time': datetime.now().isoformat()
                })
                
                print(f"📊 Found {len(devices)} devices in this scan")
                time.sleep(30)  # Scan every 30 seconds
                
            except Exception as e:
                print(f"❌ Scan error: {e}")
                time.sleep(10)
    
    def start_scanning(self):
        """Start the continuous scanning process"""
        if not self.scan_active:
            self.scan_active = True
            self.scan_thread = threading.Thread(target=self.continuous_scan)
            self.scan_thread.daemon = True
            self.scan_thread.start()
            print("🚀 Radar scanning started!")
    
    def stop_scanning(self):
        """Stop the scanning process"""
        self.scan_active = False
        if self.scan_thread:
            self.scan_thread.join(timeout=5)
        print("⏹️ Radar scanning stopped!")

# Initialize SAGO scanner
sago = SagoScanner()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/devices')
def get_devices():
    return jsonify({
        'devices': list(sago.detected_devices.values()),
        'scan_active': sago.scan_active,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/start_scan')
def start_scan():
    sago.start_scanning()
    return jsonify({'status': 'started'})

@app.route('/api/stop_scan')
def stop_scan():
    sago.stop_scanning()
    return jsonify({'status': 'stopped'})

@socketio.on('connect')
def handle_connect():
    print('🔌 Client connected to SAGO v1')
    emit('radar_status', {'scan_active': sago.scan_active})

@socketio.on('disconnect')
def handle_disconnect():
    print('🔌 Client disconnected from SAGO v1')

@socketio.on('start_radar')
def handle_start_radar():
    sago.start_scanning()
    emit('radar_status', {'scan_active': True})

@socketio.on('stop_radar')
def handle_stop_radar():
    sago.stop_scanning()
    emit('radar_status', {'scan_active': False})

if __name__ == '__main__':
    print("🎯 Termux Radar Application Starting...")
    print("🌐 Access the radar interface at: http://localhost:5000")
    print("📱 Or from your phone's IP address on port 5000")
    
    # Get local IP for display
    local_ip, _ = radar.get_local_ip()
    print(f"📡 Local IP: {local_ip}:5000")
    
    # Start the radar automatically
    radar.start_scanning()
    
    # Run the Flask-SocketIO server
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)