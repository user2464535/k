# 🎯 SAGO v1 - External Device Scanner

A powerful, real-time external device detection tool designed for Termux that provides an interactive web-based interface to detect and monitor external devices, networks, and connections beyond your local network.

![SAGO v1](https://img.shields.io/badge/Platform-Termux-green?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.8+-blue?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)rmux Radar - Network Device Scanner

A powerful, real-time network reconnaissance tool designed for Termux that provides an interactive web-based radar interface to detect and monitor nearby devices, WiFi networks, and Bluetooth devices.

![Termux Radar Interface](https://img.shields.io/badge/Platform-Termux-green?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.8+-blue?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)

## 🌟 Features

### 🔍 **External Device Detection**
- **WiFi Networks**: Detect external WiFi networks and access points
- **Bluetooth Devices**: Discover external Bluetooth devices and peripherals
- **Network Connections**: Monitor external network connections and endpoints
- **USB Devices**: Detect connected USB peripherals and devices
- **Real-time Updates**: Live scanning with automatic refresh

### 🎨 **Interactive Web Interface**
- **Device Visualization**: Animated display showing external devices
- **Device Categorization**: Organized display by device type (WiFi, Bluetooth, Network, USB)
- **Real-time Statistics**: Live counters and scan information
- **Mobile Optimized**: Responsive design for phone/tablet use

### ⚡ **Advanced Capabilities**
- **Port Scanning**: Detect open ports on network devices
- **Background Service**: Run radar as daemon process
- **WebSocket Updates**: Real-time data streaming
- **Termux Integration**: Uses Termux API for enhanced scanning

## 🚀 Quick Start

### 1. **Download and Install**
```bash
# Clone or download the radar application
cd ~
git clone [repository-url] termux-radar
# OR download and extract the files to ~/termux-radar

# Navigate to the directory
cd termux-radar

# Make installation script executable and run it
chmod +x install.sh
./install.sh
```

### 2. **Start the Radar**
```bash
# Start in foreground (recommended for first run)
./start_radar.sh

# OR start as background service
./radar_service.sh start
```

### 3. **Access the Interface**
Open your browser and navigate to:
- **Local access**: `http://localhost:5000`
- **Network access**: `http://[your-phone-ip]:5000`

## 📱 Installation Guide

### **Prerequisites**
1. **Termux App**: Install from [F-Droid](https://f-droid.org/en/packages/com.termux/) or Google Play
2. **Termux:API**: Install the API addon for enhanced functionality
3. **Storage Permission**: Run `termux-setup-storage` to grant storage access

### **Automatic Installation**
The installation script handles everything automatically:

```bash
cd termux-radar
chmod +x install.sh
./install.sh
```

The script will:
- Update package repositories
- Install Python, pip, and system tools
- Install required Python libraries
- Set up Termux API integration
- Create launcher and service scripts
- Configure permissions and access

### **Manual Installation** (if needed)
```bash
# Update packages
pkg update && pkg upgrade -y

# Install system packages
pkg install -y python python-pip git nmap wireless-tools bluetooth net-tools termux-api

# Install Python dependencies
pip install flask flask-socketio psutil netifaces python-nmap scapy

# Optional: Bluetooth and WiFi libraries
pip install pybluez wifi
```

## 🎮 Usage Guide

### **Starting the Radar**

#### **Foreground Mode** (Interactive)
```bash
./start_radar.sh
```
- Best for testing and development
- Shows real-time logs
- Stop with `Ctrl+C`

#### **Background Service** (Daemon)
```bash
./radar_service.sh start    # Start service
./radar_service.sh stop     # Stop service  
./radar_service.sh status   # Check status
```
- Runs in background
- Survives terminal closure
- Logs to `radar.log`

### **Web Interface Controls**
- **Start Radar**: Begin continuous scanning
- **Stop Radar**: Pause scanning operations
- **Manual Scan**: Perform one-time scan
- **Real-time Display**: Automatic updates every 30 seconds

### **Scanning Capabilities**

### **External WiFi Network Detection**
- SSID and BSSID discovery for external networks
- Signal strength measurement
- Network encryption detection
- Hidden network identification
- Access point identification

### **External Bluetooth Device Scanning**
- Device name and MAC address detection
- Device type identification (phones, headsets, speakers, etc.)
- Signal proximity estimation
- Pairing status detection
- External peripheral discovery

### **External Network Connection Monitoring**
- Active external connection detection
- Remote endpoint identification
- Connection protocol analysis
- Hostname resolution for external IPs
- Connection status monitoring

### **USB Device Detection**
- Connected USB peripheral identification
- Device information extraction
- USB device count monitoring
- Peripheral type detection

## 🔧 Configuration

### **Customizing Scan Parameters**
Edit `app.py` to modify:
- Scan intervals (default: 30 seconds)
- Port ranges for network scanning
- WiFi scan timeout values
- Bluetooth discovery duration

### **Network Settings**
- **Default Port**: 5000
- **Bind Address**: 0.0.0.0 (all interfaces)
- **Access**: Local network accessible

### **Permissions Required**
- **Location**: For WiFi network scanning
- **Bluetooth**: For BT device discovery  
- **Network**: For network device scanning
- **Storage**: For saving scan results

## 📊 Technical Details

### **Architecture**
- **Backend**: Python Flask with SocketIO
- **Frontend**: HTML5, CSS3, JavaScript
- **Communication**: WebSocket for real-time updates
- **Scanning**: Multi-threaded background processes

### **Supported External Devices**
- **WiFi**: 802.11 a/b/g/n/ac/ax networks and access points
- **Bluetooth**: Classic and BLE devices, peripherals, and accessories
- **Network**: External TCP/UDP connections and remote endpoints
- **USB**: Connected peripherals, storage devices, and accessories

### **Detection Methods**
- **Passive Scanning**: Monitor network traffic
- **Active Probing**: Send discovery packets
- **API Integration**: Termux system calls
- **Port Scanning**: TCP connection attempts

## 🛠️ Troubleshooting

### **Common Issues**

#### **Permission Denied Errors**
```bash
# Grant storage permission
termux-setup-storage

# Install Termux:API app and grant permissions
# Restart Termux after granting permissions
```

#### **No WiFi Networks Detected**
- Ensure location permission is granted
- Check that WiFi is enabled on device
- Try manual scan from interface
- Some networks may be hidden

#### **Bluetooth Scanning Fails**
- Enable Bluetooth on device
- Grant Bluetooth permissions to Termux
- Some devices require root for BT scanning
- Check if `hcitool` is available

#### **Network Scan Incomplete**
- Ensure device is connected to WiFi network
- Router may block scanning attempts  
- Try from different network
- Some devices have scanning protection

#### **Web Interface Not Loading**
```bash
# Check if service is running
./radar_service.sh status

# Check logs for errors
tail -f radar.log

# Try restarting the service
./radar_service.sh stop
./radar_service.sh start
```

### **Performance Optimization**
- **Reduce Scan Frequency**: Edit scan interval in `app.py`
- **Limit Port Ranges**: Modify port list for faster scans
- **Close Other Apps**: Free memory for better performance
- **Use Background Mode**: Reduce UI overhead

## 🔒 Security & Privacy

### **Data Handling**
- **Local Only**: All scanning data stays on device
- **No External Transmission**: No data sent to external servers
- **Temporary Storage**: Scan results not permanently saved
- **Privacy Focused**: Respects network privacy boundaries

### **Ethical Usage**
- **Own Networks Only**: Scan only networks you own/control
- **Respect Privacy**: Don't attempt to access detected devices
- **Legal Compliance**: Follow local laws regarding network scanning
- **Educational Purpose**: Use for learning and legitimate security testing

### **Security Features**
- **Localhost Binding**: Web interface accessible locally
- **No Authentication**: Consider adding auth for public networks
- **Scan Limitations**: Built-in limits to prevent abuse
- **Permission Controls**: Requires explicit permission grants

## 📋 Command Reference

### **Service Management**
```bash
./start_radar.sh                 # Start in foreground
./stop_radar.sh                  # Stop radar
./radar_service.sh start         # Start as daemon
./radar_service.sh stop          # Stop daemon
./radar_service.sh status        # Check daemon status
```

### **Utility Commands**
```bash
# View real-time logs
tail -f radar.log

# Check running processes
ps aux | grep python

# Test network connectivity
ping -c 1 8.8.8.8

# Check permissions
termux-info
```

### **API Access**
- `GET /api/devices` - Get current device list
- `GET /api/start_scan` - Start scanning
- `GET /api/stop_scan` - Stop scanning
- WebSocket events for real-time updates

## 🤝 Contributing

### **Bug Reports**
- Include Termux version and device info
- Provide logs from `radar.log`
- Describe expected vs actual behavior
- Include steps to reproduce

### **Feature Requests**
- Describe the desired functionality
- Explain the use case
- Consider security implications
- Suggest implementation approach

### **Code Contributions**
- Follow Python PEP 8 style guidelines
- Add comments for complex logic
- Test on different Android versions
- Update documentation as needed

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## ⚠️ Disclaimer

This tool is intended for educational and legitimate security testing purposes only. Users are responsible for ensuring compliance with applicable laws and regulations. Do not use this tool to access networks or devices without proper authorization.

## 🆘 Support

### **Documentation**
- Check this README for common issues
- Review the installation guide carefully
- Test with minimal configuration first

### **Community**
- Search existing issues before creating new ones
- Provide detailed information in bug reports
- Help others by sharing solutions

### **System Requirements**
- **Android Version**: 5.0+ (API level 21)
- **Termux Version**: Latest stable release
- **RAM**: 512MB+ available
- **Storage**: 100MB+ free space
- **Network**: WiFi connection recommended

---

**🎯 Happy Scanning!** 

*Built with ❤️ for the Termux community*