# 🔑 Root Access Guide for SAGO v1

## 🎯 Why Use Root Access?

Running SAGO v1 with root privileges provides enhanced external device detection capabilities:

### **🚀 Enhanced Features with Root:**
- **Advanced WiFi Scanning**: Access to more external network details and hidden networks
- **Raw Socket Access**: Direct network packet inspection for external connections
- **System-level Bluetooth**: Better external device discovery and pairing status
- **Network Interface Control**: Ability to monitor all external network interfaces
- **USB Device Detection**: Enhanced USB peripheral identification
- **Deep Packet Analysis**: External traffic monitoring and protocol analysis

### **👤 Standard Mode Limitations:**
- Limited WiFi network information
- Basic Bluetooth scanning only  
- Restricted network interface access
- Slower port scanning
- No raw packet access

---

## 🔓 How to Enable Root Access

### **Step 1: Root Your Device**

#### **Method A: Magisk (Recommended)**
```bash
# 1. Unlock bootloader (device-specific)
# 2. Install custom recovery (TWRP)
# 3. Flash Magisk ZIP file
# 4. Reboot and install Magisk Manager
```

#### **Method B: SuperSU (Legacy)**
```bash
# 1. Unlock bootloader
# 2. Flash SuperSU via recovery
# 3. Install SuperSU app
```

### **Step 2: Grant Termux Root Access**

1. **Open Root Manager** (Magisk/SuperSU app)
2. **Navigate to Apps/Superuser**
3. **Find Termux** in the list
4. **Grant Root Permission** ✅
5. **Test Access**: Run `su` in Termux

### **Step 3: Verify Root Access**
```bash
# Test root access
su -c 'id'
# Should output: uid=0(root) gid=0(root) groups=...

# Check available tools
su -c 'which iwlist'    # WiFi scanning
su -c 'which hcitool'   # Bluetooth scanning  
su -c 'which nmap'      # Network scanning
```

---

## 🚀 Running Radar with Root

### **Method 1: Automatic Root Detection**
```bash
# The scanner will auto-detect and use root if available
./start_radar.sh
```

### **Method 2: Explicit Root Mode**
```bash
# Force root mode startup
./start_root.sh
```

### **Method 3: Service with Root**
```bash
# Start background service with root
./radar_service.sh root
```

### **Method 4: Manual Root Execution**
```bash
# Direct root command
su -c './start_radar.sh'
```

---

## 🔧 Root Mode Commands

### **Service Management**
```bash
./radar_service.sh start     # Auto-detect root
./radar_service.sh root      # Force root mode
./radar_service.sh status    # Check if running as root
./radar_service.sh stop      # Stop service
```

### **Status Checking**
```bash
# Check if SAGO v1 is running with root
ps aux | grep python
# Look for UID 0 (root) in the output

# Verify root capabilities
su -c 'iwlist scan | head -5'
su -c 'hcitool scan'
su -c 'netstat -tuln'
```

---

## 🛠️ Troubleshooting Root Issues

### **❌ "su: not found"**
**Problem**: Device is not rooted
**Solution**: 
- Root your device using Magisk or similar
- Ensure bootloader is unlocked
- Install proper root binaries

### **❌ "su: permission denied"**  
**Problem**: Root access blocked
**Solutions**:
- Grant permission in root manager app
- Check if Termux is in the allowed apps list
- Restart Termux after granting permissions
- Some root managers require explicit approval

### **❌ "Root access available but features limited"**
**Problem**: Missing system tools
**Solutions**:
```bash
# Install additional tools with root
su -c 'apt update && apt install wireless-tools bluetooth'

# Check system paths
su -c 'echo $PATH'
# Should include /system/bin, /system/xbin

# Find tools manually
su -c 'find /system -name "*iwlist*" 2>/dev/null'
su -c 'find /system -name "*hcitool*" 2>/dev/null'
```

### **❌ WiFi Scanning Still Limited**
**Problem**: Missing iwlist or similar tools
**Solutions**:
```bash
# Try alternative WiFi tools
su -c 'iw dev'                    # Modern WiFi tool
su -c 'cat /proc/net/wireless'    # Wireless interfaces
su -c 'iwconfig'                  # WiFi configuration

# Install from system if available
su -c 'find /system -name "*iw*" -executable 2>/dev/null'
```

### **❌ Bluetooth Scanning Fails**
**Problem**: Bluetooth tools not accessible
**Solutions**:
```bash
# Check Bluetooth status  
su -c 'hciconfig'                 # Bluetooth interfaces
su -c 'systemctl status bluetooth' # Bluetooth service
su -c 'rfkill list bluetooth'     # Bluetooth radio status

# Alternative Bluetooth scanning
su -c 'bluetoothctl scan on'      # Modern Bluetooth tool
su -c 'l2ping -c 1 <target_mac>'  # Direct ping test
```

---

## 🔒 Security Considerations

### **⚠️ Root Risks**
- **System Access**: Root gives full system control
- **Security Bypass**: Bypasses Android security model  
- **App Vulnerabilities**: Rooted apps have elevated risks
- **Warranty Void**: May void device warranty
- **OTA Updates**: May prevent system updates

### **🛡️ Safety Practices**
- **Use Reputable Tools**: Stick to well-known root methods
- **Keep Updated**: Update root manager and Termux regularly
- **Monitor Permissions**: Regularly review app root permissions
- **Backup Device**: Full system backup before rooting
- **Test Thoroughly**: Test radar functionality after rooting

### **🔐 Access Control**
- Root radar only scans local networks
- No external data transmission
- All scanning data stays on device
- Respects network boundaries and laws

---

## 📊 Root vs Non-Root Comparison

| Feature | Non-Root Mode | Root Mode |
|---------|---------------|-----------|
| **WiFi Networks** | Basic SSID detection | Full network details + hidden networks |
| **Bluetooth** | Limited device discovery | Complete device info + pairing status |
| **Network Scanning** | Basic ping + common ports | Advanced scanning + all interfaces |
| **Port Detection** | User-accessible ports only | System-level port access |
| **Performance** | Standard speed | Faster, more accurate |
| **Information Detail** | Basic device info | Enhanced technical details |
| **Security Scanning** | Limited capability | Professional-grade scanning |

---

## 🎯 Recommended Root Setup

### **Ideal Configuration:**
1. **Root Method**: Magisk (systemless root)
2. **Root Manager**: Magisk Manager
3. **Termux Version**: Latest from F-Droid
4. **Additional Tools**: Install wireless-tools, bluetooth packages
5. **Permissions**: Grant all requested permissions
6. **API Access**: Install and configure Termux:API

### **Quick Setup Commands:**
```bash
# After rooting, run these commands:
pkg update && pkg upgrade -y
pkg install wireless-tools bluetooth net-tools
su -c 'which iwlist && echo "WiFi tools ready"'
su -c 'which hcitool && echo "Bluetooth tools ready"'

# Test root radar
./start_root.sh
```

---

## 💡 Tips for Best Results

1. **Grant Permissions Early**: Allow root access before first scan
2. **Enable Location**: Required for WiFi network scanning
3. **Enable Bluetooth**: Needed for device discovery
4. **Check Tool Availability**: Verify iwlist, hcitool are accessible
5. **Monitor Performance**: Root scanning is more resource-intensive
6. **Regular Updates**: Keep root tools and Termux updated
7. **Network Ethics**: Only scan networks you own/control

---

**🔥 With root access, SAGO v1 becomes a professional-grade external device detection tool!**

*⚠️ Remember: With great power comes great responsibility. Use root access ethically and legally.*